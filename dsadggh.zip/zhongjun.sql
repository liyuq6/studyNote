/*
 Navicat PostgreSQL Data Transfer

 Source Server         : 118.178.178.132 zhongjun
 Source Server Type    : PostgreSQL
 Source Server Version : 150001 (150001)
 Source Host           : 127.0.0.1:5432
 Source Catalog        : asec_platform
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 150001 (150001)
 File Encoding         : 65001

 Date: 01/06/2023 19:17:06
*/


-- ----------------------------
-- Sequence structure for tb_access_log_access_log_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_access_log_access_log_id_seq";
CREATE SEQUENCE "tb_access_log_access_log_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_app_address_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_app_address_id_seq";
CREATE SEQUENCE "tb_app_address_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_app_group_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_app_group_id_seq";
CREATE SEQUENCE "tb_app_group_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_channel_type_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_channel_type_id_seq";
CREATE SEQUENCE "tb_channel_type_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_condition_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_condition_id_seq";
CREATE SEQUENCE "tb_condition_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_console_config_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_console_config_id_seq";
CREATE SEQUENCE "tb_console_config_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_ddr_score_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_ddr_score_id_seq";
CREATE SEQUENCE "tb_ddr_score_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_events_history_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_events_history_id_seq";
CREATE SEQUENCE "tb_events_history_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_events_records_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_events_records_id_seq";
CREATE SEQUENCE "tb_events_records_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_fake_ip_pool_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_fake_ip_pool_id_seq";
CREATE SEQUENCE "tb_fake_ip_pool_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_file_type_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_file_type_id_seq";
CREATE SEQUENCE "tb_file_type_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_risk_level_config_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_risk_level_config_id_seq";
CREATE SEQUENCE "tb_risk_level_config_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_se_app_relation_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_se_app_relation_id_seq";
CREATE SEQUENCE "tb_se_app_relation_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_sensitive_elem_label_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_sensitive_elem_label_id_seq";
CREATE SEQUENCE "tb_sensitive_elem_label_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_sensitive_element_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_sensitive_element_id_seq";
CREATE SEQUENCE "tb_sensitive_element_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_sensitive_rule_type_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_sensitive_rule_type_id_seq";
CREATE SEQUENCE "tb_sensitive_rule_type_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_system_version_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_system_version_id_seq";
CREATE SEQUENCE "tb_system_version_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_ueba_risk_level_config_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_ueba_risk_level_config_id_seq";
CREATE SEQUENCE "tb_ueba_risk_level_config_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_ueba_strategy_condition_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_ueba_strategy_condition_id_seq";
CREATE SEQUENCE "tb_ueba_strategy_condition_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_ueba_strategy_condition_id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_ueba_strategy_condition_id_seq1";
CREATE SEQUENCE "tb_ueba_strategy_condition_id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tb_user_tag_config_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tb_user_tag_config_id_seq";
CREATE SEQUENCE "tb_user_tag_config_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Table structure for tb_access_log
-- ----------------------------
DROP TABLE IF EXISTS "tb_access_log";
CREATE TABLE "tb_access_log" (
  "access_log_id" int4 NOT NULL DEFAULT nextval('tb_access_log_access_log_id_seq'::regclass),
  "src_ip" varchar COLLATE "pg_catalog"."default",
  "src_port" int4,
  "dst_ip" varchar COLLATE "pg_catalog"."default",
  "dst_port" int4,
  "protocol" varchar COLLATE "pg_catalog"."default",
  "destination_url" varchar COLLATE "pg_catalog"."default",
  "status" int4,
  "deny_reason" varchar COLLATE "pg_catalog"."default",
  "access_user_id" varchar COLLATE "pg_catalog"."default",
  "access_username" varchar COLLATE "pg_catalog"."default",
  "app_id" int8,
  "app_name" varchar COLLATE "pg_catalog"."default",
  "strategy_id" int8,
  "strategy_name" varchar COLLATE "pg_catalog"."default",
  "iss" varchar COLLATE "pg_catalog"."default",
  "access_time" timestamptz(6),
  "corp_id" int8,
  "appliance_id" int8,
  "client_id" int8,
  "client_name" varchar COLLATE "pg_catalog"."default",
  "strategy_check_time" int4
)
;

-- ----------------------------
-- Records of tb_access_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_access_strategy
-- ----------------------------
DROP TABLE IF EXISTS "tb_access_strategy";
CREATE TABLE "tb_access_strategy" (
  "id" int8 NOT NULL,
  "corp_id" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "strategy_name" varchar COLLATE "pg_catalog"."default",
  "strategy_status" int4,
  "strategy_detail" varchar COLLATE "pg_catalog"."default",
  "user_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_group_ids" varchar[] COLLATE "pg_catalog"."default",
  "role_ids" varchar[] COLLATE "pg_catalog"."default",
  "app_ids" int8[],
  "app_group_ids" int8[],
  "start_time" varchar COLLATE "pg_catalog"."default",
  "end_time" varchar COLLATE "pg_catalog"."default",
  "enable_log" int4,
  "enable_all_user" int4,
  "enable_all_app" int4,
  "net_location" int4,
  "os_version" int4
)
;

-- ----------------------------
-- Records of tb_access_strategy
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_component
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_component";
CREATE TABLE "tb_admin_component" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "provider_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_admin_component
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_component" ("id", "name", "provider_id", "corp_id") VALUES ('7836aa27-9434-4170-888b-274243345451', 'fallback-ES256', 'ecdsa-generated', '2efd2601-d800-48b3-9035-9ed23694ba0f');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_component_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_component_config";
CREATE TABLE "tb_admin_component_config" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "component_id" varchar(36) COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default" NOT NULL,
  "value" text COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of tb_admin_component_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_component_config" ("id", "component_id", "name", "value") VALUES ('95cd7d54-faa4-4585-ad01-c63abfad9eeb', '7836aa27-9434-4170-888b-274243345451', 'ecdsaPublicKey', 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEoWaX+KkDdTMTcFj5Aowj3JF6wGJY+7tmNVnFOOsT+ahVtd9eaOHiQ0m9Y5Ai5N+blYRwWRg3HEOBgIC1Xslv3A==');
INSERT INTO "tb_admin_component_config" ("id", "component_id", "name", "value") VALUES ('cdc7a1ab-a4ed-4e34-9865-da58d8dd02dd', '7836aa27-9434-4170-888b-274243345451', 'ecdsaPrivateKey', 'MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgakw9B2rJhtJr62Dt8LI3FEwjkL8O+DRJuVW9Dn+cAKqhRANCAAShZpf4qQN1MxNwWPkCjCPckXrAYlj7u2Y1WcU46xP5qFW1315o4eJDSb1jkCLk35uVhHBZGDccQ4GAgLVeyW/c');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_corp
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_corp";
CREATE TABLE "tb_admin_corp" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now(),
  "company_name" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_admin_corp
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_corp" ("id", "name", "created_at", "updated_at", "company_name") VALUES ('2efd2601-d800-48b3-9035-9ed23694ba0f', 'default', '2023-04-25 11:17:22.666+08', '2023-04-25 11:17:22.666+08', 'default');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_credential
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_credential";
CREATE TABLE "tb_admin_credential" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(36) COLLATE "pg_catalog"."default",
  "type" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "secret_data" text COLLATE "pg_catalog"."default" NOT NULL,
  "credential_data" text COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_admin_credential
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_credential" ("id", "user_id", "type", "secret_data", "credential_data", "corp_id", "created_at", "updated_at") VALUES ('459732372590430841', '459732372456213113', 'password', '6JWcldEA7NJjai+RADuCCApdcLO5xDHuzj12gAdC3lciFJmH6Tk8jTUqjr2ftyn92AL9SCp7ija+7icbM+3gJg==', '{"UserSalt":"I4orQWR0LC910K0VHnopMA==","Iter":27500,"KeyLen":64}', '2efd2601-d800-48b3-9035-9ed23694ba0f', '2023-05-08 21:10:47.602+08', '2023-05-08 21:10:47.602+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_entity
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_entity";
CREATE TABLE "tb_admin_entity" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "phone" varchar(24) COLLATE "pg_catalog"."default",
  "email" varchar(255) COLLATE "pg_catalog"."default",
  "expire_time" timestamp(6),
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now(),
  "login_failed_times" int4,
  "lock_time" timestamp(6),
  "role_id" varchar COLLATE "pg_catalog"."default",
  "expire_type" int2,
  "desc" varchar COLLATE "pg_catalog"."default",
  "status" int2 DEFAULT 1
)
;

-- ----------------------------
-- Records of tb_admin_entity
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_entity" ("id", "name", "corp_id", "phone", "email", "expire_time", "created_at", "updated_at", "login_failed_times", "lock_time", "role_id", "expire_type", "desc", "status") VALUES ('459732372456213113', 'admin', '2efd2601-d800-48b3-9035-9ed23694ba0f', '', '', '2025-05-09 00:00:00', '2023-05-08 21:10:47.52+08', '2023-05-08 21:10:47.52+08', 0, '0001-01-01 00:00:00', '457930322189748857', 1, '', 1);
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_event_entity
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_event_entity";
CREATE TABLE "tb_admin_event_entity" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "admin_event_time" int8,
  "realm_id" varchar(255) COLLATE "pg_catalog"."default",
  "operation_type" varchar(255) COLLATE "pg_catalog"."default",
  "auth_realm_id" varchar(255) COLLATE "pg_catalog"."default",
  "auth_client_id" varchar(255) COLLATE "pg_catalog"."default",
  "auth_user_id" varchar(255) COLLATE "pg_catalog"."default",
  "ip_address" varchar(255) COLLATE "pg_catalog"."default",
  "resource_path" varchar(2550) COLLATE "pg_catalog"."default",
  "representation" text COLLATE "pg_catalog"."default",
  "error" varchar(255) COLLATE "pg_catalog"."default",
  "resource_type" varchar(64) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_admin_event_entity
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('98fa5ab0-e1ae-4cb9-aa48-3fa8aa82f718', 1685617098021, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'CREATE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, 'qwdsa', '', 'SENSITIVE_STRATEGY_ELEM');
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('7de244c8-4848-4429-a481-894fdcd701df', 1685617108016, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'CREATE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, 'dqwdqw', '', 'SENSITIVE_STRATEGY_ELEM');
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('9e5afc3e-93d4-40c9-b683-a27c93dd24c7', 1685617144892, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'CREATE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, '2742', '', 'SENSITIVE_STRATEGY_ELEM_TAG');
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('bdd1a1c0-8d95-4977-8a69-5d4b30b58b94', 1685617150944, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'CREATE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, 'dqw', '', 'SENSITIVE_STRATEGY_ELEM');
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('9c10673f-c552-438c-9ad4-ba7cf89f2406', 1685618117670, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'CREATE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, 'Create Appliance:test', '', 'APPLIANCE');
INSERT INTO "tb_admin_event_entity" ("id", "admin_event_time", "realm_id", "operation_type", "auth_realm_id", "auth_client_id", "auth_user_id", "ip_address", "resource_path", "representation", "error", "resource_type") VALUES ('77e56655-9363-41c3-80c6-6b259f038c9f', 1685618126462, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'DELETE', NULL, NULL, '459732372456213113', '175.9.141.29', NULL, 'delete Appliance:463199669590163467', '', 'APPLIANCE');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_login_log
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_login_log";
CREATE TABLE "tb_admin_login_log" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "client_id" varchar(255) COLLATE "pg_catalog"."default",
  "error" varchar(255) COLLATE "pg_catalog"."default",
  "ip_address" varchar(255) COLLATE "pg_catalog"."default",
  "corp_id" varchar(255) COLLATE "pg_catalog"."default",
  "event_time" int8,
  "type" varchar(255) COLLATE "pg_catalog"."default",
  "user_id" varchar(255) COLLATE "pg_catalog"."default",
  "auth_type" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_admin_login_log
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463196166289358859', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616029536, 'LOGIN', '459732372456213113', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197310126391307', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616711310, 'LOGOUT', '', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197318162677771', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616716104, 'LOGOUT', '', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197323313283083', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616719177, 'LOGOUT', '', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197334520463371', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616725853, 'LOGOUT', '', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197336886050827', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616727267, 'LOGOUT', '', '本地认证');
INSERT INTO "tb_admin_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "auth_type") VALUES ('463197360374153227', 'Admin', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685616741263, 'LOGOUT', '', '本地认证');
COMMIT;

-- ----------------------------
-- Table structure for tb_admin_role
-- ----------------------------
DROP TABLE IF EXISTS "tb_admin_role";
CREATE TABLE "tb_admin_role" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "role_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "desc" varchar(255) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now(),
  "status" int2,
  "role_type" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_admin_role
-- ----------------------------
BEGIN;
INSERT INTO "tb_admin_role" ("id", "role_name", "corp_id", "desc", "created_at", "updated_at", "status", "role_type") VALUES ('457929931599383161', '安全管理员', '2efd2601-d800-48b3-9035-9ed23694ba0f', '系统安全负责人', '2023-04-26 10:45:09.054+08', '2023-04-26 10:45:09.054+08', 1, 'safe_admin');
INSERT INTO "tb_admin_role" ("id", "role_name", "corp_id", "desc", "created_at", "updated_at", "status", "role_type") VALUES ('457930296000514681', '审计管理员', '2efd2601-d800-48b3-9035-9ed23694ba0f', '系统审计负责人', '2023-04-26 10:48:46.256+08', '2023-04-26 10:48:46.256+08', 1, 'audit_admin');
INSERT INTO "tb_admin_role" ("id", "role_name", "corp_id", "desc", "created_at", "updated_at", "status", "role_type") VALUES ('457930322189748857', '系统管理员', '2efd2601-d800-48b3-9035-9ed23694ba0f', '系统总负责人', '2023-04-26 10:49:01.863+08', '2023-04-26 10:49:01.863+08', 1, 'system_admin');
COMMIT;

-- ----------------------------
-- Table structure for tb_agent
-- ----------------------------
DROP TABLE IF EXISTS "tb_agent";
CREATE TABLE "tb_agent" (
  "corp_id" int8,
  "appliance_id" int8 NOT NULL,
  "app_name" text COLLATE "pg_catalog"."default",
  "first_mac" text COLLATE "pg_catalog"."default",
  "mac_info" text[] COLLATE "pg_catalog"."default",
  "private_ip" text COLLATE "pg_catalog"."default",
  "public_ip" text COLLATE "pg_catalog"."default",
  "app_ips" text[] COLLATE "pg_catalog"."default",
  "app_plat" text COLLATE "pg_catalog"."default",
  "app_type" int4,
  "app_version" text COLLATE "pg_catalog"."default",
  "app_uuid" text COLLATE "pg_catalog"."default",
  "cpu_id" text COLLATE "pg_catalog"."default",
  "app_status" int4,
  "login_user" text COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6),
  "update_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_agent
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_agent_heartbeat
-- ----------------------------
DROP TABLE IF EXISTS "tb_agent_heartbeat";
CREATE TABLE "tb_agent_heartbeat" (
  "agent_id" int8 NOT NULL,
  "corp_id" int8 NOT NULL,
  "appliance_type" text COLLATE "pg_catalog"."default",
  "sys_cpu" text COLLATE "pg_catalog"."default",
  "sys_mem" text COLLATE "pg_catalog"."default",
  "kernel_version" text COLLATE "pg_catalog"."default",
  "arch" text COLLATE "pg_catalog"."default",
  "platform" text COLLATE "pg_catalog"."default",
  "platform_family" text COLLATE "pg_catalog"."default",
  "platform_version" text COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "version" varchar COLLATE "pg_catalog"."default",
  "upgrade_time" varchar COLLATE "pg_catalog"."default",
  "user_id" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_agent_heartbeat
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_agent_module_switch
-- ----------------------------
DROP TABLE IF EXISTS "tb_agent_module_switch";
CREATE TABLE "tb_agent_module_switch" (
  "agent_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_groups" varchar[] COLLATE "pg_catalog"."default",
  "user_roles" varchar[] COLLATE "pg_catalog"."default",
  "module_code" int4 NOT NULL,
  "create_time" timestamptz(6),
  "update_time" timestamptz(6),
  "corp_id" int8
)
;

-- ----------------------------
-- Records of tb_agent_module_switch
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_alert_rule
-- ----------------------------
DROP TABLE IF EXISTS "tb_alert_rule";
CREATE TABLE "tb_alert_rule" (
  "id" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "enable" int2 NOT NULL,
  "severity_ids" _int4,
  "user_ids" _varchar COLLATE "pg_catalog"."default",
  "user_group_ids" _varchar COLLATE "pg_catalog"."default",
  "enable_analysis" int2 NOT NULL,
  "channel_types" _varchar COLLATE "pg_catalog"."default",
  "sensitive_ids" _varchar COLLATE "pg_catalog"."default",
  "created_at" timestamptz(0),
  "updated_at" timestamptz(0),
  "sensitive_level" _int4,
  "time" jsonb,
  "built_in" int2 DEFAULT 2,
  "alert_type" int4 DEFAULT 2,
  "git_contain_option" int4,
  "git_path" varchar[] COLLATE "pg_catalog"."default",
  "svn_contain_option" int4,
  "svn_path" varchar[] COLLATE "pg_catalog"."default"
)
;
COMMENT ON COLUMN "tb_alert_rule"."alert_type" IS '告警类型(1代码/2数据)';
COMMENT ON COLUMN "tb_alert_rule"."git_contain_option" IS 'git包含逻辑(1包含/2不包含)';
COMMENT ON COLUMN "tb_alert_rule"."git_path" IS 'git_path';
COMMENT ON COLUMN "tb_alert_rule"."svn_contain_option" IS 'svn包含逻辑(1包含/2不包含)';
COMMENT ON COLUMN "tb_alert_rule"."svn_path" IS 'svn_path';

-- ----------------------------
-- Records of tb_alert_rule
-- ----------------------------
BEGIN;
INSERT INTO "tb_alert_rule" ("id", "corp_id", "name", "description", "enable", "severity_ids", "user_ids", "user_group_ids", "enable_analysis", "channel_types", "sensitive_ids", "created_at", "updated_at", "sensitive_level", "time", "built_in", "alert_type", "git_contain_option", "git_path", "svn_contain_option", "svn_path") VALUES ('1', '', '发送隐藏文件', '逃逸检测意图', 1, '{1,2,3,4,5}', '{0}', '{0}', 1, '{0}', '{22}', '2023-06-01 18:39:21+08', '2023-06-01 18:39:21+08', '{4}', '{"all": 1, "rule": []}', 1, 2, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for tb_alert_rule_template
-- ----------------------------
DROP TABLE IF EXISTS "tb_alert_rule_template";
CREATE TABLE "tb_alert_rule_template" (
  "id" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "enable" int2 NOT NULL DEFAULT 1,
  "severity_ids" _int4,
  "user_ids" _varchar COLLATE "pg_catalog"."default",
  "user_group_ids" _varchar COLLATE "pg_catalog"."default",
  "enable_analysis" int2 NOT NULL DEFAULT 1,
  "channel_types" _varchar COLLATE "pg_catalog"."default",
  "sensitive_ids" _varchar COLLATE "pg_catalog"."default",
  "created_at" timestamptz(0),
  "updated_at" timestamptz(0),
  "sensitive_level" _int4,
  "time" jsonb,
  "built_in" int2 DEFAULT 2
)
;

-- ----------------------------
-- Records of tb_alert_rule_template
-- ----------------------------
BEGIN;
INSERT INTO "tb_alert_rule_template" ("id", "corp_id", "name", "description", "enable", "severity_ids", "user_ids", "user_group_ids", "enable_analysis", "channel_types", "sensitive_ids", "created_at", "updated_at", "sensitive_level", "time", "built_in") VALUES ('1', '', '研发资料外发', '研发过程中产生的技术材料、源代码、实验数据等外发', 1, '{1,2,3,4,5}', '{0}', '{0}', 1, '{0}', '{6,7,8,9,10,11,12}', '2023-06-01 18:39:21+08', '2023-06-01 18:39:21+08', '{4}', '{"all": 1, "rule": []}', 1);
INSERT INTO "tb_alert_rule_template" ("id", "corp_id", "name", "description", "enable", "severity_ids", "user_ids", "user_group_ids", "enable_analysis", "channel_types", "sensitive_ids", "created_at", "updated_at", "sensitive_level", "time", "built_in") VALUES ('2', '', '财务数据外发', '公司财务相关的一些数据外发', 1, '{1,2,3,4,5}', '{0}', '{0}', 1, '{0}', '{1,17,13,21,14}', '2023-06-01 18:39:21+08', '2023-06-01 18:39:21+08', '{4}', '{"all": 1, "rule": []}', 1);
COMMIT;

-- ----------------------------
-- Table structure for tb_app_address
-- ----------------------------
DROP TABLE IF EXISTS "tb_app_address";
CREATE TABLE "tb_app_address" (
  "id" int4 NOT NULL DEFAULT nextval('tb_app_address_id_seq'::regclass),
  "app_id" int8,
  "protocol" varchar COLLATE "pg_catalog"."default",
  "address" varchar COLLATE "pg_catalog"."default",
  "port" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_app_address
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_app_group
-- ----------------------------
DROP TABLE IF EXISTS "tb_app_group";
CREATE TABLE "tb_app_group" (
  "id" int4 NOT NULL DEFAULT nextval('tb_app_group_id_seq'::regclass),
  "corp_id" int8 NOT NULL,
  "group_name" varchar COLLATE "pg_catalog"."default",
  "is_default" bool,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_app_group
-- ----------------------------
BEGIN;
INSERT INTO "tb_app_group" ("id", "corp_id", "group_name", "is_default", "created_at", "updated_at") VALUES (1, 0, '默认分组', 't', NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for tb_appliance
-- ----------------------------
DROP TABLE IF EXISTS "tb_appliance";
CREATE TABLE "tb_appliance" (
  "corp_id" int8,
  "appliance_id" int8 NOT NULL,
  "app_name" text COLLATE "pg_catalog"."default",
  "first_mac" text COLLATE "pg_catalog"."default",
  "mac_info" text[] COLLATE "pg_catalog"."default",
  "private_ip" text COLLATE "pg_catalog"."default",
  "public_ip" text COLLATE "pg_catalog"."default",
  "app_ips" text[] COLLATE "pg_catalog"."default",
  "app_plat" text COLLATE "pg_catalog"."default",
  "app_type" int4,
  "app_version" text COLLATE "pg_catalog"."default",
  "app_uuid" text COLLATE "pg_catalog"."default",
  "cpu_id" text COLLATE "pg_catalog"."default",
  "app_status" int4,
  "login_user" text COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6),
  "update_time" timestamptz(6),
  "se_ip" varchar COLLATE "pg_catalog"."default",
  "se_port" int4,
  "desc" text COLLATE "pg_catalog"."default",
  "tls" bool,
  "skip_cert_verify" bool,
  "min_tls_version" text COLLATE "pg_catalog"."default",
  "max_tls_version" text COLLATE "pg_catalog"."default",
  "bind_se_id" int8,
  "group_id" varchar COLLATE "pg_catalog"."default",
  "protocol" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_appliance
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_appliance_cfg
-- ----------------------------
DROP TABLE IF EXISTS "tb_appliance_cfg";
CREATE TABLE "tb_appliance_cfg" (
  "id" int4 NOT NULL,
  "cfg_data" bytea,
  "cfg_type" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_appliance_cfg
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_appliance_heartbeat
-- ----------------------------
DROP TABLE IF EXISTS "tb_appliance_heartbeat";
CREATE TABLE "tb_appliance_heartbeat" (
  "appliance_id" int8 NOT NULL,
  "corp_id" int8 NOT NULL,
  "appliance_type" text COLLATE "pg_catalog"."default",
  "sys_cpu" text COLLATE "pg_catalog"."default",
  "sys_mem" text COLLATE "pg_catalog"."default",
  "kernel_version" text COLLATE "pg_catalog"."default",
  "arch" text COLLATE "pg_catalog"."default",
  "platform" text COLLATE "pg_catalog"."default",
  "platform_family" text COLLATE "pg_catalog"."default",
  "platform_version" text COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "version" varchar COLLATE "pg_catalog"."default",
  "upgrade_time" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_appliance_heartbeat
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_appliance_install
-- ----------------------------
DROP TABLE IF EXISTS "tb_appliance_install";
CREATE TABLE "tb_appliance_install" (
  "appliance_id" int8 NOT NULL,
  "expire_time" timestamptz(6),
  "type" int4,
  "corp_id" int8,
  "platform" text COLLATE "pg_catalog"."default",
  "command_linux" varchar COLLATE "pg_catalog"."default",
  "command_windows" varchar COLLATE "pg_catalog"."default",
  "name" varchar COLLATE "pg_catalog"."default",
  "desc" varchar COLLATE "pg_catalog"."default",
  "appliance_group_id" varchar COLLATE "pg_catalog"."default",
  "gateway_ip" varchar COLLATE "pg_catalog"."default",
  "gateway_port" int2,
  "gateway_protocol" varchar COLLATE "pg_catalog"."default",
  "platform_ip" varchar COLLATE "pg_catalog"."default",
  "platform_port" int2
)
;

-- ----------------------------
-- Records of tb_appliance_install
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_application
-- ----------------------------
DROP TABLE IF EXISTS "tb_application";
CREATE TABLE "tb_application" (
  "id" int8 NOT NULL,
  "corp_id" int8 NOT NULL,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "app_name" varchar COLLATE "pg_catalog"."default",
  "app_describe" varchar COLLATE "pg_catalog"."default",
  "web_url" varchar COLLATE "pg_catalog"."default",
  "icon_url" varchar COLLATE "pg_catalog"."default",
  "app_status" int4,
  "group_id" int8
)
;

-- ----------------------------
-- Records of tb_application
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_auth_policy
-- ----------------------------
DROP TABLE IF EXISTS "tb_auth_policy";
CREATE TABLE "tb_auth_policy" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "group_ids" text[] COLLATE "pg_catalog"."default",
  "user_ids" text[] COLLATE "pg_catalog"."default",
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "root_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "is_default" bool NOT NULL DEFAULT false,
  "enable_all_user" bool NOT NULL DEFAULT false,
  "enable" bool NOT NULL DEFAULT true,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_auth_policy"."id" IS '策略id';
COMMENT ON COLUMN "tb_auth_policy"."name" IS '策略名称';
COMMENT ON COLUMN "tb_auth_policy"."description" IS '策略描述';
COMMENT ON COLUMN "tb_auth_policy"."group_ids" IS '分组列表';
COMMENT ON COLUMN "tb_auth_policy"."user_ids" IS '用户列表';
COMMENT ON COLUMN "tb_auth_policy"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_auth_policy"."root_group_id" IS '根目录id';
COMMENT ON COLUMN "tb_auth_policy"."enable_all_user" IS '所有用户生效';
COMMENT ON COLUMN "tb_auth_policy"."enable" IS '策略启用/禁用';
COMMENT ON TABLE "tb_auth_policy" IS '认证策略表';

-- ----------------------------
-- Records of tb_auth_policy
-- ----------------------------
BEGIN;
INSERT INTO "tb_auth_policy" ("id", "name", "description", "group_ids", "user_ids", "corp_id", "root_group_id", "is_default", "enable_all_user", "enable", "created_at", "updated_at") VALUES ('56b9c08b-d0e0-47a2-9cd6-c2101531cd78', '默认本地目录认证策略', '本地账号密码登陆', '{fee12b7b-a71f-4b16-b28e-c1241adb37d3}', NULL, '2efd2601-d800-48b3-9035-9ed23694ba0f', 'fee12b7b-a71f-4b16-b28e-c1241adb37d3', 't', 't', 't', '2023-06-01 18:39:22.650577+08', '2023-06-01 18:39:22.650577+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_auth_policy_idp_mapper
-- ----------------------------
DROP TABLE IF EXISTS "tb_auth_policy_idp_mapper";
CREATE TABLE "tb_auth_policy_idp_mapper" (
  "policy_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "idp_id" varchar(36) COLLATE "pg_catalog"."default",
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON TABLE "tb_auth_policy_idp_mapper" IS '认证策略和认证服务器的多对多关系';

-- ----------------------------
-- Records of tb_auth_policy_idp_mapper
-- ----------------------------
BEGIN;
INSERT INTO "tb_auth_policy_idp_mapper" ("policy_id", "idp_id", "corp_id", "created_at", "updated_at") VALUES ('56b9c08b-d0e0-47a2-9cd6-c2101531cd78', '40b115ef-fe57-44fe-9279-bd82af8a56a8', '2efd2601-d800-48b3-9035-9ed23694ba0f', '2023-06-01 18:39:22.653987+08', '2023-06-01 18:39:22.653987+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_channel_type
-- ----------------------------
DROP TABLE IF EXISTS "tb_channel_type";
CREATE TABLE "tb_channel_type" (
  "id" int4 NOT NULL DEFAULT nextval('tb_channel_type_id_seq'::regclass),
  "pid" int4,
  "channel" varchar COLLATE "pg_catalog"."default",
  "channel_name" varchar COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_channel_type
-- ----------------------------
BEGIN;
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (29, 0, 'im', 'IM通信', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (30, 0, 'remote', '远程协助', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (31, 0, 'netdisk', '网盘', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (32, 0, 'file_sharing', '文件共享', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (33, 0, 'vcs', '版本控制', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (34, 0, 'peripheral', '外设', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (35, 0, 'netnotes', '云笔记', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (36, 1, 'qq', 'QQ', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (37, 1, 'wechat', '微信', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (38, 1, 'tim', 'TIM', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (39, 1, 'dingtalk', '钉钉', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (40, 1, 'lark', '飞书', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (41, 1, 'wxwork', '企业微信', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (42, 2, 'mstsc', 'mstsc', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (43, 2, 'todesk', 'todesk', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (44, 2, 'sunlogin', '向日葵', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (45, 2, 'teamviewer', 'teamviewer', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (46, 3, 'baidu_netdisk', '百度云盘', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (47, 3, 'ali_netdisk', '阿里云盘', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (48, 3, 'weiyunapp', '腾讯微云', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (49, 4, 'ftp', 'ftp', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (50, 4, 'flashfxp', 'flashfxp', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (51, 6, 'usbdisk', 'U盘', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (52, 5, 'git', 'git', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (53, 5, 'svn', 'svn', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (54, 7, 'youdaoyunNote', '有道云笔记', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (55, 7, 'wizNote', '为知笔记', NULL);
INSERT INTO "tb_channel_type" ("id", "pid", "channel", "channel_name", "create_time") VALUES (56, 7, 'everNote', '印象笔记', NULL);
COMMIT;

-- ----------------------------
-- Table structure for tb_component
-- ----------------------------
DROP TABLE IF EXISTS "tb_component";
CREATE TABLE "tb_component" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "provider_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default"
)
;
COMMENT ON TABLE "tb_component" IS '用于身份验证，授权相关全局配置的扩展组件表';

-- ----------------------------
-- Records of tb_component
-- ----------------------------
BEGIN;
INSERT INTO "tb_component" ("id", "name", "provider_id", "corp_id") VALUES ('7836aa27-9434-4170-888b-274243345451', 'fallback-ES256', 'ecdsa-generated', '2efd2601-d800-48b3-9035-9ed23694ba0f');
COMMIT;

-- ----------------------------
-- Table structure for tb_component_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_component_config";
CREATE TABLE "tb_component_config" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "component_id" varchar(36) COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default" NOT NULL,
  "value" text COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON TABLE "tb_component_config" IS '组件配置';

-- ----------------------------
-- Records of tb_component_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_component_config" ("id", "component_id", "name", "value") VALUES ('ef1368dc-394d-4866-bad9-06703e63cba9', '7836aa27-9434-4170-888b-274243345451', 'ecdsaPublicKey', 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE6Aeoox2y6zlMbXNnZM/rafji+YnDDstwkCgA+32n/S5RdqH7ZAV4nkxWKvDM2LKTl5IF5/pLe/MrjUcdI4PAsA==');
INSERT INTO "tb_component_config" ("id", "component_id", "name", "value") VALUES ('dfc71940-365d-45da-ae7a-1420b571349e', '7836aa27-9434-4170-888b-274243345451', 'ecdsaPrivateKey', 'MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgL0e1ElgqFgpxy4MG1R5qBCL2utS7f+ARs7UKCfDHFgyhRANCAAToB6ijHbLrOUxtc2dkz+tp+OL5icMOy3CQKAD7faf9LlF2oftkBXieTFYq8MzYspOXkgXn+kt78yuNRx0jg8Cw');
COMMIT;

-- ----------------------------
-- Table structure for tb_condition
-- ----------------------------
DROP TABLE IF EXISTS "tb_condition";
CREATE TABLE "tb_condition" (
  "id" int4 NOT NULL DEFAULT nextval('tb_condition_id_seq'::regclass),
  "condition" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_condition
-- ----------------------------
BEGIN;
INSERT INTO "tb_condition" ("id", "condition") VALUES (1, '{"condition":[{"label": "文件", "value": "file_info","children":[{"label": "文件名", "value": "file_name"},{"label": "md5", "value": "md5"},{"label": "sha256", "value": "sha256"},{"label": "文件类型","value": "file_type"}]},{"label": "用户名", "value": "user_name"},{"label": "终端名", "value": "agent_name"},{"label": "风险等级", "value": "severity"},{"label": "动作", "value": "activity"},{"label": "外发通道", "value": "channel"}]}');
COMMIT;

-- ----------------------------
-- Table structure for tb_console_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_console_config";
CREATE TABLE "tb_console_config" (
  "id" int4 NOT NULL DEFAULT nextval('tb_console_config_id_seq'::regclass),
  "config_type" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT 'deploy'::character varying,
  "develop_mode" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "deploy_mode" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "create_time" timestamptz(6),
  "update_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_console_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_console_config" ("id", "config_type", "develop_mode", "deploy_mode", "create_time", "update_time") VALUES (1, 'deploy', 'release', 'public', '2023-06-01 18:39:23.793025+08', '2023-06-01 18:39:23.793025+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_corp
-- ----------------------------
DROP TABLE IF EXISTS "tb_corp";
CREATE TABLE "tb_corp" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_corp"."id" IS '租户id';
COMMENT ON COLUMN "tb_corp"."name" IS '租户名';
COMMENT ON TABLE "tb_corp" IS '租户表';

-- ----------------------------
-- Records of tb_corp
-- ----------------------------
BEGIN;
INSERT INTO "tb_corp" ("id", "name", "created_at", "updated_at") VALUES ('2efd2601-d800-48b3-9035-9ed23694ba0f', 'default', '2023-06-01 18:35:59.694618+08', '2023-06-01 18:35:59.694618+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_credential
-- ----------------------------
DROP TABLE IF EXISTS "tb_credential";
CREATE TABLE "tb_credential" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "type" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "secret_data" text COLLATE "pg_catalog"."default" NOT NULL,
  "credential_data" text COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON TABLE "tb_credential" IS '用户凭证表';

-- ----------------------------
-- Records of tb_credential
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ddr_score
-- ----------------------------
DROP TABLE IF EXISTS "tb_ddr_score";
CREATE TABLE "tb_ddr_score" (
  "id" int4 NOT NULL DEFAULT nextval('tb_ddr_score_id_seq'::regclass),
  "indicator_type" int2 NOT NULL,
  "indicator_sub_type" int2,
  "indicator" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "score" int4 NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "type_name" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_ddr_score
-- ----------------------------
BEGIN;
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (124, 2, 1, '1', 3, '', '身份风险类型');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (125, 3, 1, 'qq', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (126, 3, 1, 'wechat', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (127, 3, 1, 'tim', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (128, 3, 1, 'dingtalk', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (129, 3, 1, 'lark', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (130, 3, 1, 'wxwork', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (131, 3, 1, 'mstsc', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (132, 3, 1, 'todesk', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (133, 3, 1, 'sunlogin', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (134, 3, 1, 'teamviewer', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (135, 3, 1, 'baidu_netdisk', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (136, 3, 1, 'ali_netdisk', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (137, 3, 1, 'weiyunapp', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (138, 3, 1, 'flashfxp', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (139, 3, 1, 'usbdisk', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (140, 3, 1, 'git', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (141, 3, 1, 'svn', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (142, 3, 1, 'youdaoyunNote', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (143, 3, 1, 'wizNote', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (144, 3, 1, 'everNote', 5, '', '外发途径');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (145, 3, 2, 'file_compression', 4, '', '数据隐藏');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (146, 3, 2, 'hide_suffix', 4, '', '数据隐藏');
INSERT INTO "tb_ddr_score" ("id", "indicator_type", "indicator_sub_type", "indicator", "score", "corp_id", "type_name") VALUES (147, 3, 1, 'everNote', 5, '', '外发途径');
COMMIT;

-- ----------------------------
-- Table structure for tb_ddr_source
-- ----------------------------
DROP TABLE IF EXISTS "tb_ddr_source";
CREATE TABLE "tb_ddr_source" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "source_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "source_type" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "create_at" timestamptz(6),
  "update_at" timestamptz(6),
  "corp_id" varchar COLLATE "pg_catalog"."default"
)
;
COMMENT ON COLUMN "tb_ddr_source"."id" IS '雪花id';
COMMENT ON COLUMN "tb_ddr_source"."source_name" IS '来源名称';
COMMENT ON COLUMN "tb_ddr_source"."source_type" IS '来源类型枚举(web/git/software)';
COMMENT ON COLUMN "tb_ddr_source"."corp_id" IS '租户id';
COMMENT ON TABLE "tb_ddr_source" IS 'ddr来源表';

-- ----------------------------
-- Records of tb_ddr_source
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ddr_source_git
-- ----------------------------
DROP TABLE IF EXISTS "tb_ddr_source_git";
CREATE TABLE "tb_ddr_source_git" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "git_url" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "source_id" varchar COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ddr_source_git"."id" IS '雪花id';
COMMENT ON COLUMN "tb_ddr_source_git"."git_url" IS '来源名称';
COMMENT ON COLUMN "tb_ddr_source_git"."source_id" IS '来源id';
COMMENT ON TABLE "tb_ddr_source_git" IS 'ddr来源表';

-- ----------------------------
-- Records of tb_ddr_source_git
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ddr_source_software
-- ----------------------------
DROP TABLE IF EXISTS "tb_ddr_source_software";
CREATE TABLE "tb_ddr_source_software" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "software_name" varchar COLLATE "pg_catalog"."default",
  "process_name" varchar COLLATE "pg_catalog"."default",
  "source_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ddr_source_software"."id" IS '雪花id';
COMMENT ON COLUMN "tb_ddr_source_software"."software_name" IS '软件名称';
COMMENT ON COLUMN "tb_ddr_source_software"."process_name" IS '进程名称';
COMMENT ON COLUMN "tb_ddr_source_software"."source_id" IS '来源id';
COMMENT ON TABLE "tb_ddr_source_software" IS 'ddr来源表';

-- ----------------------------
-- Records of tb_ddr_source_software
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ddr_source_web
-- ----------------------------
DROP TABLE IF EXISTS "tb_ddr_source_web";
CREATE TABLE "tb_ddr_source_web" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "url_addr" varchar COLLATE "pg_catalog"."default",
  "url_port" varchar COLLATE "pg_catalog"."default",
  "url_route" varchar COLLATE "pg_catalog"."default",
  "source_id" varchar COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ddr_source_web"."id" IS '雪花id';
COMMENT ON COLUMN "tb_ddr_source_web"."url_addr" IS 'web地址';
COMMENT ON COLUMN "tb_ddr_source_web"."url_port" IS 'web端口';
COMMENT ON COLUMN "tb_ddr_source_web"."url_route" IS 'web路径';
COMMENT ON COLUMN "tb_ddr_source_web"."source_id" IS '来源id';
COMMENT ON TABLE "tb_ddr_source_web" IS 'ddr来源表';

-- ----------------------------
-- Records of tb_ddr_source_web
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_events_history
-- ----------------------------
DROP TABLE IF EXISTS "tb_events_history";
CREATE TABLE "tb_events_history" (
  "id" int4 NOT NULL DEFAULT nextval('tb_events_history_id_seq'::regclass),
  "name" varchar COLLATE "pg_catalog"."default",
  "start_time" timestamptz(6),
  "end_time" timestamptz(6),
  "condition" varchar COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_events_history
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_events_records
-- ----------------------------
DROP TABLE IF EXISTS "tb_events_records";
CREATE TABLE "tb_events_records" (
  "id" int4 NOT NULL DEFAULT nextval('tb_events_records_id_seq'::regclass),
  "risk_grade" int8,
  "event_type" varchar COLLATE "pg_catalog"."default",
  "file_name" varchar COLLATE "pg_catalog"."default",
  "user_name" varchar COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_events_records
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_fake_ip_pool
-- ----------------------------
DROP TABLE IF EXISTS "tb_fake_ip_pool";
CREATE TABLE "tb_fake_ip_pool" (
  "id" int4 NOT NULL DEFAULT nextval('tb_fake_ip_pool_id_seq'::regclass),
  "corp_id" int8 NOT NULL,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "fake_ip_pool" text COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_fake_ip_pool
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_file_type
-- ----------------------------
DROP TABLE IF EXISTS "tb_file_type";
CREATE TABLE "tb_file_type" (
  "id" int4 NOT NULL DEFAULT nextval('tb_file_type_id_seq'::regclass),
  "code" int8,
  "name" varchar COLLATE "pg_catalog"."default",
  "parent_id" int8
)
;

-- ----------------------------
-- Records of tb_file_type
-- ----------------------------
BEGIN;
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (1, 1001, '源代码', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (2, 1002, '办公文档', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (3, 1003, '文本文档', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (4, 1004, '图像文档', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (5, 1005, '音频文档', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (6, 1006, '数据库文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (7, 1007, '视频文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (8, 1008, '邮件文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (9, 1009, '压缩文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (10, 1010, '应用文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (11, 1011, '二进制文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (12, 1013, '设计文件', 0);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (13, 1001001, 'C', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (14, 1001002, 'C#', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (15, 1001003, 'C++', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (16, 1001004, 'CoffeeScript', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (17, 1001005, 'CSS', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (18, 1001006, 'Dart', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (19, 1001007, 'Elixir', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (20, 1001008, 'Go', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (21, 1001009, 'Groovy', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (22, 1001010, 'HTML', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (23, 1001011, 'Java', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (24, 1001012, 'JavaScript', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (25, 1001013, 'Kotlin', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (26, 1001014, 'Objective-C', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (27, 1001015, 'Perl', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (28, 1001016, 'PHP', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (29, 1001017, 'PowerShell', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (30, 1001018, 'Python', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (31, 1001019, 'Ruby', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (32, 1001020, 'Rust', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (33, 1001021, 'Scala', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (34, 1001022, 'Shell', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (35, 1001023, 'Swift', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (36, 1001024, 'TypeScript', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (37, 1001025, 'Sql', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (38, 1001026, 'Bat', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (39, 1001027, 'DM', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (40, 1001028, 'Lua', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (41, 1001029, 'Pascal', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (42, 1001030, 'Tel', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (43, 1001031, 'Asp', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (44, 1001032, 'Aspx', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (45, 1001033, 'Asm', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (46, 1001034, 'Jsp', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (47, 1001035, 'Less', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (48, 1001036, 'Matlab', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (49, 1001037, 'VB', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (50, 1001038, 'VBS', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (51, 1001039, 'Postscript', 1);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (52, 1002001, '演示文稿(Office 念山 WPS,iWork,LotusQasis)', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (53, 1002002, '电子表格(Office,金山 WPS,iWork,LotusQasis,CSV,TSV)', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (54, 1002003, '电子文档(Office,金山 WPS,iWork,LotusQasis,WordPerfect,XPS)', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (55, 1002004, 'PDF', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (56, 1002005, 'FDF', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (57, 1002006, '其他', 2);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (58, 1013001, '虚拟现实', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (59, 1013002, '图片处理软件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (60, 1013003, '排版软件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (61, 1013004, '建筑软件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (62, 1013005, '三维动画软件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (63, 1013006, '工业设计', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (64, 1013007, '原型设计软件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (65, 1013008, 'CAD类', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (66, 1013009, 'FBS导出文件', 12);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (67, 1013001001, 'VRML', 58);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (68, 1013001002, 'Virtue3D Optimizer Compressed 3D Graphic', 58);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (69, 1013002001, 'Photoshop', 59);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (70, 1013003001, 'Adobe illustrator', 60);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (71, 1013003002, 'Coreldraw', 60);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (72, 1013004001, 'Revit', 61);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (73, 1013004002, 'NavisWorks', 61);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (74, 1013005001, 'Maya', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (75, 1013005002, 'Blitz3D', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (76, 1013005003, 'Lightwave 3D', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (77, 1013005004, 'MikuMikuDance', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (78, 1013005005, 'Quick 3D', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (79, 1013005006, 'Rhinoceros', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (80, 1013005007, '3DSMax', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (81, 1013005008, 'Cinema 4D', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (82, 1013005009, '3D通用', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (83, 1013005010, 'Godot Engine', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (84, 1013005011, 'Flatland 文件', 62);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (85, 1013006001, 'Gerber', 63);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (86, 1013006002, 'Alias', 63);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (87, 1013006003, 'PDMS Aveva', 63);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (88, 1013007001, 'Axure', 64);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (89, 1013007002, 'Figma', 64);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (90, 1013007003, 'Adobe XD', 64);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (91, 1013007004, 'Visio', 64);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (92, 1013007005, 'Sketch', 64);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (93, 1013008001, 'Solid Edge', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (94, 1013008002, 'DesignCAD 3D MAX', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (95, 1013008003, 'AutoCAD', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (96, 1013008004, 'Parasolid', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (97, 1013008005, 'SolidWorks', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (98, 1013008006, 'Catia', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (99, 1013008007, 'CAD通用文件', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (100, 1013008008, 'JT文件', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (101, 1013008009, 'ArchiCAD', 65);
INSERT INTO "tb_file_type" ("id", "code", "name", "parent_id") VALUES (102, 1013009001, 'FBS导出文件', 66);
COMMIT;

-- ----------------------------
-- Table structure for tb_identity_provider
-- ----------------------------
DROP TABLE IF EXISTS "tb_identity_provider";
CREATE TABLE "tb_identity_provider" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "type" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "source_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL DEFAULT '0'::character varying,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "avatar" text COLLATE "pg_catalog"."default",
  "enable" bool DEFAULT true,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "is_default" bool DEFAULT false,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_identity_provider"."id" IS '认证服务器id';
COMMENT ON COLUMN "tb_identity_provider"."name" IS '认证服务器名称，租户下名称唯一';
COMMENT ON COLUMN "tb_identity_provider"."type" IS '认证服务器类型';
COMMENT ON COLUMN "tb_identity_provider"."source_id" IS '认证服务器对应的用户来源，为0表示可应用于所有用户';
COMMENT ON COLUMN "tb_identity_provider"."corp_id" IS '租户id';
COMMENT ON TABLE "tb_identity_provider" IS '认证服务器表';

-- ----------------------------
-- Records of tb_identity_provider
-- ----------------------------
BEGIN;
INSERT INTO "tb_identity_provider" ("id", "name", "type", "source_id", "corp_id", "avatar", "enable", "description", "is_default", "created_at", "updated_at") VALUES ('40b115ef-fe57-44fe-9279-bd82af8a56a8', '本地认证服务器', 'local', '859725c5-3404-454e-a4b4-90e5d65c5477', '2efd2601-d800-48b3-9035-9ed23694ba0f', NULL, 't', NULL, 't', '2023-06-01 18:35:59.701756+08', '2023-06-01 18:35:59.701756+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_identity_provider_attribute
-- ----------------------------
DROP TABLE IF EXISTS "tb_identity_provider_attribute";
CREATE TABLE "tb_identity_provider_attribute" (
  "key" text COLLATE "pg_catalog"."default" NOT NULL,
  "value" text COLLATE "pg_catalog"."default",
  "provider_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_identity_provider_attribute
-- ----------------------------
BEGIN;
INSERT INTO "tb_identity_provider_attribute" ("key", "value", "provider_id", "created_at", "updated_at") VALUES ('auth_type', 'password', '40b115ef-fe57-44fe-9279-bd82af8a56a8', '2023-06-01 18:39:22.644163+08', '2023-06-01 18:39:22.644163+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_idp_group_mapper
-- ----------------------------
DROP TABLE IF EXISTS "tb_idp_group_mapper";
CREATE TABLE "tb_idp_group_mapper" (
  "provider_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_idp_group_mapper"."provider_id" IS '认证服务器 id';
COMMENT ON COLUMN "tb_idp_group_mapper"."group_id" IS '顶层目录id';
COMMENT ON TABLE "tb_idp_group_mapper" IS '认证服务器和用户组之间多对多关系的映射中间表';

-- ----------------------------
-- Records of tb_idp_group_mapper
-- ----------------------------
BEGIN;
INSERT INTO "tb_idp_group_mapper" ("provider_id", "group_id", "corp_id", "created_at", "updated_at") VALUES ('40b115ef-fe57-44fe-9279-bd82af8a56a8', 'fee12b7b-a71f-4b16-b28e-c1241adb37d3', '2efd2601-d800-48b3-9035-9ed23694ba0f', '2023-06-01 18:39:22.640684+08', '2023-06-01 18:39:22.640684+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_incident
-- ----------------------------
DROP TABLE IF EXISTS "tb_incident";
CREATE TABLE "tb_incident" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "incident_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "risk_level" int4 NOT NULL,
  "incident_status" int4 NOT NULL,
  "application_id" varchar(255) COLLATE "pg_catalog"."default",
  "application_name" varchar(255) COLLATE "pg_catalog"."default",
  "channel" varchar(255) COLLATE "pg_catalog"."default",
  "strategy_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "strategy_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "user_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "incident_score" int4 NOT NULL,
  "incident_type" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "raw_event_ids" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "event_start_time" int8 NOT NULL,
  "event_end_time" int8 NOT NULL,
  "created_at" timestamptz(6) DEFAULT now(),
  "updated_at" timestamptz(6),
  "agent_info" jsonb NOT NULL,
  "summary_data" jsonb NOT NULL,
  "trace_data" jsonb
)
;
COMMENT ON COLUMN "tb_incident"."id" IS '雪花id主键';
COMMENT ON COLUMN "tb_incident"."incident_name" IS '事件名称';
COMMENT ON COLUMN "tb_incident"."risk_level" IS '严重等级(1-5)';
COMMENT ON COLUMN "tb_incident"."incident_status" IS '事件状态(-1生成中;1未确定;2已确定;3标记允许)';
COMMENT ON COLUMN "tb_incident"."application_id" IS '应用id';
COMMENT ON COLUMN "tb_incident"."application_name" IS '访问应用';
COMMENT ON COLUMN "tb_incident"."channel" IS '外发通道';
COMMENT ON COLUMN "tb_incident"."strategy_id" IS '命中策略ID';
COMMENT ON COLUMN "tb_incident"."strategy_name" IS '命中策略名';
COMMENT ON COLUMN "tb_incident"."user_id" IS '用户id';
COMMENT ON COLUMN "tb_incident"."user_name" IS '用户名';
COMMENT ON COLUMN "tb_incident"."incident_score" IS '风险评分';
COMMENT ON COLUMN "tb_incident"."incident_type" IS '摘要/事件类型(根据类型展示摘要字段)';
COMMENT ON COLUMN "tb_incident"."raw_event_ids" IS '原始事件id数组';
COMMENT ON COLUMN "tb_incident"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_incident"."event_start_time" IS '事件开始时间  unix秒戳';
COMMENT ON COLUMN "tb_incident"."event_end_time" IS '事件结束时间  unix秒戳';
COMMENT ON COLUMN "tb_incident"."created_at" IS '创建时间';
COMMENT ON COLUMN "tb_incident"."updated_at" IS '更新时间';
COMMENT ON COLUMN "tb_incident"."agent_info" IS '用户终端信息';
COMMENT ON COLUMN "tb_incident"."summary_data" IS '摘要数据';
COMMENT ON COLUMN "tb_incident"."trace_data" IS '溯源数据(预留扩展)';
COMMENT ON TABLE "tb_incident" IS '高级事件表';

-- ----------------------------
-- Records of tb_incident
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_module_switch
-- ----------------------------
DROP TABLE IF EXISTS "tb_module_switch";
CREATE TABLE "tb_module_switch" (
  "module_code" int4 NOT NULL,
  "module_switch" bool,
  "create_time" timestamptz(6),
  "update_time" timestamptz(6),
  "corp_id" int8
)
;

-- ----------------------------
-- Records of tb_module_switch
-- ----------------------------
BEGIN;
INSERT INTO "tb_module_switch" ("module_code", "module_switch", "create_time", "update_time", "corp_id") VALUES (2, 'f', NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for tb_opt_resource
-- ----------------------------
DROP TABLE IF EXISTS "tb_opt_resource";
CREATE TABLE "tb_opt_resource" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "resource_type" varchar(36) COLLATE "pg_catalog"."default",
  "opt_type" int4
)
;

-- ----------------------------
-- Records of tb_opt_resource
-- ----------------------------
BEGIN;
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('1', '用户', 'USER', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('2', '用户目录', 'GROUP', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('3', '应用', 'APPLICATION', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('4', '访问策略', 'ACCESS_STRATEGY', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('5', '系统组件', 'APPLIANCE', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('6', '应用组', 'APPLICATION_GROUP', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('7', '用户角色', 'ROLE', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('8', '认证策略', 'AUTHORIZATION_POLICY', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('9', '敏感策略', 'SENSITIVE_STRATEGY', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('10', 'DLP策略', 'ALERT_RULE', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('11', '管理员', 'ADMIN_OPT', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('12', '管理员角色', 'ADMIN_ROLE_OPT', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('13', '删除', 'DELETE', 1);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('14', '修改', 'UPDATE', 1);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('15', '新增', 'CREATE', 1);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('16', '用户风险评分', 'USER_RISK', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('17', 'DLP策略评分', 'DDR_RISK_SCORE', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('18', 'UEBA策略', 'UEBA_STRATEGY', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('19', '敏感元素', 'SENSITIVE_STRATEGY_ELEM', 2);
INSERT INTO "tb_opt_resource" ("id", "name", "resource_type", "opt_type") VALUES ('20', '敏感元素标签', 'SENSITIVE_STRATEGY_ELEM_TAG', 2);
COMMIT;

-- ----------------------------
-- Table structure for tb_risk_level_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_risk_level_config";
CREATE TABLE "tb_risk_level_config" (
  "id" int4 NOT NULL DEFAULT nextval('tb_risk_level_config_id_seq'::regclass),
  "min_score" int8,
  "max_score" int8,
  "risk_level_name" varchar(255) COLLATE "pg_catalog"."default",
  "risk_level" int4
)
;

-- ----------------------------
-- Records of tb_risk_level_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_risk_level_config" ("id", "min_score", "max_score", "risk_level_name", "risk_level") VALUES (26, 1, 1, '信息', 1);
INSERT INTO "tb_risk_level_config" ("id", "min_score", "max_score", "risk_level_name", "risk_level") VALUES (27, 1, 3, '低危', 2);
INSERT INTO "tb_risk_level_config" ("id", "min_score", "max_score", "risk_level_name", "risk_level") VALUES (28, 4, 6, '中危', 3);
INSERT INTO "tb_risk_level_config" ("id", "min_score", "max_score", "risk_level_name", "risk_level") VALUES (29, 7, 9, '高危', 4);
INSERT INTO "tb_risk_level_config" ("id", "min_score", "max_score", "risk_level_name", "risk_level") VALUES (30, 9, -1, '严重', 5);
COMMIT;

-- ----------------------------
-- Table structure for tb_role
-- ----------------------------
DROP TABLE IF EXISTS "tb_role";
CREATE TABLE "tb_role" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "is_all_user" int2,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_role"."id" IS '角色id';
COMMENT ON COLUMN "tb_role"."name" IS '角色名称，租户下角色名唯一';
COMMENT ON COLUMN "tb_role"."description" IS '角色描述';
COMMENT ON COLUMN "tb_role"."corp_id" IS '租户id';
COMMENT ON TABLE "tb_role" IS '角色表';

-- ----------------------------
-- Records of tb_role
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_se_app_relation
-- ----------------------------
DROP TABLE IF EXISTS "tb_se_app_relation";
CREATE TABLE "tb_se_app_relation" (
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "id" int4 NOT NULL DEFAULT nextval('tb_se_app_relation_id_seq'::regclass),
  "app_id" int8,
  "connector_id" int8,
  "se_group_id" varchar COLLATE "pg_catalog"."default",
  "se_id" int8
)
;

-- ----------------------------
-- Records of tb_se_app_relation
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_sensitive_elem_label
-- ----------------------------
DROP TABLE IF EXISTS "tb_sensitive_elem_label";
CREATE TABLE "tb_sensitive_elem_label" (
  "id" int4 NOT NULL DEFAULT nextval('tb_sensitive_elem_label_id_seq'::regclass),
  "name" varchar COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_sensitive_elem_label
-- ----------------------------
BEGIN;
INSERT INTO "tb_sensitive_elem_label" ("id", "name", "create_time") VALUES (1, '2742', '2023-06-01 18:59:04.89058+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_sensitive_element
-- ----------------------------
DROP TABLE IF EXISTS "tb_sensitive_element";
CREATE TABLE "tb_sensitive_element" (
  "id" int4 NOT NULL DEFAULT nextval('tb_sensitive_element_id_seq'::regclass),
  "category" int4 NOT NULL,
  "description" varchar COLLATE "pg_catalog"."default",
  "sensitive_element_name" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "related_count" int8,
  "built_in" int2 NOT NULL,
  "value" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
  "tags" int4[],
  "corp_id" varchar(255) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_sensitive_element
-- ----------------------------
BEGIN;
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (1, 1, NULL, '内部文档关键词', NULL, 1, '{绝密,机密文档,机密资料,机密信息,内部文档,内部数据,内部资料}', NULL, NULL, '2023-06-01 18:39:19.479554+08', '2023-06-01 18:39:19.479554+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (2, 1, NULL, '工资单关键词', NULL, 1, '{年终奖,薪资保密,工资条,工资明细,工资对账单,工资单,个人所得税}', NULL, NULL, '2023-06-01 18:39:19.480776+08', '2023-06-01 18:39:19.480776+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (3, 1, NULL, '财务关键词', NULL, 1, '{申报表,个人所得税,债务拖欠,资本投资,重大借款,债权债务,借款台账,债权转让,损益表,现金流量表,资产负债表,所有者权益表,组织结构调整,融资活动,发行股票,财务报告,税务表,财务预算,盈余报表,融资协议,股权投资协议,上市公告,资产重组,利润表,增值税,营业税,企业所得税}', NULL, NULL, '2023-06-01 18:39:19.481503+08', '2023-06-01 18:39:19.481503+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (4, 1, NULL, '汇报关键词', NULL, 1, '{晋升,年终总结,绩效,述职,汇报,内部分享}', NULL, NULL, '2023-06-01 18:39:19.48217+08', '2023-06-01 18:39:19.48217+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (5, 1, NULL, '简历关键词', NULL, 1, '{技能,工作经验,工作经历,简历,求职,项目经历}', NULL, NULL, '2023-06-01 18:39:19.482861+08', '2023-06-01 18:39:19.482861+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (6, 2, NULL, '公司名称', NULL, 1, '{有限.*?公司}', NULL, NULL, '2023-06-01 18:39:19.48355+08', '2023-06-01 18:39:19.48355+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (7, 2, NULL, '国密文件', NULL, 1, '{"(绝|机|秘)\\s*密\\s*(★|☆)"}', NULL, NULL, '2023-06-01 18:39:19.484203+08', '2023-06-01 18:39:19.484203+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (8, 1, NULL, '案例', NULL, 1, '{案例}', NULL, NULL, '2023-06-01 18:39:19.484843+08', '2023-06-01 18:39:19.484843+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (9, 1, NULL, '项目管理', NULL, 1, '{项目管理}', NULL, NULL, '2023-06-01 18:39:19.486116+08', '2023-06-01 18:39:19.486116+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (10, 1, NULL, '版本修订', NULL, 1, '{版本修订}', NULL, NULL, '2023-06-01 18:39:19.486787+08', '2023-06-01 18:39:19.486787+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (11, 1, NULL, '设计', NULL, 1, '{设计}', NULL, NULL, '2023-06-01 18:39:19.487461+08', '2023-06-01 18:39:19.487461+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (12, 1, NULL, '框架', NULL, 1, '{框架}', NULL, NULL, '2023-06-01 18:39:19.488403+08', '2023-06-01 18:39:19.488403+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (13, 1, NULL, '政策背景', NULL, 1, '{政策背景}', NULL, NULL, '2023-06-01 18:39:19.489085+08', '2023-06-01 18:39:19.489085+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (14, 1, NULL, '竞品分析', NULL, 1, '{竞品分析}', NULL, NULL, '2023-06-01 18:39:19.48975+08', '2023-06-01 18:39:19.48975+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (15, 1, NULL, '产品结构', NULL, 1, '{产品结构}', NULL, NULL, '2023-06-01 18:39:19.490468+08', '2023-06-01 18:39:19.490468+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (16, 1, NULL, '产品介绍', NULL, 1, '{产品介绍}', NULL, NULL, '2023-06-01 18:39:19.491139+08', '2023-06-01 18:39:19.491139+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (17, 1, NULL, '产品优势', NULL, 1, '{产品优势}', NULL, NULL, '2023-06-01 18:39:19.491873+08', '2023-06-01 18:39:19.491873+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (18, 1, NULL, '更新', NULL, 1, '{更新}', NULL, NULL, '2023-06-01 18:39:19.492424+08', '2023-06-01 18:39:19.492424+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (19, 1, NULL, '使用手册', NULL, 1, '{使用手册}', NULL, NULL, '2023-06-01 18:39:19.49299+08', '2023-06-01 18:39:19.49299+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (20, 1, NULL, '使用文档', NULL, 1, '{使用文档}', NULL, NULL, '2023-06-01 18:39:19.49356+08', '2023-06-01 18:39:19.49356+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (21, 1, NULL, '使用说明', NULL, 1, '{使用说明}', NULL, NULL, '2023-06-01 18:39:19.494097+08', '2023-06-01 18:39:19.494097+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (22, 1, NULL, '操作手册', NULL, 1, '{操作手册}', NULL, NULL, '2023-06-01 18:39:19.494654+08', '2023-06-01 18:39:19.494654+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (23, 1, NULL, '操作文档', NULL, 1, '{操作文档}', NULL, NULL, '2023-06-01 18:39:19.495189+08', '2023-06-01 18:39:19.495189+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (24, 1, NULL, '白皮书', NULL, 1, '{白皮书}', NULL, NULL, '2023-06-01 18:39:19.495737+08', '2023-06-01 18:39:19.495737+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (25, 1, NULL, '立项报告', NULL, 1, '{立项报告}', NULL, NULL, '2023-06-01 18:39:19.496289+08', '2023-06-01 18:39:19.496289+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (26, 1, NULL, '立项书', NULL, 1, '{立项书}', NULL, NULL, '2023-06-01 18:39:19.496886+08', '2023-06-01 18:39:19.496886+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (27, 1, NULL, '项目管理计划', NULL, 1, '{项目管理计划}', NULL, NULL, '2023-06-01 18:39:19.497418+08', '2023-06-01 18:39:19.497418+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (28, 1, NULL, '接口', NULL, 1, '{接口}', NULL, NULL, '2023-06-01 18:39:19.498008+08', '2023-06-01 18:39:19.498008+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (29, 1, NULL, '架构', NULL, 1, '{架构}', NULL, NULL, '2023-06-01 18:39:19.498565+08', '2023-06-01 18:39:19.498565+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (30, 1, NULL, '库表关系', NULL, 1, '{库表关系}', NULL, NULL, '2023-06-01 18:39:19.499106+08', '2023-06-01 18:39:19.499106+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (31, 1, NULL, 'ER图', NULL, 1, '{ER图}', NULL, NULL, '2023-06-01 18:39:19.499708+08', '2023-06-01 18:39:19.499708+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (32, 1, NULL, '详细设计', NULL, 1, '{详细设计}', NULL, NULL, '2023-06-01 18:39:19.500253+08', '2023-06-01 18:39:19.500253+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (33, 1, NULL, '算法', NULL, 1, '{算法}', NULL, NULL, '2023-06-01 18:39:19.500801+08', '2023-06-01 18:39:19.500801+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (34, 1, NULL, '产品设计', NULL, 1, '{产品设计}', NULL, NULL, '2023-06-01 18:39:19.501334+08', '2023-06-01 18:39:19.501334+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (35, 1, NULL, '产品算法', NULL, 1, '{产品算法}', NULL, NULL, '2023-06-01 18:39:19.501871+08', '2023-06-01 18:39:19.501871+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (36, 1, NULL, '产品方案', NULL, 1, '{产品方案}', NULL, NULL, '2023-06-01 18:39:19.50241+08', '2023-06-01 18:39:19.50241+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (37, 1, NULL, '测试', NULL, 1, '{测试}', NULL, NULL, '2023-06-01 18:39:19.502994+08', '2023-06-01 18:39:19.502994+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (38, 1, NULL, '需求', NULL, 1, '{需求}', NULL, NULL, '2023-06-01 18:39:19.503557+08', '2023-06-01 18:39:19.503557+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (39, 1, NULL, '排期', NULL, 1, '{排期}', NULL, NULL, '2023-06-01 18:39:19.504094+08', '2023-06-01 18:39:19.504094+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (40, 1, NULL, '迭代', NULL, 1, '{迭代}', NULL, NULL, '2023-06-01 18:39:19.50465+08', '2023-06-01 18:39:19.50465+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (41, 1, NULL, '版本', NULL, 1, '{版本}', NULL, NULL, '2023-06-01 18:39:19.505396+08', '2023-06-01 18:39:19.505396+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (42, 1, NULL, '发布', NULL, 1, '{发布}', NULL, NULL, '2023-06-01 18:39:19.505978+08', '2023-06-01 18:39:19.505978+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (43, 1, NULL, '开发', NULL, 1, '{开发}', NULL, NULL, '2023-06-01 18:39:19.506558+08', '2023-06-01 18:39:19.506558+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (44, 1, NULL, '实现', NULL, 1, '{实现}', NULL, NULL, '2023-06-01 18:39:19.507086+08', '2023-06-01 18:39:19.507086+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (45, 1, NULL, '软著', NULL, 1, '{软著}', NULL, NULL, '2023-06-01 18:39:19.507615+08', '2023-06-01 18:39:19.507615+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (46, 1, NULL, '交底书', NULL, 1, '{交底书}', NULL, NULL, '2023-06-01 18:39:19.508191+08', '2023-06-01 18:39:19.508191+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (47, 1, NULL, '专利', NULL, 1, '{专利}', NULL, NULL, '2023-06-01 18:39:19.508717+08', '2023-06-01 18:39:19.508717+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (48, 1, NULL, '绩效', NULL, 1, '{绩效}', NULL, NULL, '2023-06-01 18:39:19.509267+08', '2023-06-01 18:39:19.509267+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (49, 1, NULL, '第一季度', NULL, 1, '{第一季度}', NULL, NULL, '2023-06-01 18:39:19.509818+08', '2023-06-01 18:39:19.509818+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (50, 1, NULL, '第二季度', NULL, 1, '{第二季度}', NULL, NULL, '2023-06-01 18:39:19.510361+08', '2023-06-01 18:39:19.510361+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (51, 1, NULL, '岗位', NULL, 1, '{岗位}', NULL, NULL, '2023-06-01 18:39:19.510927+08', '2023-06-01 18:39:19.510927+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (52, 1, NULL, '专业', NULL, 1, '{专业}', NULL, NULL, '2023-06-01 18:39:19.511497+08', '2023-06-01 18:39:19.511497+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (53, 1, NULL, '职称', NULL, 1, '{职称}', NULL, NULL, '2023-06-01 18:39:19.512024+08', '2023-06-01 18:39:19.512024+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (54, 1, NULL, '银行卡号', NULL, 1, '{银行卡号}', NULL, NULL, '2023-06-01 18:39:19.512565+08', '2023-06-01 18:39:19.512565+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (55, 1, NULL, '毕业院校', NULL, 1, '{毕业院校}', NULL, NULL, '2023-06-01 18:39:19.513098+08', '2023-06-01 18:39:19.513098+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (56, 1, NULL, '户口', NULL, 1, '{户口}', NULL, NULL, '2023-06-01 18:39:19.513621+08', '2023-06-01 18:39:19.513621+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (57, 1, NULL, '姓名', NULL, 1, '{姓名}', NULL, NULL, '2023-06-01 18:39:19.514148+08', '2023-06-01 18:39:19.514148+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (58, 1, NULL, '工号', NULL, 1, '{工号}', NULL, NULL, '2023-06-01 18:39:19.514682+08', '2023-06-01 18:39:19.514682+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (59, 1, NULL, '年底工资', NULL, 1, '{年底工资}', NULL, NULL, '2023-06-01 18:39:19.515197+08', '2023-06-01 18:39:19.515197+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (60, 1, NULL, '当前工资', NULL, 1, '{当前工资}', NULL, NULL, '2023-06-01 18:39:19.515729+08', '2023-06-01 18:39:19.515729+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (61, 1, NULL, '管理职类', NULL, 1, '{管理职类}', NULL, NULL, '2023-06-01 18:39:19.516268+08', '2023-06-01 18:39:19.516268+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (62, 1, NULL, '专业职类', NULL, 1, '{专业职类}', NULL, NULL, '2023-06-01 18:39:19.516831+08', '2023-06-01 18:39:19.516831+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (63, 1, NULL, '岗级', NULL, 1, '{岗级}', NULL, NULL, '2023-06-01 18:39:19.517353+08', '2023-06-01 18:39:19.517353+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (64, 1, NULL, '日期', NULL, 1, '{日期}', NULL, NULL, '2023-06-01 18:39:19.517868+08', '2023-06-01 18:39:19.517868+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (65, 1, NULL, '付款', NULL, 1, '{付款}', NULL, NULL, '2023-06-01 18:39:19.51838+08', '2023-06-01 18:39:19.51838+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (66, 1, NULL, '交易订单', NULL, 1, '{交易订单}', NULL, NULL, '2023-06-01 18:39:19.519089+08', '2023-06-01 18:39:19.519089+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (67, 1, NULL, '交易记录', NULL, 1, '{交易记录}', NULL, NULL, '2023-06-01 18:39:19.519645+08', '2023-06-01 18:39:19.519645+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (68, 1, NULL, '交易', NULL, 1, '{交易}', NULL, NULL, '2023-06-01 18:39:19.52019+08', '2023-06-01 18:39:19.52019+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (69, 1, NULL, '订单', NULL, 1, '{订单}', NULL, NULL, '2023-06-01 18:39:19.520752+08', '2023-06-01 18:39:19.520752+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (70, 1, NULL, '订单号', NULL, 1, '{订单号}', NULL, NULL, '2023-06-01 18:39:19.521309+08', '2023-06-01 18:39:19.521309+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (71, 1, NULL, '营销方案', NULL, 1, '{营销方案}', NULL, NULL, '2023-06-01 18:39:19.521835+08', '2023-06-01 18:39:19.521835+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (72, 1, NULL, '营销计划', NULL, 1, '{营销计划}', NULL, NULL, '2023-06-01 18:39:19.522389+08', '2023-06-01 18:39:19.522389+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (73, 1, NULL, '活动计划', NULL, 1, '{活动计划}', NULL, NULL, '2023-06-01 18:39:19.522928+08', '2023-06-01 18:39:19.522928+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (74, 1, NULL, '活动预算', NULL, 1, '{活动预算}', NULL, NULL, '2023-06-01 18:39:19.523464+08', '2023-06-01 18:39:19.523464+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (75, 1, NULL, '推送计划', NULL, 1, '{推送计划}', NULL, NULL, '2023-06-01 18:39:19.523998+08', '2023-06-01 18:39:19.523998+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (76, 1, NULL, '甲方', NULL, 1, '{甲方}', NULL, NULL, '2023-06-01 18:39:19.524539+08', '2023-06-01 18:39:19.524539+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (77, 1, NULL, '乙方', NULL, 1, '{乙方}', NULL, NULL, '2023-06-01 18:39:19.525066+08', '2023-06-01 18:39:19.525066+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (78, 1, NULL, '违约', NULL, 1, '{违约}', NULL, NULL, '2023-06-01 18:39:19.525622+08', '2023-06-01 18:39:19.525622+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (79, 1, NULL, '协议', NULL, 1, '{协议}', NULL, NULL, '2023-06-01 18:39:19.526339+08', '2023-06-01 18:39:19.526339+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (80, 1, NULL, '合同', NULL, 1, '{合同}', NULL, NULL, '2023-06-01 18:39:19.52687+08', '2023-06-01 18:39:19.52687+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (81, 1, NULL, '合作', NULL, 1, '{合作}', NULL, NULL, '2023-06-01 18:39:19.527522+08', '2023-06-01 18:39:19.527522+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (82, 1, NULL, '渠道', NULL, 1, '{渠道}', NULL, NULL, '2023-06-01 18:39:19.528111+08', '2023-06-01 18:39:19.528111+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (83, 1, NULL, '推广', NULL, 1, '{推广}', NULL, NULL, '2023-06-01 18:39:19.528761+08', '2023-06-01 18:39:19.528761+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (84, 1, NULL, '投放', NULL, 1, '{投放}', NULL, NULL, '2023-06-01 18:39:19.529323+08', '2023-06-01 18:39:19.529323+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (85, 1, NULL, '记录', NULL, 1, '{记录}', NULL, NULL, '2023-06-01 18:39:19.530026+08', '2023-06-01 18:39:19.530026+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (86, 1, NULL, '方案', NULL, 1, '{方案}', NULL, NULL, '2023-06-01 18:39:19.530596+08', '2023-06-01 18:39:19.530596+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (87, 1, NULL, '营销', NULL, 1, '{营销}', NULL, NULL, '2023-06-01 18:39:19.53122+08', '2023-06-01 18:39:19.53122+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (88, 1, NULL, '广告', NULL, 1, '{广告}', NULL, NULL, '2023-06-01 18:39:19.531842+08', '2023-06-01 18:39:19.531842+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (89, 1, NULL, '毛利净利评估表', NULL, 1, '{毛利净利评估表}', NULL, NULL, '2023-06-01 18:39:19.532475+08', '2023-06-01 18:39:19.532475+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (90, 1, NULL, '产品名称', NULL, 1, '{产品名称}', NULL, NULL, '2023-06-01 18:39:19.533084+08', '2023-06-01 18:39:19.533084+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (91, 1, NULL, '描述', NULL, 1, '{描述}', NULL, NULL, '2023-06-01 18:39:19.533655+08', '2023-06-01 18:39:19.533655+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (92, 1, NULL, '品牌', NULL, 1, '{品牌}', NULL, NULL, '2023-06-01 18:39:19.534235+08', '2023-06-01 18:39:19.534235+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (93, 1, NULL, '型号', NULL, 1, '{型号}', NULL, NULL, '2023-06-01 18:39:19.534932+08', '2023-06-01 18:39:19.534932+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (94, 1, NULL, '单价', NULL, 1, '{单价}', NULL, NULL, '2023-06-01 18:39:19.535572+08', '2023-06-01 18:39:19.535572+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (95, 1, NULL, '投标', NULL, 1, '{投标}', NULL, NULL, '2023-06-01 18:39:19.536166+08', '2023-06-01 18:39:19.536166+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (96, 1, NULL, '销售价', NULL, 1, '{销售价}', NULL, NULL, '2023-06-01 18:39:19.536798+08', '2023-06-01 18:39:19.536798+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (97, 1, NULL, '净利', NULL, 1, '{净利}', NULL, NULL, '2023-06-01 18:39:19.53735+08', '2023-06-01 18:39:19.53735+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (98, 1, NULL, '成本', NULL, 1, '{成本}', NULL, NULL, '2023-06-01 18:39:19.538027+08', '2023-06-01 18:39:19.538027+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (99, 1, NULL, '毛利', NULL, 1, '{毛利}', NULL, NULL, '2023-06-01 18:39:19.53865+08', '2023-06-01 18:39:19.53865+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (100, 1, NULL, '利润', NULL, 1, '{利润}', NULL, NULL, '2023-06-01 18:39:19.53931+08', '2023-06-01 18:39:19.53931+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (101, 1, NULL, '部门', NULL, 1, '{部门}', NULL, NULL, '2023-06-01 18:39:19.539872+08', '2023-06-01 18:39:19.539872+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (102, 1, NULL, '销售', NULL, 1, '{销售}', NULL, NULL, '2023-06-01 18:39:19.540509+08', '2023-06-01 18:39:19.540509+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (103, 1, NULL, '合同名称', NULL, 1, '{合同名称}', NULL, NULL, '2023-06-01 18:39:19.541142+08', '2023-06-01 18:39:19.541142+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (104, 1, NULL, '预计合同额', NULL, 1, '{预计合同额}', NULL, NULL, '2023-06-01 18:39:19.54178+08', '2023-06-01 18:39:19.54178+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (105, 1, NULL, '项目进度', NULL, 1, '{项目进度}', NULL, NULL, '2023-06-01 18:39:19.542429+08', '2023-06-01 18:39:19.542429+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (106, 1, NULL, '项目阶段', NULL, 1, '{项目阶段}', NULL, NULL, '2023-06-01 18:39:19.543049+08', '2023-06-01 18:39:19.543049+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (107, 1, NULL, '项目状态', NULL, 1, '{项目状态}', NULL, NULL, '2023-06-01 18:39:19.543692+08', '2023-06-01 18:39:19.543692+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (108, 1, NULL, '立项时间', NULL, 1, '{立项时间}', NULL, NULL, '2023-06-01 18:39:19.544314+08', '2023-06-01 18:39:19.544314+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (109, 1, NULL, '推进计划', NULL, 1, '{推进计划}', NULL, NULL, '2023-06-01 18:39:19.544947+08', '2023-06-01 18:39:19.544947+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (110, 1, NULL, '状态', NULL, 1, '{状态}', NULL, NULL, '2023-06-01 18:39:19.545593+08', '2023-06-01 18:39:19.545593+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (111, 1, NULL, '负责人', NULL, 1, '{负责人}', NULL, NULL, '2023-06-01 18:39:19.546234+08', '2023-06-01 18:39:19.546234+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (112, 1, NULL, '金额', NULL, 1, '{金额}', NULL, NULL, '2023-06-01 18:39:19.546867+08', '2023-06-01 18:39:19.546867+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (113, 1, NULL, '时间', NULL, 1, '{时间}', NULL, NULL, '2023-06-01 18:39:19.547462+08', '2023-06-01 18:39:19.547462+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (114, 1, NULL, '计划', NULL, 1, '{计划}', NULL, NULL, '2023-06-01 18:39:19.548054+08', '2023-06-01 18:39:19.548054+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (115, 1, NULL, '经营', NULL, 1, '{经营}', NULL, NULL, '2023-06-01 18:39:19.548694+08', '2023-06-01 18:39:19.548694+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (116, 1, NULL, '工程文件', NULL, 1, '{工程文件}', NULL, NULL, '2023-06-01 18:39:19.549275+08', '2023-06-01 18:39:19.549275+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (117, 1, NULL, '项目文件', NULL, 1, '{项目文件}', NULL, NULL, '2023-06-01 18:39:19.549929+08', '2023-06-01 18:39:19.549929+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (118, 1, NULL, '工作方案', NULL, 1, '{工作方案}', NULL, NULL, '2023-06-01 18:39:19.550508+08', '2023-06-01 18:39:19.550508+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (119, 1, NULL, '工作计划', NULL, 1, '{工作计划}', NULL, NULL, '2023-06-01 18:39:19.551283+08', '2023-06-01 18:39:19.551283+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (120, 1, NULL, '技术规范', NULL, 1, '{技术规范}', NULL, NULL, '2023-06-01 18:39:19.551937+08', '2023-06-01 18:39:19.551937+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (121, 1, NULL, '解决方案', NULL, 1, '{解决方案}', NULL, NULL, '2023-06-01 18:39:19.552733+08', '2023-06-01 18:39:19.552733+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (122, 1, NULL, '安全方案', NULL, 1, '{安全方案}', NULL, NULL, '2023-06-01 18:39:19.553355+08', '2023-06-01 18:39:19.553355+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (123, 1, NULL, '设计方案', NULL, 1, '{设计方案}', NULL, NULL, '2023-06-01 18:39:19.553931+08', '2023-06-01 18:39:19.553931+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (124, 1, NULL, '调查报告', NULL, 1, '{调查报告}', NULL, NULL, '2023-06-01 18:39:19.554488+08', '2023-06-01 18:39:19.554488+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (125, 1, NULL, '咨询报告', NULL, 1, '{咨询报告}', NULL, NULL, '2023-06-01 18:39:19.555083+08', '2023-06-01 18:39:19.555083+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (126, 1, NULL, '系统设计说明书', NULL, 1, '{系统设计说明书}', NULL, NULL, '2023-06-01 18:39:19.555734+08', '2023-06-01 18:39:19.555734+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (127, 1, NULL, '项目规划', NULL, 1, '{项目规划}', NULL, NULL, '2023-06-01 18:39:19.556282+08', '2023-06-01 18:39:19.556282+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (128, 1, NULL, '分析报告', NULL, 1, '{分析报告}', NULL, NULL, '2023-06-01 18:39:19.556856+08', '2023-06-01 18:39:19.556856+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (129, 1, NULL, '仅限内参', NULL, 1, '{仅限内参}', NULL, NULL, '2023-06-01 18:39:19.557504+08', '2023-06-01 18:39:19.557504+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (130, 1, NULL, '内部使用', NULL, 1, '{内部使用}', NULL, NULL, '2023-06-01 18:39:19.558087+08', '2023-06-01 18:39:19.558087+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (131, 1, NULL, '内部资料', NULL, 1, '{内部资料}', NULL, NULL, '2023-06-01 18:39:19.558656+08', '2023-06-01 18:39:19.558656+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (132, 1, NULL, '不得扩散', NULL, 1, '{不得扩散}', NULL, NULL, '2023-06-01 18:39:19.559444+08', '2023-06-01 18:39:19.559444+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (133, 1, NULL, '不得外传', NULL, 1, '{不得外传}', NULL, NULL, '2023-06-01 18:39:19.560027+08', '2023-06-01 18:39:19.560027+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (134, 1, NULL, '切勿外传', NULL, 1, '{切勿外传}', NULL, NULL, '2023-06-01 18:39:19.560585+08', '2023-06-01 18:39:19.560585+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (135, 1, NULL, '商密', NULL, 1, '{商密}', NULL, NULL, '2023-06-01 18:39:19.561209+08', '2023-06-01 18:39:19.561209+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (136, 1, NULL, '评分标准', NULL, 1, '{评分标准}', NULL, NULL, '2023-06-01 18:39:19.561788+08', '2023-06-01 18:39:19.561788+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (137, 1, NULL, '投标方案', NULL, 1, '{投标方案}', NULL, NULL, '2023-06-01 18:39:19.562416+08', '2023-06-01 18:39:19.562416+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (138, 1, NULL, '采购成本', NULL, 1, '{采购成本}', NULL, NULL, '2023-06-01 18:39:19.563084+08', '2023-06-01 18:39:19.563084+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (139, 1, NULL, '预算金额', NULL, 1, '{预算金额}', NULL, NULL, '2023-06-01 18:39:19.563679+08', '2023-06-01 18:39:19.563679+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (140, 1, NULL, '招标规范', NULL, 1, '{招标规范}', NULL, NULL, '2023-06-01 18:39:19.564207+08', '2023-06-01 18:39:19.564207+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (141, 1, NULL, '协议书', NULL, 1, '{协议书}', NULL, NULL, '2023-06-01 18:39:19.564732+08', '2023-06-01 18:39:19.564732+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (142, 1, NULL, '不含税', NULL, 1, '{不含税}', NULL, NULL, '2023-06-01 18:39:19.565488+08', '2023-06-01 18:39:19.565488+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (143, 1, NULL, '税额', NULL, 1, '{税额}', NULL, NULL, '2023-06-01 18:39:19.56601+08', '2023-06-01 18:39:19.56601+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (144, 1, NULL, '承诺', NULL, 1, '{承诺}', NULL, NULL, '2023-06-01 18:39:19.56663+08', '2023-06-01 18:39:19.56663+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (145, 1, NULL, '生效', NULL, 1, '{生效}', NULL, NULL, '2023-06-01 18:39:19.567208+08', '2023-06-01 18:39:19.567208+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (146, 1, NULL, '双方签字', NULL, 1, '{双方签字}', NULL, NULL, '2023-06-01 18:39:19.567827+08', '2023-06-01 18:39:19.567827+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (147, 1, NULL, '采购', NULL, 1, '{采购}', NULL, NULL, '2023-06-01 18:39:19.568403+08', '2023-06-01 18:39:19.568403+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (148, 1, NULL, '法律', NULL, 1, '{法律}', NULL, NULL, '2023-06-01 18:39:19.569023+08', '2023-06-01 18:39:19.569023+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (149, 1, NULL, '签订', NULL, 1, '{签订}', NULL, NULL, '2023-06-01 18:39:19.569639+08', '2023-06-01 18:39:19.569639+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (150, 1, NULL, '签章', NULL, 1, '{签章}', NULL, NULL, '2023-06-01 18:39:19.570202+08', '2023-06-01 18:39:19.570202+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (151, 1, NULL, '其他', NULL, 1, '{其他}', NULL, NULL, '2023-06-01 18:39:19.570794+08', '2023-06-01 18:39:19.570794+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (152, 1, NULL, '意向书', NULL, 1, '{意向书}', NULL, NULL, '2023-06-01 18:39:19.571387+08', '2023-06-01 18:39:19.571387+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (153, 1, NULL, '报价', NULL, 1, '{报价}', NULL, NULL, '2023-06-01 18:39:19.571938+08', '2023-06-01 18:39:19.571938+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (154, 1, NULL, '刊例价', NULL, 1, '{刊例价}', NULL, NULL, '2023-06-01 18:39:19.57253+08', '2023-06-01 18:39:19.57253+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (155, 1, NULL, '报价单', NULL, 1, '{报价单}', NULL, NULL, '2023-06-01 18:39:19.573081+08', '2023-06-01 18:39:19.573081+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (156, 1, NULL, '报价表', NULL, 1, '{报价表}', NULL, NULL, '2023-06-01 18:39:19.573649+08', '2023-06-01 18:39:19.573649+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (157, 1, NULL, '有效期', NULL, 1, '{有效期}', NULL, NULL, '2023-06-01 18:39:19.574383+08', '2023-06-01 18:39:19.574383+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (158, 1, NULL, '总金额', NULL, 1, '{总金额}', NULL, NULL, '2023-06-01 18:39:19.575042+08', '2023-06-01 18:39:19.575042+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (159, 1, NULL, '总价', NULL, 1, '{总价}', NULL, NULL, '2023-06-01 18:39:19.575615+08', '2023-06-01 18:39:19.575615+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (160, 1, NULL, '标书', NULL, 1, '{标书}', NULL, NULL, '2023-06-01 18:39:19.576185+08', '2023-06-01 18:39:19.576185+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (161, 1, NULL, '客户等级', NULL, 1, '{客户等级}', NULL, NULL, '2023-06-01 18:39:19.576749+08', '2023-06-01 18:39:19.576749+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (162, 1, NULL, '公司地址', NULL, 1, '{公司地址}', NULL, NULL, '2023-06-01 18:39:19.577327+08', '2023-06-01 18:39:19.577327+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (163, 1, NULL, '联系人', NULL, 1, '{联系人}', NULL, NULL, '2023-06-01 18:39:19.577943+08', '2023-06-01 18:39:19.577943+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (164, 1, NULL, '联系方式', NULL, 1, '{联系方式}', NULL, NULL, '2023-06-01 18:39:19.579805+08', '2023-06-01 18:39:19.579805+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (165, 1, NULL, '供应商', NULL, 1, '{供应商}', NULL, NULL, '2023-06-01 18:39:19.580373+08', '2023-06-01 18:39:19.580373+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (166, 1, NULL, '采购编号', NULL, 1, '{采购编号}', NULL, NULL, '2023-06-01 18:39:19.581111+08', '2023-06-01 18:39:19.581111+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (167, 1, NULL, '项目编号', NULL, 1, '{项目编号}', NULL, NULL, '2023-06-01 18:39:19.581819+08', '2023-06-01 18:39:19.581819+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (168, 1, NULL, '厂家', NULL, 1, '{厂家}', NULL, NULL, '2023-06-01 18:39:19.582461+08', '2023-06-01 18:39:19.582461+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (169, 1, NULL, '项目名称', NULL, 1, '{项目名称}', NULL, NULL, '2023-06-01 18:39:19.583094+08', '2023-06-01 18:39:19.583094+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (170, 1, NULL, 'OA', NULL, 1, '{OA}', NULL, NULL, '2023-06-01 18:39:19.583676+08', '2023-06-01 18:39:19.583676+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (171, 1, NULL, '技术要求', NULL, 1, '{技术要求}', NULL, NULL, '2023-06-01 18:39:19.584309+08', '2023-06-01 18:39:19.584309+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (172, 1, NULL, '技术需求', NULL, 1, '{技术需求}', NULL, NULL, '2023-06-01 18:39:19.584905+08', '2023-06-01 18:39:19.584905+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (173, 1, NULL, '评分办法', NULL, 1, '{评分办法}', NULL, NULL, '2023-06-01 18:39:19.585513+08', '2023-06-01 18:39:19.585513+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (174, 1, NULL, '评标办法', NULL, 1, '{评标办法}', NULL, NULL, '2023-06-01 18:39:19.586106+08', '2023-06-01 18:39:19.586106+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (175, 1, NULL, '商务分', NULL, 1, '{商务分}', NULL, NULL, '2023-06-01 18:39:19.586722+08', '2023-06-01 18:39:19.586722+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (176, 1, NULL, '价格分', NULL, 1, '{价格分}', NULL, NULL, '2023-06-01 18:39:19.587314+08', '2023-06-01 18:39:19.587314+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (177, 1, NULL, '技术分', NULL, 1, '{技术分}', NULL, NULL, '2023-06-01 18:39:19.588048+08', '2023-06-01 18:39:19.588048+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (178, 1, NULL, '分值', NULL, 1, '{分值}', NULL, NULL, '2023-06-01 18:39:19.588681+08', '2023-06-01 18:39:19.588681+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (179, 1, NULL, '参数', NULL, 1, '{参数}', NULL, NULL, '2023-06-01 18:39:19.589276+08', '2023-06-01 18:39:19.589276+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (180, 1, NULL, '招标', NULL, 1, '{招标}', NULL, NULL, '2023-06-01 18:39:19.589893+08', '2023-06-01 18:39:19.589893+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (181, 1, NULL, '产品清单', NULL, 1, '{产品清单}', NULL, NULL, '2023-06-01 18:39:19.590465+08', '2023-06-01 18:39:19.590465+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (182, 1, NULL, '产品目录', NULL, 1, '{产品目录}', NULL, NULL, '2023-06-01 18:39:19.591067+08', '2023-06-01 18:39:19.591067+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (183, 1, NULL, '编码', NULL, 1, '{编码}', NULL, NULL, '2023-06-01 18:39:19.59165+08', '2023-06-01 18:39:19.59165+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (184, 1, NULL, '名称', NULL, 1, '{名称}', NULL, NULL, '2023-06-01 18:39:19.592273+08', '2023-06-01 18:39:19.592273+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (185, 1, NULL, '分类', NULL, 1, '{分类}', NULL, NULL, '2023-06-01 18:39:19.592886+08', '2023-06-01 18:39:19.592886+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (186, 1, NULL, '序号', NULL, 1, '{序号}', NULL, NULL, '2023-06-01 18:39:19.593585+08', '2023-06-01 18:39:19.593585+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (187, 1, NULL, '数量', NULL, 1, '{数量}', NULL, NULL, '2023-06-01 18:39:19.59421+08', '2023-06-01 18:39:19.59421+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (188, 1, NULL, '规格', NULL, 1, '{规格}', NULL, NULL, '2023-06-01 18:39:19.594844+08', '2023-06-01 18:39:19.594844+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (189, 1, NULL, '客户名称', NULL, 1, '{客户名称}', NULL, NULL, '2023-06-01 18:39:19.59549+08', '2023-06-01 18:39:19.59549+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (190, 1, NULL, '优先级', NULL, 1, '{优先级}', NULL, NULL, '2023-06-01 18:39:19.596227+08', '2023-06-01 18:39:19.596227+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (191, 1, NULL, '健康度', NULL, 1, '{健康度}', NULL, NULL, '2023-06-01 18:39:19.596957+08', '2023-06-01 18:39:19.596957+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (192, 1, NULL, '阶段', NULL, 1, '{阶段}', NULL, NULL, '2023-06-01 18:39:19.597538+08', '2023-06-01 18:39:19.597538+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (193, 1, NULL, '反馈', NULL, 1, '{反馈}', NULL, NULL, '2023-06-01 18:39:19.59817+08', '2023-06-01 18:39:19.59817+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (194, 1, NULL, '董事', NULL, 1, '{董事}', NULL, NULL, '2023-06-01 18:39:19.5988+08', '2023-06-01 18:39:19.5988+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (195, 1, NULL, '财务指标', NULL, 1, '{财务指标}', NULL, NULL, '2023-06-01 18:39:19.599404+08', '2023-06-01 18:39:19.599404+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (196, 1, NULL, '股份', NULL, 1, '{股份}', NULL, NULL, '2023-06-01 18:39:19.600116+08', '2023-06-01 18:39:19.600116+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (197, 1, NULL, '股东', NULL, 1, '{股东}', NULL, NULL, '2023-06-01 18:39:19.600719+08', '2023-06-01 18:39:19.600719+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (198, 1, NULL, '股票', NULL, 1, '{股票}', NULL, NULL, '2023-06-01 18:39:19.601365+08', '2023-06-01 18:39:19.601365+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (199, 1, NULL, '净利润', NULL, 1, '{净利润}', NULL, NULL, '2023-06-01 18:39:19.601983+08', '2023-06-01 18:39:19.601983+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (200, 1, NULL, '经营活动', NULL, 1, '{经营活动}', NULL, NULL, '2023-06-01 18:39:19.602563+08', '2023-06-01 18:39:19.602563+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (201, 1, NULL, '股本', NULL, 1, '{股本}', NULL, NULL, '2023-06-01 18:39:19.603299+08', '2023-06-01 18:39:19.603299+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (202, 1, NULL, '每股收益', NULL, 1, '{每股收益}', NULL, NULL, '2023-06-01 18:39:19.603861+08', '2023-06-01 18:39:19.603861+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (203, 1, NULL, '年度报告', NULL, 1, '{年度报告}', NULL, NULL, '2023-06-01 18:39:19.604571+08', '2023-06-01 18:39:19.604571+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (204, 1, NULL, '季度报告', NULL, 1, '{季度报告}', NULL, NULL, '2023-06-01 18:39:19.60518+08', '2023-06-01 18:39:19.60518+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (205, 1, NULL, '半年报告', NULL, 1, '{半年报告}', NULL, NULL, '2023-06-01 18:39:19.605838+08', '2023-06-01 18:39:19.605838+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (206, 1, NULL, '财务报表', NULL, 1, '{财务报表}', NULL, NULL, '2023-06-01 18:39:19.606487+08', '2023-06-01 18:39:19.606487+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (207, 1, NULL, '主营业务', NULL, 1, '{主营业务}', NULL, NULL, '2023-06-01 18:39:19.607079+08', '2023-06-01 18:39:19.607079+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (208, 1, NULL, '偿债能力', NULL, 1, '{偿债能力}', NULL, NULL, '2023-06-01 18:39:19.607739+08', '2023-06-01 18:39:19.607739+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (209, 1, NULL, '盈利能力', NULL, 1, '{盈利能力}', NULL, NULL, '2023-06-01 18:39:19.608332+08', '2023-06-01 18:39:19.608332+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (210, 1, NULL, '营运能力', NULL, 1, '{营运能力}', NULL, NULL, '2023-06-01 18:39:19.609103+08', '2023-06-01 18:39:19.609103+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (211, 1, NULL, '财务分析', NULL, 1, '{财务分析}', NULL, NULL, '2023-06-01 18:39:19.609729+08', '2023-06-01 18:39:19.609729+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (212, 1, NULL, '收入', NULL, 1, '{收入}', NULL, NULL, '2023-06-01 18:39:19.610385+08', '2023-06-01 18:39:19.610385+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (213, 1, NULL, '资产', NULL, 1, '{资产}', NULL, NULL, '2023-06-01 18:39:19.61101+08', '2023-06-01 18:39:19.61101+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (214, 1, NULL, '负债', NULL, 1, '{负债}', NULL, NULL, '2023-06-01 18:39:19.611742+08', '2023-06-01 18:39:19.611742+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (215, 1, NULL, '税', NULL, 1, '{税}', NULL, NULL, '2023-06-01 18:39:19.612293+08', '2023-06-01 18:39:19.612293+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (216, 1, NULL, '说明', NULL, 1, '{说明}', NULL, NULL, '2023-06-01 18:39:19.612914+08', '2023-06-01 18:39:19.612914+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (217, 1, NULL, '元', NULL, 1, '{元}', NULL, NULL, '2023-06-01 18:39:19.6135+08', '2023-06-01 18:39:19.6135+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (218, 1, NULL, '报告', NULL, 1, '{报告}', NULL, NULL, '2023-06-01 18:39:19.614085+08', '2023-06-01 18:39:19.614085+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (219, 1, NULL, '总额', NULL, 1, '{总额}', NULL, NULL, '2023-06-01 18:39:19.614688+08', '2023-06-01 18:39:19.614688+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (220, 1, NULL, '效率', NULL, 1, '{效率}', NULL, NULL, '2023-06-01 18:39:19.615448+08', '2023-06-01 18:39:19.615448+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (221, 1, NULL, '费用', NULL, 1, '{费用}', NULL, NULL, '2023-06-01 18:39:19.616026+08', '2023-06-01 18:39:19.616026+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (222, 1, NULL, '固定资产', NULL, 1, '{固定资产}', NULL, NULL, '2023-06-01 18:39:19.61657+08', '2023-06-01 18:39:19.61657+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (223, 1, NULL, '经费', NULL, 1, '{经费}', NULL, NULL, '2023-06-01 18:39:19.617157+08', '2023-06-01 18:39:19.617157+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (224, 1, NULL, '单位', NULL, 1, '{单位}', NULL, NULL, '2023-06-01 18:39:19.617861+08', '2023-06-01 18:39:19.617861+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (225, 1, NULL, '指标', NULL, 1, '{指标}', NULL, NULL, '2023-06-01 18:39:19.618625+08', '2023-06-01 18:39:19.618625+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (226, 1, NULL, '预算指标', NULL, 1, '{预算指标}', NULL, NULL, '2023-06-01 18:39:19.619172+08', '2023-06-01 18:39:19.619172+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (227, 1, NULL, '纳税人识别号', NULL, 1, '{纳税人识别号}', NULL, NULL, '2023-06-01 18:39:19.619803+08', '2023-06-01 18:39:19.619803+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (228, 1, NULL, '应税项目', NULL, 1, '{应税项目}', NULL, NULL, '2023-06-01 18:39:19.620548+08', '2023-06-01 18:39:19.620548+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (229, 1, NULL, '应税税额', NULL, 1, '{应税税额}', NULL, NULL, '2023-06-01 18:39:19.621132+08', '2023-06-01 18:39:19.621132+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (230, 1, NULL, '税务机关', NULL, 1, '{税务机关}', NULL, NULL, '2023-06-01 18:39:19.621831+08', '2023-06-01 18:39:19.621831+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (231, 1, NULL, '银行密码', NULL, 1, '{银行密码}', NULL, NULL, '2023-06-01 18:39:19.622487+08', '2023-06-01 18:39:19.622487+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (232, 1, NULL, '会议纪要', NULL, 1, '{会议纪要}', NULL, NULL, '2023-06-01 18:39:19.623108+08', '2023-06-01 18:39:19.623108+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (233, 1, NULL, '统计数据', NULL, 1, '{统计数据}', NULL, NULL, '2023-06-01 18:39:19.62377+08', '2023-06-01 18:39:19.62377+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (234, 1, NULL, '财务预算', NULL, 1, '{财务预算}', NULL, NULL, '2023-06-01 18:39:19.624556+08', '2023-06-01 18:39:19.624556+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (235, 1, NULL, '预算', NULL, 1, '{预算}', NULL, NULL, '2023-06-01 18:39:19.625143+08', '2023-06-01 18:39:19.625143+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (236, 1, NULL, '策划方案', NULL, 1, '{策划方案}', NULL, NULL, '2023-06-01 18:39:19.625863+08', '2023-06-01 18:39:19.625863+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (237, 1, NULL, '分析报表', NULL, 1, '{分析报表}', NULL, NULL, '2023-06-01 18:39:19.626459+08', '2023-06-01 18:39:19.626459+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (238, 1, NULL, '销售交易', NULL, 1, '{销售交易}', NULL, NULL, '2023-06-01 18:39:19.62701+08', '2023-06-01 18:39:19.62701+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (239, 1, NULL, '自营业务', NULL, 1, '{自营业务}', NULL, NULL, '2023-06-01 18:39:19.627619+08', '2023-06-01 18:39:19.627619+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (240, 1, NULL, '研究报告', NULL, 1, '{研究报告}', NULL, NULL, '2023-06-01 18:39:19.628257+08', '2023-06-01 18:39:19.628257+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (241, 1, NULL, '工资单', NULL, 1, '{工资单}', NULL, NULL, '2023-06-01 18:39:19.628815+08', '2023-06-01 18:39:19.628815+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (242, 1, NULL, '工资表', NULL, 1, '{工资表}', NULL, NULL, '2023-06-01 18:39:19.62947+08', '2023-06-01 18:39:19.62947+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (243, 1, NULL, '工资', NULL, 1, '{工资}', NULL, NULL, '2023-06-01 18:39:19.630011+08', '2023-06-01 18:39:19.630011+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (244, 1, NULL, '董事会决议', NULL, 1, '{董事会决议}', NULL, NULL, '2023-06-01 18:39:19.630585+08', '2023-06-01 18:39:19.630585+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (245, 1, NULL, '存折帐号', NULL, 1, '{存折帐号}', NULL, NULL, '2023-06-01 18:39:19.631169+08', '2023-06-01 18:39:19.631169+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (246, 1, NULL, '储蓄卡', NULL, 1, '{储蓄卡}', NULL, NULL, '2023-06-01 18:39:19.631881+08', '2023-06-01 18:39:19.631881+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (247, 1, NULL, '贷记卡', NULL, 1, '{贷记卡}', NULL, NULL, '2023-06-01 18:39:19.632463+08', '2023-06-01 18:39:19.632463+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (248, 1, NULL, '准贷记卡', NULL, 1, '{准贷记卡}', NULL, NULL, '2023-06-01 18:39:19.633091+08', '2023-06-01 18:39:19.633091+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (249, 1, NULL, '公积金帐号', NULL, 1, '{公积金帐号}', NULL, NULL, '2023-06-01 18:39:19.633685+08', '2023-06-01 18:39:19.633685+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (250, 1, NULL, '对公帐号', NULL, 1, '{对公帐号}', NULL, NULL, '2023-06-01 18:39:19.634431+08', '2023-06-01 18:39:19.634431+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (251, 1, NULL, '内部帐号', NULL, 1, '{内部帐号}', NULL, NULL, '2023-06-01 18:39:19.635071+08', '2023-06-01 18:39:19.635071+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (252, 1, NULL, '资金管理计划', NULL, 1, '{资金管理计划}', NULL, NULL, '2023-06-01 18:39:19.635668+08', '2023-06-01 18:39:19.635668+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (253, 1, NULL, '理财计划', NULL, 1, '{理财计划}', NULL, NULL, '2023-06-01 18:39:19.636351+08', '2023-06-01 18:39:19.636351+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (254, 1, NULL, '借款计划', NULL, 1, '{借款计划}', NULL, NULL, '2023-06-01 18:39:19.637215+08', '2023-06-01 18:39:19.637215+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (255, 1, NULL, '贷款计划', NULL, 1, '{贷款计划}', NULL, NULL, '2023-06-01 18:39:19.637836+08', '2023-06-01 18:39:19.637836+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (256, 1, NULL, '资金动态', NULL, 1, '{资金动态}', NULL, NULL, '2023-06-01 18:39:19.63846+08', '2023-06-01 18:39:19.63846+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (257, 1, NULL, '开户行', NULL, 1, '{开户行}', NULL, NULL, '2023-06-01 18:39:19.639119+08', '2023-06-01 18:39:19.639119+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (258, 1, NULL, '账号', NULL, 1, '{账号}', NULL, NULL, '2023-06-01 18:39:19.639777+08', '2023-06-01 18:39:19.639777+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (259, 1, NULL, '昨日余额', NULL, 1, '{昨日余额}', NULL, NULL, '2023-06-01 18:39:19.640412+08', '2023-06-01 18:39:19.640412+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (260, 1, NULL, '本日收入', NULL, 1, '{本日收入}', NULL, NULL, '2023-06-01 18:39:19.641025+08', '2023-06-01 18:39:19.641025+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (261, 1, NULL, '本日支出', NULL, 1, '{本日支出}', NULL, NULL, '2023-06-01 18:39:19.641591+08', '2023-06-01 18:39:19.641591+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (262, 1, NULL, '本日结余', NULL, 1, '{本日结余}', NULL, NULL, '2023-06-01 18:39:19.642261+08', '2023-06-01 18:39:19.642261+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (263, 1, NULL, '销售额', NULL, 1, '{销售额}', NULL, NULL, '2023-06-01 18:39:19.642864+08', '2023-06-01 18:39:19.642864+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (264, 1, NULL, '税款计算', NULL, 1, '{税款计算}', NULL, NULL, '2023-06-01 18:39:19.64349+08', '2023-06-01 18:39:19.64349+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (265, 1, NULL, '税款缴纳', NULL, 1, '{税款缴纳}', NULL, NULL, '2023-06-01 18:39:19.644106+08', '2023-06-01 18:39:19.644106+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (266, 1, NULL, '增值税', NULL, 1, '{增值税}', NULL, NULL, '2023-06-01 18:39:19.644737+08', '2023-06-01 18:39:19.644737+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (267, 1, NULL, '栏次', NULL, 1, '{栏次}', NULL, NULL, '2023-06-01 18:39:19.645338+08', '2023-06-01 18:39:19.645338+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (268, 1, NULL, '营业收入', NULL, 1, '{营业收入}', NULL, NULL, '2023-06-01 18:39:19.646025+08', '2023-06-01 18:39:19.646025+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (269, 1, NULL, '营业利润', NULL, 1, '{营业利润}', NULL, NULL, '2023-06-01 18:39:19.646621+08', '2023-06-01 18:39:19.646621+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (270, 1, NULL, '利润总额', NULL, 1, '{利润总额}', NULL, NULL, '2023-06-01 18:39:19.647233+08', '2023-06-01 18:39:19.647233+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (271, 1, NULL, '应纳所得税额', NULL, 1, '{应纳所得税额}', NULL, NULL, '2023-06-01 18:39:19.647806+08', '2023-06-01 18:39:19.647806+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (272, 1, NULL, '应补', NULL, 1, '{应补}', NULL, NULL, '2023-06-01 18:39:19.648479+08', '2023-06-01 18:39:19.648479+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (273, 1, NULL, '期末余额', NULL, 1, '{期末余额}', NULL, NULL, '2023-06-01 18:39:19.6492+08', '2023-06-01 18:39:19.6492+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (274, 1, NULL, '年初余额', NULL, 1, '{年初余额}', NULL, NULL, '2023-06-01 18:39:19.649985+08', '2023-06-01 18:39:19.649985+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (275, 1, NULL, '流动负债', NULL, 1, '{流动负债}', NULL, NULL, '2023-06-01 18:39:19.65064+08', '2023-06-01 18:39:19.65064+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (276, 1, NULL, '流动资产', NULL, 1, '{流动资产}', NULL, NULL, '2023-06-01 18:39:19.651256+08', '2023-06-01 18:39:19.651256+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (277, 1, NULL, '行次', NULL, 1, '{行次}', NULL, NULL, '2023-06-01 18:39:19.651876+08', '2023-06-01 18:39:19.651876+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (278, 1, NULL, '发展计划', NULL, 1, '{发展计划}', NULL, NULL, '2023-06-01 18:39:19.652526+08', '2023-06-01 18:39:19.652526+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (279, 1, NULL, '战略规划', NULL, 1, '{战略规划}', NULL, NULL, '2023-06-01 18:39:19.653194+08', '2023-06-01 18:39:19.653194+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (280, 1, NULL, '项目', NULL, 1, '{项目}', NULL, NULL, '2023-06-01 18:39:19.653749+08', '2023-06-01 18:39:19.653749+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (281, 1, NULL, '分析', NULL, 1, '{分析}', NULL, NULL, '2023-06-01 18:39:19.654392+08', '2023-06-01 18:39:19.654392+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (282, 1, NULL, '背景', NULL, 1, '{背景}', NULL, NULL, '2023-06-01 18:39:19.655058+08', '2023-06-01 18:39:19.655058+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (283, 1, NULL, '规划', NULL, 1, '{规划}', NULL, NULL, '2023-06-01 18:39:19.655688+08', '2023-06-01 18:39:19.655688+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (284, 1, NULL, '公司', NULL, 1, '{公司}', NULL, NULL, '2023-06-01 18:39:19.656257+08', '2023-06-01 18:39:19.656257+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (285, 1, NULL, '产品', NULL, 1, '{产品}', NULL, NULL, '2023-06-01 18:39:19.656851+08', '2023-06-01 18:39:19.656851+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (286, 1, NULL, '市场', NULL, 1, '{市场}', NULL, NULL, '2023-06-01 18:39:19.657588+08', '2023-06-01 18:39:19.657588+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (287, 1, NULL, '盈利', NULL, 1, '{盈利}', NULL, NULL, '2023-06-01 18:39:19.658125+08', '2023-06-01 18:39:19.658125+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (288, 1, NULL, '营收', NULL, 1, '{营收}', NULL, NULL, '2023-06-01 18:39:19.658707+08', '2023-06-01 18:39:19.658707+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (289, 1, NULL, '融资计划', NULL, 1, '{融资计划}', NULL, NULL, '2023-06-01 18:39:19.659258+08', '2023-06-01 18:39:19.659258+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (290, 1, NULL, '股权', NULL, 1, '{股权}', NULL, NULL, '2023-06-01 18:39:19.659832+08', '2023-06-01 18:39:19.659832+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (291, 1, NULL, '期权', NULL, 1, '{期权}', NULL, NULL, '2023-06-01 18:39:19.660393+08', '2023-06-01 18:39:19.660393+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (292, 1, NULL, '股权激励', NULL, 1, '{股权激励}', NULL, NULL, '2023-06-01 18:39:19.660934+08', '2023-06-01 18:39:19.660934+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (293, 1, NULL, '期权激励', NULL, 1, '{期权激励}', NULL, NULL, '2023-06-01 18:39:19.661464+08', '2023-06-01 18:39:19.661464+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (294, 1, NULL, '执照', NULL, 1, '{执照}', NULL, NULL, '2023-06-01 18:39:19.662174+08', '2023-06-01 18:39:19.662174+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (295, 1, NULL, '正本', NULL, 1, '{正本}', NULL, NULL, '2023-06-01 18:39:19.662768+08', '2023-06-01 18:39:19.662768+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (296, 1, NULL, '副本', NULL, 1, '{副本}', NULL, NULL, '2023-06-01 18:39:19.663476+08', '2023-06-01 18:39:19.663476+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (297, 1, NULL, '证书', NULL, 1, '{证书}', NULL, NULL, '2023-06-01 18:39:19.664043+08', '2023-06-01 18:39:19.664043+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (298, 1, NULL, '证明', NULL, 1, '{证明}', NULL, NULL, '2023-06-01 18:39:19.66469+08', '2023-06-01 18:39:19.66469+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (299, 1, NULL, '许可证', NULL, 1, '{许可证}', NULL, NULL, '2023-06-01 18:39:19.665326+08', '2023-06-01 18:39:19.665326+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (300, 1, NULL, '基本', NULL, 1, '{基本}', NULL, NULL, '2023-06-01 18:39:19.665949+08', '2023-06-01 18:39:19.665949+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (301, 1, NULL, '实发', NULL, 1, '{实发}', NULL, NULL, '2023-06-01 18:39:19.666521+08', '2023-06-01 18:39:19.666521+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (302, 1, NULL, '加班', NULL, 1, '{加班}', NULL, NULL, '2023-06-01 18:39:19.667146+08', '2023-06-01 18:39:19.667146+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (303, 1, NULL, '总计', NULL, 1, '{总计}', NULL, NULL, '2023-06-01 18:39:19.667725+08', '2023-06-01 18:39:19.667725+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (304, 1, NULL, '公积金', NULL, 1, '{公积金}', NULL, NULL, '2023-06-01 18:39:19.668268+08', '2023-06-01 18:39:19.668268+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (305, 1, NULL, '社保', NULL, 1, '{社保}', NULL, NULL, '2023-06-01 18:39:19.668913+08', '2023-06-01 18:39:19.668913+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (306, 1, NULL, '电话', NULL, 1, '{电话}', NULL, NULL, '2023-06-01 18:39:19.669531+08', '2023-06-01 18:39:19.669531+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (307, 1, NULL, '单位名称', NULL, 1, '{单位名称}', NULL, NULL, '2023-06-01 18:39:19.670396+08', '2023-06-01 18:39:19.670396+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (308, 1, NULL, '地址', NULL, 1, '{地址}', NULL, NULL, '2023-06-01 18:39:19.670973+08', '2023-06-01 18:39:19.670973+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (309, 1, NULL, '身份证', NULL, 1, '{身份证}', NULL, NULL, '2023-06-01 18:39:19.671568+08', '2023-06-01 18:39:19.671568+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (310, 1, NULL, '证件', NULL, 1, '{证件}', NULL, NULL, '2023-06-01 18:39:19.672204+08', '2023-06-01 18:39:19.672204+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (311, 1, NULL, '分机', NULL, 1, '{分机}', NULL, NULL, '2023-06-01 18:39:19.672786+08', '2023-06-01 18:39:19.672786+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (312, 1, NULL, '手机', NULL, 1, '{手机}', NULL, NULL, '2023-06-01 18:39:19.673489+08', '2023-06-01 18:39:19.673489+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (313, 1, NULL, '座机', NULL, 1, '{座机}', NULL, NULL, '2023-06-01 18:39:19.67411+08', '2023-06-01 18:39:19.67411+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (314, 1, NULL, '固话', NULL, 1, '{固话}', NULL, NULL, '2023-06-01 18:39:19.674701+08', '2023-06-01 18:39:19.674701+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (315, 1, NULL, '传真', NULL, 1, '{传真}', NULL, NULL, '2023-06-01 18:39:19.675239+08', '2023-06-01 18:39:19.675239+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (316, 1, NULL, '邮箱', NULL, 1, '{邮箱}', NULL, NULL, '2023-06-01 18:39:19.675846+08', '2023-06-01 18:39:19.675846+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (317, 1, NULL, '电邮', NULL, 1, '{电邮}', NULL, NULL, '2023-06-01 18:39:19.676375+08', '2023-06-01 18:39:19.676375+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (318, 1, NULL, '企邮', NULL, 1, '{企邮}', NULL, NULL, '2023-06-01 18:39:19.676976+08', '2023-06-01 18:39:19.676976+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (319, 1, NULL, '职务', NULL, 1, '{职务}', NULL, NULL, '2023-06-01 18:39:19.677686+08', '2023-06-01 18:39:19.677686+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (320, 1, NULL, '求职', NULL, 1, '{求职}', NULL, NULL, '2023-06-01 18:39:19.678225+08', '2023-06-01 18:39:19.678225+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (321, 1, NULL, '求职简历', NULL, 1, '{求职简历}', NULL, NULL, '2023-06-01 18:39:19.678788+08', '2023-06-01 18:39:19.678788+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (322, 1, NULL, '个人简历', NULL, 1, '{个人简历}', NULL, NULL, '2023-06-01 18:39:19.679368+08', '2023-06-01 18:39:19.679368+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (323, 1, NULL, '职位', NULL, 1, '{职位}', NULL, NULL, '2023-06-01 18:39:19.679949+08', '2023-06-01 18:39:19.679949+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (324, 1, NULL, '个人经验', NULL, 1, '{个人经验}', NULL, NULL, '2023-06-01 18:39:19.680512+08', '2023-06-01 18:39:19.680512+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (325, 1, NULL, '待遇要求', NULL, 1, '{待遇要求}', NULL, NULL, '2023-06-01 18:39:19.681076+08', '2023-06-01 18:39:19.681076+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (326, 1, NULL, '薪金要求', NULL, 1, '{薪金要求}', NULL, NULL, '2023-06-01 18:39:19.68166+08', '2023-06-01 18:39:19.68166+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (327, 1, NULL, '工作经历', NULL, 1, '{工作经历}', NULL, NULL, '2023-06-01 18:39:19.682179+08', '2023-06-01 18:39:19.682179+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (328, 1, NULL, '工作简介', NULL, 1, '{工作简介}', NULL, NULL, '2023-06-01 18:39:19.682695+08', '2023-06-01 18:39:19.682695+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (329, 1, NULL, '求职意向', NULL, 1, '{求职意向}', NULL, NULL, '2023-06-01 18:39:19.683273+08', '2023-06-01 18:39:19.683273+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (330, 1, NULL, '希望薪金', NULL, 1, '{希望薪金}', NULL, NULL, '2023-06-01 18:39:19.68387+08', '2023-06-01 18:39:19.68387+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (331, 1, NULL, '薪金面议', NULL, 1, '{薪金面议}', NULL, NULL, '2023-06-01 18:39:19.684471+08', '2023-06-01 18:39:19.684471+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (332, 1, NULL, '学历', NULL, 1, '{学历}', NULL, NULL, '2023-06-01 18:39:19.685026+08', '2023-06-01 18:39:19.685026+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (333, 1, NULL, '专业技能', NULL, 1, '{专业技能}', NULL, NULL, '2023-06-01 18:39:19.685621+08', '2023-06-01 18:39:19.685621+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (334, 1, NULL, '项目经验', NULL, 1, '{项目经验}', NULL, NULL, '2023-06-01 18:39:19.686178+08', '2023-06-01 18:39:19.686178+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (335, 1, NULL, '职责', NULL, 1, '{职责}', NULL, NULL, '2023-06-01 18:39:19.686701+08', '2023-06-01 18:39:19.686701+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (336, 1, NULL, '自我评价', NULL, 1, '{自我评价}', NULL, NULL, '2023-06-01 18:39:19.687265+08', '2023-06-01 18:39:19.687265+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (337, 1, NULL, '工作年限', NULL, 1, '{工作年限}', NULL, NULL, '2023-06-01 18:39:19.687842+08', '2023-06-01 18:39:19.687842+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (338, 1, NULL, '教育程度', NULL, 1, '{教育程度}', NULL, NULL, '2023-06-01 18:39:19.688405+08', '2023-06-01 18:39:19.688405+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (339, 1, NULL, '婚姻状况', NULL, 1, '{婚姻状况}', NULL, NULL, '2023-06-01 18:39:19.688991+08', '2023-06-01 18:39:19.688991+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (340, 1, NULL, '项目经历', NULL, 1, '{项目经历}', NULL, NULL, '2023-06-01 18:39:19.689548+08', '2023-06-01 18:39:19.689548+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (341, 1, NULL, '个人简介', NULL, 1, '{个人简介}', NULL, NULL, '2023-06-01 18:39:19.690059+08', '2023-06-01 18:39:19.690059+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (342, 1, NULL, 'resume', NULL, 1, '{resume}', NULL, NULL, '2023-06-01 18:39:19.690616+08', '2023-06-01 18:39:19.690616+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (343, 1, NULL, 'University', NULL, 1, '{University}', NULL, NULL, '2023-06-01 18:39:19.691137+08', '2023-06-01 18:39:19.691137+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (344, 1, NULL, 'Major', NULL, 1, '{Major}', NULL, NULL, '2023-06-01 18:39:19.691715+08', '2023-06-01 18:39:19.691715+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (345, 1, NULL, 'Experience', NULL, 1, '{Experience}', NULL, NULL, '2023-06-01 18:39:19.692257+08', '2023-06-01 18:39:19.692257+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (346, 1, NULL, 'Project', NULL, 1, '{Project}', NULL, NULL, '2023-06-01 18:39:19.692857+08', '2023-06-01 18:39:19.692857+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (347, 1, NULL, 'Skill', NULL, 1, '{Skill}', NULL, NULL, '2023-06-01 18:39:19.693399+08', '2023-06-01 18:39:19.693399+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (348, 1, NULL, 'Personal', NULL, 1, '{Personal}', NULL, NULL, '2023-06-01 18:39:19.693976+08', '2023-06-01 18:39:19.693976+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (349, 1, NULL, 'Education', NULL, 1, '{Education}', NULL, NULL, '2023-06-01 18:39:19.694558+08', '2023-06-01 18:39:19.694558+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (350, 1, NULL, 'Evaluation', NULL, 1, '{Evaluation}', NULL, NULL, '2023-06-01 18:39:19.695167+08', '2023-06-01 18:39:19.695167+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (351, 1, NULL, 'Qualifications', NULL, 1, '{Qualifications}', NULL, NULL, '2023-06-01 18:39:19.695746+08', '2023-06-01 18:39:19.695746+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (352, 1, NULL, 'Honors', NULL, 1, '{Honors}', NULL, NULL, '2023-06-01 18:39:19.696343+08', '2023-06-01 18:39:19.696343+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (353, 1, NULL, '通知', NULL, 1, '{通知}', NULL, NULL, '2023-06-01 18:39:19.697135+08', '2023-06-01 18:39:19.697135+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (354, 1, NULL, '公告', NULL, 1, '{公告}', NULL, NULL, '2023-06-01 18:39:19.697948+08', '2023-06-01 18:39:19.697948+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (355, 1, NULL, '通告', NULL, 1, '{通告}', NULL, NULL, '2023-06-01 18:39:19.698581+08', '2023-06-01 18:39:19.698581+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (356, 1, NULL, '密码相关关键词', NULL, 1, '{密码,pass,password}', NULL, NULL, '2023-06-01 18:39:19.69921+08', '2023-06-01 18:39:19.69921+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (357, 1, NULL, '用户名相关关键词', NULL, 1, '{name,user,用户名}', NULL, NULL, '2023-06-01 18:39:19.699826+08', '2023-06-01 18:39:19.699826+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (358, 1, NULL, '手机号相关关键词', NULL, 1, '{phone,mobile,手机号}', NULL, NULL, '2023-06-01 18:39:19.70042+08', '2023-06-01 18:39:19.70042+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (359, 1, NULL, '地址相关关键词', NULL, 1, '{address,addr_,_addr,地址}', NULL, NULL, '2023-06-01 18:39:19.701036+08', '2023-06-01 18:39:19.701036+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (360, 1, NULL, '技术方案', NULL, 1, '{技术方案}', NULL, NULL, '2023-06-01 18:39:19.701688+08', '2023-06-01 18:39:19.701688+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (361, 1, NULL, '软件著作权', NULL, 1, '{软件著作权}', NULL, NULL, '2023-06-01 18:39:19.702257+08', '2023-06-01 18:39:19.702257+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (362, 1, NULL, '系统', NULL, 1, '{系统}', NULL, NULL, '2023-06-01 18:39:19.702836+08', '2023-06-01 18:39:19.702836+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (363, 1, NULL, '软件', NULL, 1, '{软件}', NULL, NULL, '2023-06-01 18:39:19.703448+08', '2023-06-01 18:39:19.703448+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (364, 1, NULL, '制度', NULL, 1, '{制度}', NULL, NULL, '2023-06-01 18:39:19.704016+08', '2023-06-01 18:39:19.704016+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (365, 1, NULL, '制定', NULL, 1, '{制定}', NULL, NULL, '2023-06-01 18:39:19.704582+08', '2023-06-01 18:39:19.704582+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (366, 1, NULL, '管理', NULL, 1, '{管理}', NULL, NULL, '2023-06-01 18:39:19.705246+08', '2023-06-01 18:39:19.705246+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (367, 1, NULL, '目标', NULL, 1, '{目标}', NULL, NULL, '2023-06-01 18:39:19.705844+08', '2023-06-01 18:39:19.705844+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (368, 1, NULL, '规章', NULL, 1, '{规章}', NULL, NULL, '2023-06-01 18:39:19.706535+08', '2023-06-01 18:39:19.706535+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (369, 2, NULL, '包含中文', NULL, 1, '{[一-龥]}', NULL, NULL, '2023-06-01 18:39:19.707082+08', '2023-06-01 18:39:19.707082+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (370, 1, '', 'qwdsa', 0, 2, '{qwdqwd}', '{}', '', '2023-06-01 18:58:18.019919+08', '2023-06-01 18:58:18.019919+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (371, 1, '', 'dqwdqw', 0, 2, '{asdas}', '{}', '', '2023-06-01 18:58:28.01554+08', '2023-06-01 18:58:28.01554+08');
INSERT INTO "tb_sensitive_element" ("id", "category", "description", "sensitive_element_name", "related_count", "built_in", "value", "tags", "corp_id", "created_at", "updated_at") VALUES (372, 1, '', 'dqw', 0, 2, '{dqwdqw}', '{1}', '', '2023-06-01 18:59:10.941919+08', '2023-06-01 18:59:10.941919+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_sensitive_rule_type
-- ----------------------------
DROP TABLE IF EXISTS "tb_sensitive_rule_type";
CREATE TABLE "tb_sensitive_rule_type" (
  "id" int4 NOT NULL DEFAULT nextval('tb_sensitive_rule_type_id_seq'::regclass),
  "name" text COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_sensitive_rule_type
-- ----------------------------
BEGIN;
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (1, '产品项目资料');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (2, '技术研发资料');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (3, '人力资源信息');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (4, '市场运营资料');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (5, '商务合作资料');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (6, '财务信息');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (7, '公司战略资料');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (8, '个人信息');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (9, '通用类');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (10, '政治敏感');
INSERT INTO "tb_sensitive_rule_type" ("id", "name") VALUES (11, '其他');
COMMIT;

-- ----------------------------
-- Table structure for tb_sensitive_strategy
-- ----------------------------
DROP TABLE IF EXISTS "tb_sensitive_strategy";
CREATE TABLE "tb_sensitive_strategy" (
  "id" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "rule_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "sensitive_level" int2,
  "rule_description" varchar(255) COLLATE "pg_catalog"."default",
  "enable" int2 NOT NULL,
  "check_file_suffix" int2,
  "min_file_size" int4,
  "min_file_size_unit" varchar COLLATE "pg_catalog"."default",
  "max_file_size" int4,
  "max_file_size_unit" varchar COLLATE "pg_catalog"."default",
  "corp_id" varchar(64) COLLATE "pg_catalog"."default",
  "file_type_code" int8[] NOT NULL,
  "check_file_encrypted" int2,
  "rule_operator" varchar(255) COLLATE "pg_catalog"."default" DEFAULT 'or'::character varying,
  "filename_operator" varchar(255) COLLATE "pg_catalog"."default" DEFAULT 'or'::character varying,
  "content_operator" varchar(255) COLLATE "pg_catalog"."default" DEFAULT 'or'::character varying,
  "create_at" timestamptz(6),
  "update_at" timestamptz(6),
  "category_id" int4,
  "category" varchar(255) COLLATE "pg_catalog"."default",
  "filename_rule" jsonb,
  "content_rule" jsonb,
  "built_in" int2,
  "source_id" varchar COLLATE "pg_catalog"."default",
  "identify_way" int4[] NOT NULL DEFAULT ARRAY[1]
)
;
COMMENT ON COLUMN "tb_sensitive_strategy"."source_id" IS '来源Id';
COMMENT ON COLUMN "tb_sensitive_strategy"."identify_way" IS '识别方式 1文件来源 2文件名称 3文件类型 4文件大小';

-- ----------------------------
-- Records of tb_sensitive_strategy
-- ----------------------------
BEGIN;
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('1', '设计文件', 4, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1003002,1003003,1003004,1003005,1003006,1003007,1003008}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.982371+08', '2023-06-01 18:39:19.982371+08', 1, '产品项目资料', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('2', '项目管理文档', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.9834+08', '2023-06-01 18:39:19.9834+08', 1, '产品项目资料', '[{"count": 0, "operator": "or", "sensitive_element_codes": [27, 28, 29]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('3', '产品方案', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.984053+08', '2023-06-01 18:39:19.984053+08', 1, '产品项目资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [38]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('4', '产品白皮书', 1, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.984609+08', '2023-06-01 18:39:19.984609+08', 1, '产品项目资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [26]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('5', '产品使用说明', 1, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.985177+08', '2023-06-01 18:39:19.985177+08', 1, '产品项目资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [21]}, {"count": 0, "operator": "and", "sensitive_element_codes": [22]}, {"count": 0, "operator": "and", "sensitive_element_codes": [23]}, {"count": 0, "operator": "and", "sensitive_element_codes": [24]}, {"count": 0, "operator": "and", "sensitive_element_codes": [25]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('6', '加密的源代码压缩包', 4, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1001001,1001002,1001003,1001004,1001008,1001009,1001011,1001012,1001013,1001014,1001015,1001016,1001017,1001018,1001019,1001020,1001021,1001022,1001023,1001024,1001025,1001026,1001028,1001031,1001032,1001033,1001034,1001036,1001037,1001038}', 1, 'or', 'or', 'or', '2023-06-01 18:39:19.985768+08', '2023-06-01 18:39:19.985768+08', 2, '技术研发资料', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('7', '数据库大文件', 4, '', 2, 2, 50, 'mb', 0, 'mb', NULL, '{1006}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.98633+08', '2023-06-01 18:39:19.98633+08', 2, '技术研发资料', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('8', '技术文档', 2, '', 2, 2, 50, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.986893+08', '2023-06-01 18:39:19.986893+08', 2, '技术研发资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [363]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('9', '数据库文件', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1006}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.987487+08', '2023-06-01 18:39:19.987487+08', 2, '技术研发资料', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('10', '测试数据', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1001,1002,1013,1003,1004,1005,1006,1007,1008,1009,1010}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.988043+08', '2023-06-01 18:39:19.988043+08', 2, '技术研发资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [39]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('11', '设计文档及算法', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.988614+08', '2023-06-01 18:39:19.988614+08', 2, '技术研发资料', '[{"count": 0, "operator": "or", "sensitive_element_codes": [36, 37, 38]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('12', '代码文件', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1001001,1001002,1001003,1001004,1001008,1001009,1001011,1001012,1001013,1001014,1001015,1001016,1001017,1001018,1001019,1001020,1001021,1001022,1001023,1001024,1001025,1001026,1001028,1001031,1001032,1001033,1001034,1001036,1001037,1001038}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.989207+08', '2023-06-01 18:39:19.989207+08', 2, '技术研发资料', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('13', '营销方案', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.98984+08', '2023-06-01 18:39:19.98984+08', 4, '市场运营资料', '[{"count": 0, "operator": "or", "sensitive_element_codes": [73, 74]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('14', '活动预案', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.990399+08', '2023-06-01 18:39:19.990399+08', 4, '市场运营资料', '[{"count": 0, "operator": "or", "sensitive_element_codes": [75, 76]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('15', '推送计划', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.990974+08', '2023-06-01 18:39:19.990974+08', 4, '市场运营资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [77]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('16', '投放内容', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.991569+08', '2023-06-01 18:39:19.991569+08', 4, '市场运营资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [86]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('17', '投放记录', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'and', 'or', '2023-06-01 18:39:19.992113+08', '2023-06-01 18:39:19.992113+08', 4, '市场运营资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [86]}, {"count": 0, "operator": "and", "sensitive_element_codes": [87]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('18', '广告设计方案', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'and', 'or', '2023-06-01 18:39:19.992658+08', '2023-06-01 18:39:19.992658+08', 4, '市场运营资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [90]}, {"count": 0, "operator": "and", "sensitive_element_codes": [88]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('19', '广告营销方案', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'and', 'or', '2023-06-01 18:39:19.993203+08', '2023-06-01 18:39:19.993203+08', 4, '市场运营资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [90]}, {"count": 0, "operator": "and", "sensitive_element_codes": [89]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('20', '产品规格说明', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.993861+08', '2023-06-01 18:39:19.993861+08', 5, '商务合作资料', '[{"count": 0, "operator": "and", "sensitive_element_codes": [191]}, {"count": 0, "operator": "and", "sensitive_element_codes": [219]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('21', '固定资产数据表', 4, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.994489+08', '2023-06-01 18:39:19.994489+08', 6, '财务信息', '[{"count": 0, "operator": "and", "sensitive_element_codes": [225]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('22', '隐藏文档', 4, '', 2, 1, 0, 'mb', 0, 'mb', NULL, '{1001,1002,1013,1003,1004,1005,1006,1007,1008,1009,1010}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.995058+08', '2023-06-01 18:39:19.995058+08', 9, '通用类', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('23', '加密文件', 4, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1001,1002,1013,1003,1004,1005,1006,1007,1008,1009,1010}', 1, 'or', 'or', 'or', '2023-06-01 18:39:19.995602+08', '2023-06-01 18:39:19.995602+08', 9, '通用类', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('24', '大文件', 2, '', 2, 2, 100, 'mb', 0, 'mb', NULL, '{1001,1002,1013,1003,1004,1005,1006,1007,1008,1009,1010}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.996143+08', '2023-06-01 18:39:19.996143+08', 9, '通用类', '[{}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('25', '会议纪要', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.996688+08', '2023-06-01 18:39:19.996688+08', 9, '通用类', '[{"count": 0, "operator": "and", "sensitive_element_codes": [235]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('26', '公文通告', 2, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002,1004}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.997621+08', '2023-06-01 18:39:19.997621+08', 9, '通用类', '[{"count": 0, "operator": "or", "sensitive_element_codes": [356, 357, 358]}]', NULL, 1, NULL, '{1}');
INSERT INTO "tb_sensitive_strategy" ("id", "rule_name", "sensitive_level", "rule_description", "enable", "check_file_suffix", "min_file_size", "min_file_size_unit", "max_file_size", "max_file_size_unit", "corp_id", "file_type_code", "check_file_encrypted", "rule_operator", "filename_operator", "content_operator", "create_at", "update_at", "category_id", "category", "filename_rule", "content_rule", "built_in", "source_id", "identify_way") VALUES ('27', '办公文档', 1, '', 2, 2, 0, 'mb', 0, 'mb', NULL, '{1002}', 2, 'or', 'or', 'or', '2023-06-01 18:39:19.99818+08', '2023-06-01 18:39:19.99818+08', 9, '通用类', '[{}]', NULL, 1, NULL, '{1}');
COMMIT;

-- ----------------------------
-- Table structure for tb_special_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_special_config";
CREATE TABLE "tb_special_config" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "type" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "value" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now(),
  "key" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_special_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_special_config" ("id", "type", "value", "created_at", "updated_at", "key") VALUES ('1', 'ADMIN', '3600000000000', '2023-05-09 14:05:43.086+08', '2023-05-09 14:05:43.086+08', 'access_token_duration');
INSERT INTO "tb_special_config" ("id", "type", "value", "created_at", "updated_at", "key") VALUES ('2', 'ADMIN', '86400000000000', '2023-05-09 14:06:51.676+08', '2023-05-09 14:06:51.676+08', 'refresh_token_duration');
INSERT INTO "tb_special_config" ("id", "type", "value", "created_at", "updated_at", "key") VALUES ('3', 'USER', '604800000000000', '2023-05-09 14:56:42.879+08', '2023-05-09 14:56:42.879+08', 'access_token_duration');
INSERT INTO "tb_special_config" ("id", "type", "value", "created_at", "updated_at", "key") VALUES ('4', 'USER', '604800000000000', '2023-05-09 14:56:42.887+08', '2023-05-09 14:56:42.887+08', 'refresh_token_duration');
COMMIT;

-- ----------------------------
-- Table structure for tb_system_version
-- ----------------------------
DROP TABLE IF EXISTS "tb_system_version";
CREATE TABLE "tb_system_version" (
  "id" int4 NOT NULL DEFAULT nextval('tb_system_version_id_seq'::regclass),
  "name" varchar COLLATE "pg_catalog"."default",
  "branch" varchar COLLATE "pg_catalog"."default",
  "version" varchar COLLATE "pg_catalog"."default",
  "package_name" varchar COLLATE "pg_catalog"."default",
  "create_time" timestamptz(6),
  "update_time" timestamptz(6)
)
;

-- ----------------------------
-- Records of tb_system_version
-- ----------------------------
BEGIN;
INSERT INTO "tb_system_version" ("id", "name", "branch", "version", "package_name", "create_time", "update_time") VALUES (1, 'platform', 'release', '1.0.8.0', '1.0.8.0-release_build11(20230601)', '2023-06-01 18:39:23.510986+08', '2023-06-01 18:39:23.510986+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_task_info
-- ----------------------------
DROP TABLE IF EXISTS "tb_task_info";
CREATE TABLE "tb_task_info" (
  "task_id" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "task_name" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "task_type" int8 NOT NULL,
  "task_info" bytea,
  "task_state" int8,
  "agent_module" int8 NOT NULL,
  "user_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_group_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_role_ids" varchar[] COLLATE "pg_catalog"."default",
  "agent_ids" int8[],
  "is_all_user" int8,
  "is_all_agent" int8,
  "create_time" timestamptz(6),
  "update_time" timestamptz(6),
  "corp_id" int8
)
;

-- ----------------------------
-- Records of tb_task_info
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_task_result
-- ----------------------------
DROP TABLE IF EXISTS "tb_task_result";
CREATE TABLE "tb_task_result" (
  "task_id" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "agent_id" int8 NOT NULL,
  "task_state" int8,
  "reason" int8,
  "create_time" timestamptz(6),
  "update_time" timestamptz(6),
  "corp_id" int8
)
;

-- ----------------------------
-- Records of tb_task_result
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ueba_risk_level_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_ueba_risk_level_config";
CREATE TABLE "tb_ueba_risk_level_config" (
  "id" int4 NOT NULL DEFAULT nextval('tb_ueba_risk_level_config_id_seq'::regclass),
  "min_score" int4 NOT NULL,
  "max_score" int4 NOT NULL,
  "risk_level" int4 NOT NULL,
  "risk_level_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ueba_risk_level_config"."id" IS '自增主键id';
COMMENT ON COLUMN "tb_ueba_risk_level_config"."min_score" IS '区间最低分数';
COMMENT ON COLUMN "tb_ueba_risk_level_config"."max_score" IS '区间最高分数 无上限时 约定为-1';
COMMENT ON COLUMN "tb_ueba_risk_level_config"."risk_level" IS '风险等级1-5';
COMMENT ON COLUMN "tb_ueba_risk_level_config"."risk_level_name" IS '风险等级名称';
COMMENT ON COLUMN "tb_ueba_risk_level_config"."corp_id" IS '租户id';
COMMENT ON TABLE "tb_ueba_risk_level_config" IS 'ueba用户风险设置表';

-- ----------------------------
-- Records of tb_ueba_risk_level_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_ueba_risk_level_config" ("id", "min_score", "max_score", "risk_level", "risk_level_name", "corp_id") VALUES (11, 0, 0, 1, '信息', '');
INSERT INTO "tb_ueba_risk_level_config" ("id", "min_score", "max_score", "risk_level", "risk_level_name", "corp_id") VALUES (12, 1, 30, 2, '低风险', '');
INSERT INTO "tb_ueba_risk_level_config" ("id", "min_score", "max_score", "risk_level", "risk_level_name", "corp_id") VALUES (13, 31, 60, 3, '中风险', '');
INSERT INTO "tb_ueba_risk_level_config" ("id", "min_score", "max_score", "risk_level", "risk_level_name", "corp_id") VALUES (14, 61, 90, 4, '高风险', '');
INSERT INTO "tb_ueba_risk_level_config" ("id", "min_score", "max_score", "risk_level", "risk_level_name", "corp_id") VALUES (15, 90, -1, 5, '严重风险', '');
COMMIT;

-- ----------------------------
-- Table structure for tb_ueba_strategy
-- ----------------------------
DROP TABLE IF EXISTS "tb_ueba_strategy";
CREATE TABLE "tb_ueba_strategy" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "built_in" int4 NOT NULL,
  "editable" int4 NOT NULL,
  "enable" int4 NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "user_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_group_ids" varchar[] COLLATE "pg_catalog"."default",
  "channels" varchar[] COLLATE "pg_catalog"."default",
  "channel_types" varchar[] COLLATE "pg_catalog"."default",
  "application_ids" varchar[] COLLATE "pg_catalog"."default",
  "application_group_ids" varchar[] COLLATE "pg_catalog"."default",
  "user_risk_levels" int4[],
  "user_tags_ids" int4[],
  "risk_region_ids" int4[],
  "risk_region_pids" int4[],
  "event_risk_level" int4 NOT NULL,
  "time" jsonb NOT NULL,
  "rule" jsonb,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6),
  "risk_score" int4 NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "rule_extend" jsonb,
  "incident_type" varchar COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ueba_strategy"."id" IS '雪花主键ID';
COMMENT ON COLUMN "tb_ueba_strategy"."built_in" IS '是否内置 1是 2否';
COMMENT ON COLUMN "tb_ueba_strategy"."editable" IS '是否可编辑 1是 2否';
COMMENT ON COLUMN "tb_ueba_strategy"."enable" IS '状态 1启用 2禁用';
COMMENT ON COLUMN "tb_ueba_strategy"."name" IS '规则名称';
COMMENT ON COLUMN "tb_ueba_strategy"."description" IS '规则描述';
COMMENT ON COLUMN "tb_ueba_strategy"."user_ids" IS '生效用户ids(数组)  [“0”]标识所有用户';
COMMENT ON COLUMN "tb_ueba_strategy"."user_group_ids" IS '生效用户分组ids(数组) [“0”]标识所有分组';
COMMENT ON COLUMN "tb_ueba_strategy"."channels" IS '外发通道(数组) [“0”]标识所有分组';
COMMENT ON COLUMN "tb_ueba_strategy"."channel_types" IS '外发通道父级(数组) [“0”]标识所有分组';
COMMENT ON COLUMN "tb_ueba_strategy"."application_ids" IS '生效应用ids';
COMMENT ON COLUMN "tb_ueba_strategy"."application_group_ids" IS '生效应用分组ids';
COMMENT ON COLUMN "tb_ueba_strategy"."user_risk_levels" IS '用户风险ids';
COMMENT ON COLUMN "tb_ueba_strategy"."user_tags_ids" IS '用户标签ids';
COMMENT ON COLUMN "tb_ueba_strategy"."risk_region_ids" IS '风险区域ids';
COMMENT ON COLUMN "tb_ueba_strategy"."risk_region_pids" IS '风险区域父级ids';
COMMENT ON COLUMN "tb_ueba_strategy"."event_risk_level" IS '事件风险等级 (1-5)';
COMMENT ON COLUMN "tb_ueba_strategy"."time" IS '规则生效时间 (前端透传)';
COMMENT ON COLUMN "tb_ueba_strategy"."rule" IS '规则数据 (前端透传)';
COMMENT ON COLUMN "tb_ueba_strategy"."created_at" IS '创建时间';
COMMENT ON COLUMN "tb_ueba_strategy"."updated_at" IS '更新时间';
COMMENT ON COLUMN "tb_ueba_strategy"."risk_score" IS '风险评分';
COMMENT ON COLUMN "tb_ueba_strategy"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_ueba_strategy"."rule_extend" IS '扩展规则';
COMMENT ON COLUMN "tb_ueba_strategy"."incident_type" IS '事件类型';
COMMENT ON TABLE "tb_ueba_strategy" IS 'ueba策略表';

-- ----------------------------
-- Records of tb_ueba_strategy
-- ----------------------------
BEGIN;
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('2', 1, 1, 1, '批量下载', '检测到从组织内部的数据存储系统，下载数据次数和大小超过正常范围，帮助识别内部的可疑行为', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 4, '{"all": 1, "rule": []}', '[{"step_index": 1, "step_operator": "or", "step_condition": [{"condition": [{"id": 1, "name": "send_counts", "value": "50", "window_size": "3600"}, {"id": 2, "name": "send_size", "value": "1073741824", "window_size": "3600"}], "inside_operator": "or"}]}]', '2023-04-03 16:57:35+08', '2023-04-03 16:57:37+08', 8, '0', '{}', 'download');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('7', 1, 1, 1, '批量外发', '检测到通过不可信的数据通道频繁的外发，外发数据次数和大小超过正常范围', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 5, '{"all": 1, "rule": []}', '[{"step_index": 1, "step_operator": "or", "step_condition": [{"condition": [{"id": 1, "name": "send_counts", "value": "5", "window_size": "60"}, {"id": 2, "name": "send_size", "value": "1073741824", "window_size": "3600"}], "inside_operator": "or"}]}]', '2023-03-10 23:23:16.99+08', '2023-03-11 00:23:21.624+08', 15, '0', '{}', 'send');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('6', 1, 1, 1, '批量访问', '识别遍历访问、尝试访问未授权的应用系统', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 4, '{"all": 1, "rule": []}', '[{"step_index": 1, "step_operator": "or", "step_condition": [{"condition": [{"id": 1, "name": "access_fail_counts", "value": "2", "window_size": "360"}], "inside_operator": "or"}]}]', '2023-04-03 17:00:56+08', '2023-04-03 17:00:59+08', 10, '0', '{}', 'access');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('1', 1, 2, 1, '敏感数据外泄', '检测意外或故意的数据外发，识别数据从公司环境转移到个人或非公司应用程序/站点的情况', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 1, '{"all": 1, "rule": []}', '[]', '2023-03-09 16:45:45+08', '2023-03-09 16:45:47+08', 0, '0', '{}', 'sensitive_send');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('4', 1, 2, 1, '离职风险', '识别有离职风险的员工，如频繁的访问招聘网站或更新个人简历', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 2, '{"all": 1, "rule": []}', '[]', '2023-04-03 17:03:25+08', '2023-04-03 17:03:27+08', 5, '0', '{}', 'offer');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('3', 1, 1, 1, '连续登录失败', '识别试图爆破、侵入组织身份账号的行为', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 3, '{"all": 1, "rule": []}', '[{"step_index": 1, "step_operator": "or", "step_condition": [{"condition": [{"id": 1, "name": "login_fail_counts", "value": "5", "window_size": "1800"}], "inside_operator": "or"}]}]', '2023-04-03 17:03:25+08', '2023-04-03 17:03:27+08', 10, '0', '{}', 'login');
INSERT INTO "tb_ueba_strategy" ("id", "built_in", "editable", "enable", "name", "description", "user_ids", "user_group_ids", "channels", "channel_types", "application_ids", "application_group_ids", "user_risk_levels", "user_tags_ids", "risk_region_ids", "risk_region_pids", "event_risk_level", "time", "rule", "created_at", "updated_at", "risk_score", "corp_id", "rule_extend", "incident_type") VALUES ('5', 1, 1, 1, '风险地域登录', '识别从有风险国家、地区进行登录', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{0}', '{}', '{}', '{}', 4, '{"all": 1, "rule": []}', '[]', '2023-03-10 23:23:16.99+08', '2023-03-13 18:23:21.624+08', 10, '0', '{}', 'login');
COMMIT;

-- ----------------------------
-- Table structure for tb_ueba_strategy_condition
-- ----------------------------
DROP TABLE IF EXISTS "tb_ueba_strategy_condition";
CREATE TABLE "tb_ueba_strategy_condition" (
  "id" int4 NOT NULL DEFAULT nextval('tb_ueba_strategy_condition_id_seq1'::regclass),
  "pid" int4 NOT NULL,
  "condition_type" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "condition" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "condition_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL
)
;
COMMENT ON COLUMN "tb_ueba_strategy_condition"."id" IS '自增型ID';
COMMENT ON COLUMN "tb_ueba_strategy_condition"."pid" IS '父ID 0 为顶层';
COMMENT ON COLUMN "tb_ueba_strategy_condition"."condition_type" IS '条件类型(用于减少表) region地域/event事件序列';
COMMENT ON COLUMN "tb_ueba_strategy_condition"."condition" IS '条件英文描述 如 log_fail 对应登录失败';
COMMENT ON COLUMN "tb_ueba_strategy_condition"."condition_name" IS '条件描述 前端展示 如登录失败';
COMMENT ON TABLE "tb_ueba_strategy_condition" IS 'ueba策略条件内置表';

-- ----------------------------
-- Records of tb_ueba_strategy_condition
-- ----------------------------
BEGIN;
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (1, 0, 'risk_region', 'domestic', '国内');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (2, 0, 'risk_region', 'foreign', '国外');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (569, 1, 'risk_region', 'beijing', '北京');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (570, 1, 'risk_region', 'tianjin', '天津');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (571, 1, 'risk_region', 'hebei', '河北');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (572, 1, 'risk_region', 'shanxi', '山西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (573, 1, 'risk_region', 'neimenggu', '内蒙古');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (574, 1, 'risk_region', 'liaoning', '辽宁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (575, 1, 'risk_region', 'jilin', '吉林');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (576, 1, 'risk_region', 'heilongjiang', '黑龙江');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (577, 1, 'risk_region', 'shanghai', '上海');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (578, 1, 'risk_region', 'jiangsu', '江苏');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (579, 1, 'risk_region', 'zhejiang', '浙江');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (580, 1, 'risk_region', 'anhui', '安徽');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (581, 1, 'risk_region', 'fujian', '福建');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (582, 1, 'risk_region', 'jiangxi', '江西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (583, 1, 'risk_region', 'shandong', '山东');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (584, 1, 'risk_region', 'henan', '河南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (585, 1, 'risk_region', 'hubei', '湖北');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (586, 1, 'risk_region', 'hunan', '湖南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (587, 1, 'risk_region', 'guangdong', '广东');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (588, 1, 'risk_region', 'guangxi', '广西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (589, 1, 'risk_region', 'hainan', '海南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (590, 1, 'risk_region', 'chongqing', '重庆');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (591, 1, 'risk_region', 'sichuan', '四川');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (592, 1, 'risk_region', 'guizhou', '贵州');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (593, 1, 'risk_region', 'yunnan', '云南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (594, 1, 'risk_region', 'xizang', '西藏');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (595, 1, 'risk_region', 'shaanxi', '陕西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (596, 1, 'risk_region', 'gansu', '甘肃');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (597, 1, 'risk_region', 'qinghai', '青海');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (598, 1, 'risk_region', 'ningxia', '宁夏');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (599, 1, 'risk_region', 'xinjiang', '新疆');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (600, 1, 'risk_region', 'taiwan', '台湾');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (601, 1, 'risk_region', 'xianggang', '香港');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (602, 1, 'risk_region', 'aomen', '澳门');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (603, 2, 'risk_region', 'aluba', '阿鲁巴');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (604, 2, 'risk_region', 'afuhan', '阿富汗');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (605, 2, 'risk_region', 'angela', '安哥拉');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (606, 2, 'risk_region', 'anguila', '安圭拉');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (607, 2, 'risk_region', 'aolan', '奥兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (608, 2, 'risk_region', 'aerbaniya', '阿尔巴尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (609, 2, 'risk_region', 'andaoer', '安道尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (610, 2, 'risk_region', 'alianqiu', '阿联酋');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (611, 2, 'risk_region', 'agenting', '阿根廷');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (612, 2, 'risk_region', 'yameiniya', '亚美尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (613, 2, 'risk_region', 'meishusamoya', '美属萨摩亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (614, 2, 'risk_region', 'nanjizhou', '南极洲');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (615, 2, 'risk_region', 'fashunanbuhenanjilingdi', '法属南部和南极领地');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (616, 2, 'risk_region', 'antiguahebabuda', '安提瓜和巴布达');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (617, 2, 'risk_region', 'aodaliya', '澳大利亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (618, 2, 'risk_region', 'aodili', '奥地利');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (619, 2, 'risk_region', 'asaibaijiang', '阿塞拜疆');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (620, 2, 'risk_region', 'bulongdi', '布隆迪');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (621, 2, 'risk_region', 'bilishi', '比利时');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (622, 2, 'risk_region', 'beining', '贝宁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (623, 2, 'risk_region', 'helanjialeibiqu', '荷兰加勒比区');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (624, 2, 'risk_region', 'bujinafasuo', '布基纳法索');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (625, 2, 'risk_region', 'mengjialaguo', '孟加拉国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (626, 2, 'risk_region', 'baojialiya', '保加利亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (627, 2, 'risk_region', 'balin', '巴林');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (628, 2, 'risk_region', 'bahama', '巴哈马');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (629, 2, 'risk_region', 'bohei', '波黑');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (630, 2, 'risk_region', 'shengbataileimi', '圣巴泰勒米');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (631, 2, 'risk_region', 'baieluosi', '白俄罗斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (632, 2, 'risk_region', 'bolizi', '伯利兹');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (633, 2, 'risk_region', 'baimuda', '百慕大');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (634, 2, 'risk_region', 'boliweiya', '玻利维亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (635, 2, 'risk_region', 'baxi', '巴西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (636, 2, 'risk_region', 'babaduosi', '巴巴多斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (637, 2, 'risk_region', 'wenlai', '文莱');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (638, 2, 'risk_region', 'budan', '不丹');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (639, 2, 'risk_region', 'buweidao', '布韦岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (640, 2, 'risk_region', 'bociwana', '博茨瓦纳');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (641, 2, 'risk_region', 'zhongfei', '中非');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (642, 2, 'risk_region', 'jianada', '加拿大');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (643, 2, 'risk_region', 'kekesi（jilin）qundao', '科科斯（基林）群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (644, 2, 'risk_region', 'ruishi', '瑞士');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (645, 2, 'risk_region', 'zhili', '智利');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (646, 2, 'risk_region', 'ketediwa', '科特迪瓦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (647, 2, 'risk_region', 'kamailong', '喀麦隆');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (280, 0, 'severity', '1', '信息');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (281, 0, 'severity', '2', '低危');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (282, 0, 'severity', '3', '中危');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (283, 0, 'severity', '4', '高危');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (284, 0, 'severity', '5', '严重');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (648, 2, 'risk_region', 'gangguominzhugongheguo', '刚果民主共和国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (649, 2, 'risk_region', 'gangguogongheguo', '刚果共和国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (650, 2, 'risk_region', 'kukequndao', '库克群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (651, 2, 'risk_region', 'gelunbiya', '哥伦比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (652, 2, 'risk_region', 'kemoluo', '科摩罗');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (653, 2, 'risk_region', 'fudejiao', '佛得角');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (654, 2, 'risk_region', 'gesidalijia', '哥斯达黎加');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (655, 2, 'risk_region', 'guba', '古巴');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (656, 2, 'risk_region', 'kulasuo', '库拉索');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (657, 2, 'risk_region', 'shengdandao', '圣诞岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (658, 2, 'risk_region', 'kaimanqundao', '开曼群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (659, 2, 'risk_region', 'saipulusi', '塞浦路斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (660, 2, 'risk_region', 'jieke', '捷克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (661, 2, 'risk_region', 'deguo', '德国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (662, 2, 'risk_region', 'jibuti', '吉布提');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (663, 2, 'risk_region', 'duominike', '多米尼克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (664, 2, 'risk_region', 'danmai', '丹麦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (665, 2, 'risk_region', 'duominijia', '多米尼加');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (666, 2, 'risk_region', 'aerjiliya', '阿尔及利亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (667, 2, 'risk_region', 'eguaduoer', '厄瓜多尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (668, 2, 'risk_region', 'aiji', '埃及');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (669, 2, 'risk_region', 'eliteliya', '厄立特里亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (670, 2, 'risk_region', 'xisahala', '西撒哈拉');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (671, 2, 'risk_region', 'xibanya', '西班牙');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (672, 2, 'risk_region', 'aishaniya', '爱沙尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (673, 2, 'risk_region', 'aisaiebiya', '埃塞俄比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (674, 2, 'risk_region', 'fenlan', '芬兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (675, 2, 'risk_region', 'feiji', '斐济');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (676, 2, 'risk_region', 'fukelanqundao', '福克兰群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (677, 2, 'risk_region', 'faguo', '法国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (678, 2, 'risk_region', 'faluoqundao', '法罗群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (679, 2, 'risk_region', 'mikeluonixiyalianbang', '密克罗尼西亚联邦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (680, 2, 'risk_region', 'jiapeng', '加蓬');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (681, 2, 'risk_region', 'yingguo', '英国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (682, 2, 'risk_region', 'gelujiya', '格鲁吉亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (683, 2, 'risk_region', 'genxi', '根西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (684, 2, 'risk_region', 'jiana', '加纳');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (685, 2, 'risk_region', 'zhibuluotuo', '直布罗陀');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (686, 2, 'risk_region', 'jineiya', '几内亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (687, 2, 'risk_region', 'guadeluopu', '瓜德罗普');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (688, 2, 'risk_region', 'gangbiya', '冈比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (689, 2, 'risk_region', 'jineiyabishao', '几内亚比绍');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (690, 2, 'risk_region', 'chidaojineiya', '赤道几内亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (691, 2, 'risk_region', 'xila', '希腊');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (692, 2, 'risk_region', 'gelinnada', '格林纳达');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (693, 2, 'risk_region', 'gelinglan', '格陵兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (694, 2, 'risk_region', 'weidimala', '危地马拉');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (695, 2, 'risk_region', 'fashuguiyana', '法属圭亚那');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (696, 2, 'risk_region', 'guandao', '关岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (697, 2, 'risk_region', 'guiyana', '圭亚那');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (698, 2, 'risk_region', 'hededaohemaiketangnaqundao', '赫德岛和麦克唐纳群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (699, 2, 'risk_region', 'hongdoulasi', '洪都拉斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (700, 2, 'risk_region', 'keluodiya', '克罗地亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (701, 2, 'risk_region', 'haidi', '海地');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (702, 2, 'risk_region', 'xiongyali', '匈牙利');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (703, 2, 'risk_region', 'yindunixiya', '印度尼西亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (704, 2, 'risk_region', 'maendao', '马恩岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (705, 2, 'risk_region', 'yindu', '印度');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (706, 2, 'risk_region', 'yingshuyinduyanglingdi', '英属印度洋领地');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (707, 2, 'risk_region', 'aierlan', '爱尔兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (708, 2, 'risk_region', 'yilang', '伊朗');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (709, 2, 'risk_region', 'yilake', '伊拉克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (710, 2, 'risk_region', 'bingdao', '冰岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (711, 2, 'risk_region', 'yiselie', '以色列');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (712, 2, 'risk_region', 'yidali', '意大利');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (713, 2, 'risk_region', 'yamaijia', '牙买加');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (714, 2, 'risk_region', 'zexi', '泽西');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (715, 2, 'risk_region', 'yuedan', '约旦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (716, 2, 'risk_region', 'riben', '日本');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (717, 2, 'risk_region', 'hasakesitan', '哈萨克斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (718, 2, 'risk_region', 'kenniya', '肯尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (719, 2, 'risk_region', 'jierjisisitan', '吉尔吉斯斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (720, 2, 'risk_region', 'jianpuzhai', '柬埔寨');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (721, 2, 'risk_region', 'jilibasi', '基里巴斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (722, 2, 'risk_region', 'shengjiciheniweisi', '圣基茨和尼维斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (723, 2, 'risk_region', 'hanguo', '韩国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (724, 2, 'risk_region', 'keweite', '科威特');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (725, 2, 'risk_region', 'laowo', '老挝');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (726, 2, 'risk_region', 'libanen', '黎巴嫩');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (727, 2, 'risk_region', 'libiliya', '利比里亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (728, 2, 'risk_region', 'libiya', '利比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (729, 2, 'risk_region', 'shengluxiya', '圣卢西亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (730, 2, 'risk_region', 'liezhidunshideng', '列支敦士登');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (731, 2, 'risk_region', 'sililanka', '斯里兰卡');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (732, 2, 'risk_region', 'laisuotuo', '莱索托');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (733, 2, 'risk_region', 'litaowan', '立陶宛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (734, 2, 'risk_region', 'lusenbao', '卢森堡');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (735, 2, 'risk_region', 'latuoweiya', '拉脱维亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (736, 2, 'risk_region', 'fashushengmading', '法属圣马丁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (737, 2, 'risk_region', 'moluoge', '摩洛哥');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (738, 2, 'risk_region', 'monage', '摩纳哥');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (739, 2, 'risk_region', 'moerduowa', '摩尔多瓦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (740, 2, 'risk_region', 'madajiasijia', '马达加斯加');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (741, 2, 'risk_region', 'maerdaifu', '马尔代夫');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (742, 2, 'risk_region', 'moxige', '墨西哥');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (743, 2, 'risk_region', 'mashaoerqundao', '马绍尔群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (744, 2, 'risk_region', 'beimaqidun', '北马其顿');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (745, 2, 'risk_region', 'mali', '马里');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (746, 2, 'risk_region', 'maerta', '马耳他');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (747, 2, 'risk_region', 'miandian', '缅甸');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (748, 2, 'risk_region', 'heishan', '黑山');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (749, 2, 'risk_region', 'menggu', '蒙古');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (750, 2, 'risk_region', 'beimaliyanaqundao', '北马里亚纳群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (751, 2, 'risk_region', 'mosangbike', '莫桑比克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (752, 2, 'risk_region', 'maolitaniya', '毛里塔尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (753, 2, 'risk_region', 'mengtesailate', '蒙特塞拉特');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (754, 2, 'risk_region', 'matinike', '马提尼克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (755, 2, 'risk_region', 'maoliqiusi', '毛里求斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (756, 2, 'risk_region', 'malawei', '马拉维');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (757, 2, 'risk_region', 'malaixiya', '马来西亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (758, 2, 'risk_region', 'mayuete', '马约特');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (759, 2, 'risk_region', 'namibiya', '纳米比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (760, 2, 'risk_region', 'xinkaliduoniya', '新喀里多尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (761, 2, 'risk_region', 'nirier', '尼日尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (762, 2, 'risk_region', 'nuofukedao', '诺福克岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (763, 2, 'risk_region', 'niriliya', '尼日利亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (764, 2, 'risk_region', 'nijialagua', '尼加拉瓜');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (765, 2, 'risk_region', 'niuai', '纽埃');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (766, 2, 'risk_region', 'helan', '荷兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (767, 2, 'risk_region', 'nuowei', '挪威');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (768, 2, 'risk_region', 'nipoer', '尼泊尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (769, 2, 'risk_region', 'naolu', '瑙鲁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (770, 2, 'risk_region', 'xinxilan', '新西兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (771, 2, 'risk_region', 'aman', '阿曼');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (772, 2, 'risk_region', 'bajisitan', '巴基斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (773, 2, 'risk_region', 'banama', '巴拿马');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (774, 2, 'risk_region', 'pitekaienqundao', '皮特凯恩群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (775, 2, 'risk_region', 'bilu', '秘鲁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (776, 2, 'risk_region', 'feilvbin', '菲律宾');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (777, 2, 'risk_region', 'palao', '帕劳');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (778, 2, 'risk_region', 'babuyaxinjineiya', '巴布亚新几内亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (779, 2, 'risk_region', 'bolan', '波兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (780, 2, 'risk_region', 'boduolige', '波多黎各');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (781, 2, 'risk_region', 'chaoxian', '朝鲜');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (782, 2, 'risk_region', 'putaoya', '葡萄牙');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (783, 2, 'risk_region', 'balagui', '巴拉圭');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (784, 2, 'risk_region', 'balesitan', '巴勒斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (785, 2, 'risk_region', 'fashubolinixiya', '法属波利尼西亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (786, 2, 'risk_region', 'kataer', '卡塔尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (787, 2, 'risk_region', 'liuniwang', '留尼汪');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (788, 2, 'risk_region', 'luomaniya', '罗马尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (789, 2, 'risk_region', 'eluosi', '俄罗斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (790, 2, 'risk_region', 'luwangda', '卢旺达');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (791, 2, 'risk_region', 'shatealabo', '沙特阿拉伯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (792, 2, 'risk_region', 'sudan', '苏丹');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (793, 2, 'risk_region', 'saineijiaer', '塞内加尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (794, 2, 'risk_region', 'xinjiapo', '新加坡');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (795, 2, 'risk_region', 'nanqiaozhiyahenansangweiqiqundao', '南乔治亚和南桑威奇群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (796, 2, 'risk_region', 'shengheleina、asensonghetelisitan-dakuniya', '圣赫勒拿、阿森松和特里斯坦-达库尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (797, 2, 'risk_region', 'siwaerbaheyangmayan', '斯瓦尔巴和扬马延');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (798, 2, 'risk_region', 'suoluomenqundao', '所罗门群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (799, 2, 'risk_region', 'sailaliang', '塞拉利昂');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (800, 2, 'risk_region', 'saerwaduo', '萨尔瓦多');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (801, 2, 'risk_region', 'shengmalinuo', '圣马力诺');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (802, 2, 'risk_region', 'suomali', '索马里');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (803, 2, 'risk_region', 'shengpiaierhemikelong', '圣皮埃尔和密克隆');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (804, 2, 'risk_region', 'saierweiya', '塞尔维亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (805, 2, 'risk_region', 'nansudan', '南苏丹');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (806, 2, 'risk_region', 'shengduomeihepulinxibi', '圣多美和普林西比');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (807, 2, 'risk_region', 'sulinan', '苏里南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (808, 2, 'risk_region', 'siluofake', '斯洛伐克');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (809, 2, 'risk_region', 'siluowenniya', '斯洛文尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (810, 2, 'risk_region', 'ruidian', '瑞典');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (811, 2, 'risk_region', 'siweishilan', '斯威士兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (812, 2, 'risk_region', 'heshushengmading', '荷属圣马丁');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (813, 2, 'risk_region', 'saisheer', '塞舌尔');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (814, 2, 'risk_region', 'xuliya', '叙利亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (815, 2, 'risk_region', 'tekesihekaikesiqundao', '特克斯和凯科斯群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (816, 2, 'risk_region', 'zhade', '乍得');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (817, 2, 'risk_region', 'duoge', '多哥');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (818, 2, 'risk_region', 'taiguo', '泰国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (819, 2, 'risk_region', 'tajikesitan', '塔吉克斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (820, 2, 'risk_region', 'tuokelao', '托克劳');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (821, 2, 'risk_region', 'tukumansitan', '土库曼斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (822, 2, 'risk_region', 'dongdiwen', '东帝汶');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (823, 2, 'risk_region', 'tangjia', '汤加');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (824, 2, 'risk_region', 'telinidaheduobage', '特立尼达和多巴哥');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (825, 2, 'risk_region', 'tunisi', '突尼斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (826, 2, 'risk_region', 'tuerqi', '土耳其');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (827, 2, 'risk_region', 'tuwalu', '图瓦卢');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (828, 2, 'risk_region', 'tansangniya', '坦桑尼亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (829, 2, 'risk_region', 'wuganda', '乌干达');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (830, 2, 'risk_region', 'wukelan', '乌克兰');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (831, 2, 'risk_region', 'meiguobentuwaixiaodaoyu', '美国本土外小岛屿');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (832, 2, 'risk_region', 'wulagui', '乌拉圭');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (833, 2, 'risk_region', 'meiguo', '美国');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (834, 2, 'risk_region', 'wuzibiekesitan', '乌兹别克斯坦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (835, 2, 'risk_region', 'fandigang', '梵蒂冈');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (836, 2, 'risk_region', 'shengwensentehegelinnadingsi', '圣文森特和格林纳丁斯');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (837, 2, 'risk_region', 'weineiruila', '委内瑞拉');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (838, 2, 'risk_region', 'yingshuweierjingqundao', '英属维尔京群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (839, 2, 'risk_region', 'meishuweierjingqundao', '美属维尔京群岛');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (840, 2, 'risk_region', 'yuenan', '越南');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (841, 2, 'risk_region', 'wanuatu', '瓦努阿图');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (842, 2, 'risk_region', 'walisihefutuna', '瓦利斯和富图纳');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (843, 2, 'risk_region', 'samoya', '萨摩亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (844, 2, 'risk_region', 'yemen', '也门');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (845, 2, 'risk_region', 'nanfei', '南非');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (846, 2, 'risk_region', 'zanbiya', '赞比亚');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (847, 2, 'risk_region', 'jinbabuwei', '津巴布韦');
INSERT INTO "tb_ueba_strategy_condition" ("id", "pid", "condition_type", "condition", "condition_name") VALUES (4, 3, 'risk_region', 'us', '美国');
COMMIT;

-- ----------------------------
-- Table structure for tb_ueba_user_risk
-- ----------------------------
DROP TABLE IF EXISTS "tb_ueba_user_risk";
CREATE TABLE "tb_ueba_user_risk" (
  "id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "user_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "score_date" date NOT NULL,
  "score" int4 NOT NULL,
  "risk_level" int4 NOT NULL,
  "incident_count" int4 NOT NULL,
  "event_count" int4 NOT NULL,
  "send_file_bytes" int8,
  "send_file_count" int4,
  "download_file_bytes" int8,
  "download_file_count" int4,
  "created_at" timestamptz(6),
  "updated_at" timestamptz(6)
)
;
COMMENT ON COLUMN "tb_ueba_user_risk"."id" IS '雪花ID';
COMMENT ON COLUMN "tb_ueba_user_risk"."user_id" IS '用户ID';
COMMENT ON COLUMN "tb_ueba_user_risk"."user_name" IS '用户名称';
COMMENT ON COLUMN "tb_ueba_user_risk"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_ueba_user_risk"."score_date" IS '评分日期';
COMMENT ON COLUMN "tb_ueba_user_risk"."score" IS '评分';
COMMENT ON COLUMN "tb_ueba_user_risk"."risk_level" IS '风险等级(1~5)';
COMMENT ON COLUMN "tb_ueba_user_risk"."incident_count" IS 'ueba异常事件数(异常数)';
COMMENT ON COLUMN "tb_ueba_user_risk"."event_count" IS '异常事件关联原始事件数(事件数)';
COMMENT ON COLUMN "tb_ueba_user_risk"."send_file_bytes" IS '当日累积发送文件大小(bytes)';
COMMENT ON COLUMN "tb_ueba_user_risk"."send_file_count" IS '当日累积发送文件数量';
COMMENT ON COLUMN "tb_ueba_user_risk"."download_file_bytes" IS '当日累积下载文件大小(bytes)';
COMMENT ON COLUMN "tb_ueba_user_risk"."download_file_count" IS '当日累积下载文件数量';
COMMENT ON COLUMN "tb_ueba_user_risk"."created_at" IS '创建时间';
COMMENT ON COLUMN "tb_ueba_user_risk"."updated_at" IS '更新时间';
COMMENT ON TABLE "tb_ueba_user_risk" IS 'ueba用户风险表';

-- ----------------------------
-- Records of tb_ueba_user_risk
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_ueba_window_event
-- ----------------------------
DROP TABLE IF EXISTS "tb_ueba_window_event";
CREATE TABLE "tb_ueba_window_event" (
  "id" varchar COLLATE "pg_catalog"."default",
  "rule_id" varchar COLLATE "pg_catalog"."default",
  "window_rule_id" int4,
  "window_type" varchar COLLATE "pg_catalog"."default",
  "create_time" int8,
  "start_time" int8,
  "end_time" int8,
  "event_ids" varchar[] COLLATE "pg_catalog"."default",
  "raw_rule" varchar COLLATE "pg_catalog"."default",
  "user_id" varchar COLLATE "pg_catalog"."default",
  "agent_info" varchar COLLATE "pg_catalog"."default",
  "status" int4,
  "user_name" varchar(255) COLLATE "pg_catalog"."default"
)
;
COMMENT ON TABLE "tb_ueba_window_event" IS 'ueba窗口聚合事件';

-- ----------------------------
-- Records of tb_ueba_window_event
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_entity
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_entity";
CREATE TABLE "tb_user_entity" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "display_name" varchar(255) COLLATE "pg_catalog"."default",
  "true_name" varchar(255) COLLATE "pg_catalog"."default",
  "nick_name" varchar(255) COLLATE "pg_catalog"."default",
  "avatar" text COLLATE "pg_catalog"."default",
  "group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "source_id" varchar(36) COLLATE "pg_catalog"."default",
  "phone" varchar(24) COLLATE "pg_catalog"."default",
  "email" varchar(255) COLLATE "pg_catalog"."default",
  "enable" bool DEFAULT true,
  "expire_type" varchar(24) COLLATE "pg_catalog"."default",
  "expire_end" timestamp(6),
  "root_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "identify" varchar COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_user_entity"."id" IS '用户id';
COMMENT ON COLUMN "tb_user_entity"."name" IS '用户登陆名';
COMMENT ON COLUMN "tb_user_entity"."display_name" IS '用户显示名';
COMMENT ON COLUMN "tb_user_entity"."true_name" IS '用户真实姓名';
COMMENT ON COLUMN "tb_user_entity"."group_id" IS '分组id';
COMMENT ON COLUMN "tb_user_entity"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_user_entity"."source_id" IS '来源id';
COMMENT ON COLUMN "tb_user_entity"."phone" IS '手机号';
COMMENT ON COLUMN "tb_user_entity"."email" IS '邮箱';
COMMENT ON TABLE "tb_user_entity" IS '用户表';

-- ----------------------------
-- Records of tb_user_entity
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_group
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_group";
CREATE TABLE "tb_user_group" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "parent_group_id" varchar(36) COLLATE "pg_catalog"."default" DEFAULT '0'::character varying,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "source_id" varchar(36) COLLATE "pg_catalog"."default",
  "is_default" bool DEFAULT false,
  "root_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_user_group"."id" IS '分组id';
COMMENT ON COLUMN "tb_user_group"."name" IS '分组名，在同级目录下唯一';
COMMENT ON COLUMN "tb_user_group"."parent_group_id" IS '父级分组id，用于维护分组的树形结构，为0时表示最顶层';
COMMENT ON COLUMN "tb_user_group"."corp_id" IS '租户id';
COMMENT ON COLUMN "tb_user_group"."source_id" IS '来源id';
COMMENT ON TABLE "tb_user_group" IS '用户分组';

-- ----------------------------
-- Records of tb_user_group
-- ----------------------------
BEGIN;
INSERT INTO "tb_user_group" ("id", "name", "description", "parent_group_id", "corp_id", "source_id", "is_default", "root_group_id", "created_at", "updated_at") VALUES ('fee12b7b-a71f-4b16-b28e-c1241adb37d3', '默认本地用户组', '', '0', '2efd2601-d800-48b3-9035-9ed23694ba0f', '859725c5-3404-454e-a4b4-90e5d65c5477', 't', 'fee12b7b-a71f-4b16-b28e-c1241adb37d3', '2023-06-01 18:39:22.636394+08', '2023-06-01 18:39:22.636394+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_user_group_sync
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_group_sync";
CREATE TABLE "tb_user_group_sync" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "auto_sync" bool DEFAULT false,
  "last_sync_time" timestamp(6),
  "next_sync_time" timestamp(6),
  "sync_status" varchar(24) COLLATE "pg_catalog"."default",
  "sync_cycle" int4,
  "sync_unit" varchar(24) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_user_group_sync
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_group_sync_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_group_sync_config";
CREATE TABLE "tb_user_group_sync_config" (
  "sync_id" varchar(36) COLLATE "pg_catalog"."default",
  "key" text COLLATE "pg_catalog"."default" NOT NULL,
  "value" text COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_user_group_sync_config
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_group_sync_log
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_group_sync_log";
CREATE TABLE "tb_user_group_sync_log" (
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "type" varchar(24) COLLATE "pg_catalog"."default" NOT NULL,
  "sync_status" varchar(24) COLLATE "pg_catalog"."default" NOT NULL,
  "sync_info" text COLLATE "pg_catalog"."default",
  "operator" varchar(255) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_user_group_sync_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_login_log
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_login_log";
CREATE TABLE "tb_user_login_log" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "client_id" varchar(255) COLLATE "pg_catalog"."default",
  "error" varchar(255) COLLATE "pg_catalog"."default",
  "ip_address" varchar(255) COLLATE "pg_catalog"."default",
  "corp_id" varchar(255) COLLATE "pg_catalog"."default",
  "event_time" int8,
  "type" varchar(255) COLLATE "pg_catalog"."default",
  "user_id" varchar(255) COLLATE "pg_catalog"."default",
  "source_id" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_user_login_log
-- ----------------------------
BEGIN;
INSERT INTO "tb_user_login_log" ("id", "client_id", "error", "ip_address", "corp_id", "event_time", "type", "user_id", "source_id") VALUES ('dd3a4aed-7f5a-4a36-b9a5-7a36f698c310', 'User', '', '175.9.141.29', '2efd2601-d800-48b3-9035-9ed23694ba0f', 1685618168652, 'LOGIN', '217828d7-f44c-4d1b-ba79-e7dc558b3134', '859725c5-3404-454e-a4b4-90e5d65c5477');
COMMIT;

-- ----------------------------
-- Table structure for tb_user_role
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_role";
CREATE TABLE "tb_user_role" (
  "user_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "role_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON TABLE "tb_user_role" IS '用户角色关系表';

-- ----------------------------
-- Records of tb_user_role
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_source
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_source";
CREATE TABLE "tb_user_source" (
  "id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "source_type" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "corp_id" varchar(36) COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;
COMMENT ON COLUMN "tb_user_source"."id" IS '用户来源id';
COMMENT ON COLUMN "tb_user_source"."name" IS '用户来源名称，租户下唯一';
COMMENT ON COLUMN "tb_user_source"."source_type" IS '来源类型，租户下唯一';
COMMENT ON COLUMN "tb_user_source"."corp_id" IS '租户id外键，维护租户-用户来源的1对多关系';
COMMENT ON TABLE "tb_user_source" IS '用户来源表';

-- ----------------------------
-- Records of tb_user_source
-- ----------------------------
BEGIN;
INSERT INTO "tb_user_source" ("id", "name", "source_type", "corp_id", "created_at", "updated_at") VALUES ('859725c5-3404-454e-a4b4-90e5d65c5477', '本地', 'local', '2efd2601-d800-48b3-9035-9ed23694ba0f', '2023-06-01 18:35:59.698562+08', '2023-06-01 18:35:59.698562+08');
INSERT INTO "tb_user_source" ("id", "name", "source_type", "corp_id", "created_at", "updated_at") VALUES ('2199f55a-40da-4030-a82d-540479146d6f', '企业微信', 'qiyewx', '2efd2601-d800-48b3-9035-9ed23694ba0f', '2023-06-01 18:35:59.699762+08', '2023-06-01 18:35:59.699762+08');
COMMIT;

-- ----------------------------
-- Table structure for tb_user_tag
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_tag";
CREATE TABLE "tb_user_tag" (
  "id" int8 NOT NULL,
  "user_id" varchar(255) COLLATE "pg_catalog"."default",
  "tag_id" int8
)
;

-- ----------------------------
-- Records of tb_user_tag
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_user_tag_config
-- ----------------------------
DROP TABLE IF EXISTS "tb_user_tag_config";
CREATE TABLE "tb_user_tag_config" (
  "id" int4 NOT NULL DEFAULT nextval('tb_user_tag_config_id_seq'::regclass),
  "name" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of tb_user_tag_config
-- ----------------------------
BEGIN;
INSERT INTO "tb_user_tag_config" ("id", "name") VALUES (1, '离职中');
INSERT INTO "tb_user_tag_config" ("id", "name") VALUES (2, '试用期');
INSERT INTO "tb_user_tag_config" ("id", "name") VALUES (3, '外包人员');
COMMIT;

-- ----------------------------
-- Table structure for tb_wx_department
-- ----------------------------
DROP TABLE IF EXISTS "tb_wx_department";
CREATE TABLE "tb_wx_department" (
  "wx_corp_id" text COLLATE "pg_catalog"."default" NOT NULL,
  "local_root_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "local_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "id" int8 NOT NULL,
  "name" text COLLATE "pg_catalog"."default",
  "name_en" text COLLATE "pg_catalog"."default",
  "parentid" int8 NOT NULL,
  "order" int8 NOT NULL,
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_wx_department
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for tb_wx_user
-- ----------------------------
DROP TABLE IF EXISTS "tb_wx_user";
CREATE TABLE "tb_wx_user" (
  "wx_corp_id" text COLLATE "pg_catalog"."default" NOT NULL,
  "local_root_group_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "local_user_id" varchar(36) COLLATE "pg_catalog"."default" NOT NULL,
  "main_department" int8 NOT NULL,
  "userid" text COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default",
  "created_at" timestamptz(6) NOT NULL DEFAULT now(),
  "updated_at" timestamptz(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Records of tb_wx_user
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Function structure for upd_timestamp
-- ----------------------------
DROP FUNCTION IF EXISTS "upd_timestamp"();
CREATE OR REPLACE FUNCTION "upd_timestamp"()
  RETURNS "pg_catalog"."trigger" AS $BODY$
begin
    new.updated_at = current_timestamp;
return new;
end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_access_log_access_log_id_seq"
OWNED BY "tb_access_log"."access_log_id";
SELECT setval('"tb_access_log_access_log_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_app_address_id_seq"
OWNED BY "tb_app_address"."id";
SELECT setval('"tb_app_address_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_app_group_id_seq"
OWNED BY "tb_app_group"."id";
SELECT setval('"tb_app_group_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_channel_type_id_seq"
OWNED BY "tb_channel_type"."id";
SELECT setval('"tb_channel_type_id_seq"', 56, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_condition_id_seq"
OWNED BY "tb_condition"."id";
SELECT setval('"tb_condition_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_console_config_id_seq"
OWNED BY "tb_console_config"."id";
SELECT setval('"tb_console_config_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_ddr_score_id_seq"
OWNED BY "tb_ddr_score"."id";
SELECT setval('"tb_ddr_score_id_seq"', 147, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_events_history_id_seq"
OWNED BY "tb_events_history"."id";
SELECT setval('"tb_events_history_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_events_records_id_seq"
OWNED BY "tb_events_records"."id";
SELECT setval('"tb_events_records_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_fake_ip_pool_id_seq"
OWNED BY "tb_fake_ip_pool"."id";
SELECT setval('"tb_fake_ip_pool_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_file_type_id_seq"
OWNED BY "tb_file_type"."id";
SELECT setval('"tb_file_type_id_seq"', 103, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_risk_level_config_id_seq"
OWNED BY "tb_risk_level_config"."id";
SELECT setval('"tb_risk_level_config_id_seq"', 30, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_se_app_relation_id_seq"
OWNED BY "tb_se_app_relation"."id";
SELECT setval('"tb_se_app_relation_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_sensitive_elem_label_id_seq"
OWNED BY "tb_sensitive_elem_label"."id";
SELECT setval('"tb_sensitive_elem_label_id_seq"', 1, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_sensitive_element_id_seq"
OWNED BY "tb_sensitive_element"."id";
SELECT setval('"tb_sensitive_element_id_seq"', 372, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_sensitive_rule_type_id_seq"
OWNED BY "tb_sensitive_rule_type"."id";
SELECT setval('"tb_sensitive_rule_type_id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_system_version_id_seq"
OWNED BY "tb_system_version"."id";
SELECT setval('"tb_system_version_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
SELECT setval('"tb_ueba_risk_level_config_id_seq"', 15, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
SELECT setval('"tb_ueba_strategy_condition_id_seq"', 1000, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_ueba_strategy_condition_id_seq1"
OWNED BY "tb_ueba_strategy_condition"."id";
SELECT setval('"tb_ueba_strategy_condition_id_seq1"', 852, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "tb_user_tag_config_id_seq"
OWNED BY "tb_user_tag_config"."id";
SELECT setval('"tb_user_tag_config_id_seq"', 18, true);

-- ----------------------------
-- Primary Key structure for table tb_access_log
-- ----------------------------
ALTER TABLE "tb_access_log" ADD CONSTRAINT "tb_access_log_pkey" PRIMARY KEY ("access_log_id");

-- ----------------------------
-- Primary Key structure for table tb_access_strategy
-- ----------------------------
ALTER TABLE "tb_access_strategy" ADD CONSTRAINT "tb_access_strategy_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table tb_admin_component
-- ----------------------------
ALTER TABLE "tb_admin_component" ADD CONSTRAINT "tb_admin_component_un" UNIQUE ("provider_id", "corp_id");

-- ----------------------------
-- Primary Key structure for table tb_admin_component
-- ----------------------------
ALTER TABLE "tb_admin_component" ADD CONSTRAINT "tb_admin_component_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_admin_component_config
-- ----------------------------
ALTER TABLE "tb_admin_component_config" ADD CONSTRAINT "tb_admin_component_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_admin_corp
-- ----------------------------
CREATE TRIGGER "tb_admin_corp_update_trigger" BEFORE UPDATE ON "tb_admin_corp"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_admin_corp
-- ----------------------------
ALTER TABLE "tb_admin_corp" ADD CONSTRAINT "tb_admin_corp_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_admin_credential
-- ----------------------------
CREATE TRIGGER "tb_admin_credential_update_trigger" BEFORE UPDATE ON "tb_admin_credential"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_admin_credential
-- ----------------------------
ALTER TABLE "tb_admin_credential" ADD CONSTRAINT "tb_admin_credential_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_admin_entity
-- ----------------------------
CREATE TRIGGER "tb_admin_entity_update_trigger" BEFORE UPDATE ON "tb_admin_entity"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_admin_entity
-- ----------------------------
ALTER TABLE "tb_admin_entity" ADD CONSTRAINT "tb_admin_entity_un" UNIQUE ("name", "corp_id");

-- ----------------------------
-- Primary Key structure for table tb_admin_entity
-- ----------------------------
ALTER TABLE "tb_admin_entity" ADD CONSTRAINT "tb_admin_entity_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_admin_event_entity
-- ----------------------------
ALTER TABLE "tb_admin_event_entity" ADD CONSTRAINT "constraint_tb_admin_event_entity" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_admin_login_log
-- ----------------------------
CREATE INDEX "idx_tb_admin_event_time" ON "tb_admin_login_log" USING btree (
  "corp_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "event_time" "pg_catalog"."int8_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table tb_admin_login_log
-- ----------------------------
ALTER TABLE "tb_admin_login_log" ADD CONSTRAINT "constraint_admin_login_log" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_admin_role
-- ----------------------------
CREATE TRIGGER "tb_admin_role_update_trigger" BEFORE UPDATE ON "tb_admin_role"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_admin_role
-- ----------------------------
ALTER TABLE "tb_admin_role" ADD CONSTRAINT "tb_admin_role_un" UNIQUE ("role_name", "corp_id");

-- ----------------------------
-- Primary Key structure for table tb_admin_role
-- ----------------------------
ALTER TABLE "tb_admin_role" ADD CONSTRAINT "tb_admin_role_pk" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_agent
-- ----------------------------
ALTER TABLE "tb_agent" ADD CONSTRAINT "tb_agent_pkey" PRIMARY KEY ("appliance_id");

-- ----------------------------
-- Primary Key structure for table tb_agent_heartbeat
-- ----------------------------
ALTER TABLE "tb_agent_heartbeat" ADD CONSTRAINT "tb_agent_heartbeat_pkey" PRIMARY KEY ("agent_id");

-- ----------------------------
-- Primary Key structure for table tb_agent_module_switch
-- ----------------------------
ALTER TABLE "tb_agent_module_switch" ADD CONSTRAINT "tb_agent_module_switch_pkey" PRIMARY KEY ("module_code");

-- ----------------------------
-- Uniques structure for table tb_alert_rule
-- ----------------------------
ALTER TABLE "tb_alert_rule" ADD CONSTRAINT "tb_alert_rule_un" UNIQUE ("name");

-- ----------------------------
-- Primary Key structure for table tb_alert_rule
-- ----------------------------
ALTER TABLE "tb_alert_rule" ADD CONSTRAINT "tb_alert_rule_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table tb_alert_rule_template
-- ----------------------------
ALTER TABLE "tb_alert_rule_template" ADD CONSTRAINT "tb_alert_rule_template_un" UNIQUE ("name");

-- ----------------------------
-- Primary Key structure for table tb_alert_rule_template
-- ----------------------------
ALTER TABLE "tb_alert_rule_template" ADD CONSTRAINT "tb_alert_rule_template__pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_app_address
-- ----------------------------
ALTER TABLE "tb_app_address" ADD CONSTRAINT "tb_app_address_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_app_group
-- ----------------------------
ALTER TABLE "tb_app_group" ADD CONSTRAINT "tb_app_group_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_appliance
-- ----------------------------
ALTER TABLE "tb_appliance" ADD CONSTRAINT "tb_appliance_pkey" PRIMARY KEY ("appliance_id");

-- ----------------------------
-- Primary Key structure for table tb_appliance_cfg
-- ----------------------------
ALTER TABLE "tb_appliance_cfg" ADD CONSTRAINT "tb_appliance_cfg_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_appliance_heartbeat
-- ----------------------------
ALTER TABLE "tb_appliance_heartbeat" ADD CONSTRAINT "tb_appliance_heartbeat_pkey" PRIMARY KEY ("appliance_id");

-- ----------------------------
-- Primary Key structure for table tb_appliance_install
-- ----------------------------
ALTER TABLE "tb_appliance_install" ADD CONSTRAINT "tb_appliance_install_pkey" PRIMARY KEY ("appliance_id");

-- ----------------------------
-- Primary Key structure for table tb_application
-- ----------------------------
ALTER TABLE "tb_application" ADD CONSTRAINT "tb_application_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_auth_policy
-- ----------------------------
CREATE TRIGGER "tb_auth_policy_update_trigger" BEFORE UPDATE ON "tb_auth_policy"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_auth_policy
-- ----------------------------
ALTER TABLE "tb_auth_policy" ADD CONSTRAINT "unique_auth_policy_corp_root_group_name" UNIQUE ("corp_id", "root_group_id", "name");

-- ----------------------------
-- Primary Key structure for table tb_auth_policy
-- ----------------------------
ALTER TABLE "tb_auth_policy" ADD CONSTRAINT "tb_auth_policy_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_auth_policy_idp_mapper
-- ----------------------------
CREATE TRIGGER "tb_auth_policy_idp_mapper_update_trigger" BEFORE UPDATE ON "tb_auth_policy_idp_mapper"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_auth_policy_idp_mapper
-- ----------------------------
ALTER TABLE "tb_auth_policy_idp_mapper" ADD CONSTRAINT "unique_auth_policy_idp_mapper_policy_id_idp_id" UNIQUE ("policy_id", "idp_id");

-- ----------------------------
-- Primary Key structure for table tb_channel_type
-- ----------------------------
ALTER TABLE "tb_channel_type" ADD CONSTRAINT "tb_channel_type_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table tb_component
-- ----------------------------
ALTER TABLE "tb_component" ADD CONSTRAINT "tb_component_provider_id_corp" UNIQUE ("corp_id", "provider_id");

-- ----------------------------
-- Primary Key structure for table tb_component
-- ----------------------------
ALTER TABLE "tb_component" ADD CONSTRAINT "tb_component_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_component_config
-- ----------------------------
ALTER TABLE "tb_component_config" ADD CONSTRAINT "tb_component_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_condition
-- ----------------------------
ALTER TABLE "tb_condition" ADD CONSTRAINT "tb_condition_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_console_config
-- ----------------------------
ALTER TABLE "tb_console_config" ADD CONSTRAINT "tb_console_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_corp
-- ----------------------------
CREATE INDEX "index_corp_name" ON "tb_corp" USING btree (
  "name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Triggers structure for table tb_corp
-- ----------------------------
CREATE TRIGGER "tb_corp_update_trigger" BEFORE UPDATE ON "tb_corp"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_corp
-- ----------------------------
ALTER TABLE "tb_corp" ADD CONSTRAINT "tb_corp_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_credential
-- ----------------------------
CREATE TRIGGER "tb_credential_update_trigger" BEFORE UPDATE ON "tb_credential"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_credential
-- ----------------------------
ALTER TABLE "tb_credential" ADD CONSTRAINT "tb_credential_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_ddr_score
-- ----------------------------
ALTER TABLE "tb_ddr_score" ADD CONSTRAINT "tb_ddr_score_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_ddr_source
-- ----------------------------
CREATE UNIQUE INDEX "uk_source_name" ON "tb_ddr_source" USING btree (
  "source_name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table tb_ddr_source
-- ----------------------------
ALTER TABLE "tb_ddr_source" ADD CONSTRAINT "tb_ddr_source_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_ddr_source_git
-- ----------------------------
ALTER TABLE "tb_ddr_source_git" ADD CONSTRAINT "tb_ddr_source_git_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_ddr_source_software
-- ----------------------------
ALTER TABLE "tb_ddr_source_software" ADD CONSTRAINT "tb_ddr_source_software_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_ddr_source_web
-- ----------------------------
ALTER TABLE "tb_ddr_source_web" ADD CONSTRAINT "tb_ddr_source_web_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_events_history
-- ----------------------------
ALTER TABLE "tb_events_history" ADD CONSTRAINT "tb_events_history_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_events_records
-- ----------------------------
ALTER TABLE "tb_events_records" ADD CONSTRAINT "tb_events_records_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_fake_ip_pool
-- ----------------------------
ALTER TABLE "tb_fake_ip_pool" ADD CONSTRAINT "tb_fake_ip_pool_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_file_type
-- ----------------------------
ALTER TABLE "tb_file_type" ADD CONSTRAINT "tb_file_type_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_identity_provider
-- ----------------------------
CREATE TRIGGER "tb_identity_provider_update_trigger" BEFORE UPDATE ON "tb_identity_provider"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_identity_provider
-- ----------------------------
ALTER TABLE "tb_identity_provider" ADD CONSTRAINT "unique_idp_corp_name" UNIQUE ("corp_id", "name");

-- ----------------------------
-- Primary Key structure for table tb_identity_provider
-- ----------------------------
ALTER TABLE "tb_identity_provider" ADD CONSTRAINT "tb_identity_provider_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_identity_provider_attribute
-- ----------------------------
CREATE TRIGGER "tb_identity_provider_attribute_update_trigger" BEFORE UPDATE ON "tb_identity_provider_attribute"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Triggers structure for table tb_idp_group_mapper
-- ----------------------------
CREATE TRIGGER "tb_idp_group_mapper_update_trigger" BEFORE UPDATE ON "tb_idp_group_mapper"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_idp_group_mapper
-- ----------------------------
ALTER TABLE "tb_idp_group_mapper" ADD CONSTRAINT "unique_idp_provider_id_group_id" UNIQUE ("provider_id", "group_id");

-- ----------------------------
-- Primary Key structure for table tb_incident
-- ----------------------------
ALTER TABLE "tb_incident" ADD CONSTRAINT "tb_incident_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_module_switch
-- ----------------------------
ALTER TABLE "tb_module_switch" ADD CONSTRAINT "tb_module_switch_pkey" PRIMARY KEY ("module_code");

-- ----------------------------
-- Primary Key structure for table tb_risk_level_config
-- ----------------------------
ALTER TABLE "tb_risk_level_config" ADD CONSTRAINT "tb_risk_level_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_role
-- ----------------------------
CREATE TRIGGER "tb_role_update_trigger" BEFORE UPDATE ON "tb_role"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_role
-- ----------------------------
ALTER TABLE "tb_role" ADD CONSTRAINT "unique_role_corp_name" UNIQUE ("corp_id", "name");

-- ----------------------------
-- Primary Key structure for table tb_role
-- ----------------------------
ALTER TABLE "tb_role" ADD CONSTRAINT "tb_role_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_se_app_relation
-- ----------------------------
ALTER TABLE "tb_se_app_relation" ADD CONSTRAINT "tb_se_app_relation_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_sensitive_elem_label
-- ----------------------------
ALTER TABLE "tb_sensitive_elem_label" ADD CONSTRAINT "tb_sensitive_elem_label_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_sensitive_element
-- ----------------------------
ALTER TABLE "tb_sensitive_element" ADD CONSTRAINT "tb_sensitive_element_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_sensitive_rule_type
-- ----------------------------
ALTER TABLE "tb_sensitive_rule_type" ADD CONSTRAINT "tb_sensitive_rule_type_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_special_config
-- ----------------------------
CREATE TRIGGER "tb_special_config_update_trigger" BEFORE UPDATE ON "tb_special_config"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_special_config
-- ----------------------------
ALTER TABLE "tb_special_config" ADD CONSTRAINT "tb_special_config_pk" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_system_version
-- ----------------------------
ALTER TABLE "tb_system_version" ADD CONSTRAINT "tb_system_version_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_task_info
-- ----------------------------
CREATE INDEX "idx_tb_task_info_task_id" ON "tb_task_info" USING btree (
  "task_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "idx_tb_task_info_task_name" ON "tb_task_info" USING btree (
  "task_name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table tb_task_info
-- ----------------------------
ALTER TABLE "tb_task_info" ADD CONSTRAINT "tb_task_info_pkey" PRIMARY KEY ("task_id");

-- ----------------------------
-- Indexes structure for table tb_task_result
-- ----------------------------
CREATE INDEX "idx_tb_task_result_task_id" ON "tb_task_result" USING btree (
  "task_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "agent_id" "pg_catalog"."int8_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table tb_task_result
-- ----------------------------
ALTER TABLE "tb_task_result" ADD CONSTRAINT "tb_task_result_pkey" PRIMARY KEY ("task_id", "agent_id");

-- ----------------------------
-- Indexes structure for table tb_ueba_risk_level_config
-- ----------------------------
CREATE UNIQUE INDEX "uk_risk_level" ON "tb_ueba_risk_level_config" USING btree (
  "risk_level" "pg_catalog"."int4_ops" ASC NULLS LAST
);
COMMENT ON INDEX "uk_risk_level" IS '风险等级唯一键索引';

-- ----------------------------
-- Primary Key structure for table tb_ueba_risk_level_config
-- ----------------------------
ALTER TABLE "tb_ueba_risk_level_config" ADD CONSTRAINT "tb_ueba_risk_level_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_ueba_strategy
-- ----------------------------
CREATE UNIQUE INDEX "uk_name" ON "tb_ueba_strategy" USING btree (
  "name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
COMMENT ON INDEX "uk_name" IS '规则名称唯一索引';

-- ----------------------------
-- Primary Key structure for table tb_ueba_strategy
-- ----------------------------
ALTER TABLE "tb_ueba_strategy" ADD CONSTRAINT "tb_ueba_strategy_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_ueba_strategy_condition
-- ----------------------------
CREATE UNIQUE INDEX "uk_condition" ON "tb_ueba_strategy_condition" USING btree (
  "condition" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
COMMENT ON INDEX "uk_condition" IS '条件唯一索引';

-- ----------------------------
-- Primary Key structure for table tb_ueba_strategy_condition
-- ----------------------------
ALTER TABLE "tb_ueba_strategy_condition" ADD CONSTRAINT "tb_ueba_strategy_condition_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_ueba_user_risk
-- ----------------------------
CREATE UNIQUE INDEX "uk_user_id_score_date" ON "tb_ueba_user_risk" USING btree (
  "user_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "score_date" "pg_catalog"."date_ops" ASC NULLS LAST
);
COMMENT ON INDEX "uk_user_id_score_date" IS '用户id时间唯一索引';

-- ----------------------------
-- Primary Key structure for table tb_ueba_user_risk
-- ----------------------------
ALTER TABLE "tb_ueba_user_risk" ADD CONSTRAINT "tb_ueba_user_risk_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table tb_ueba_window_event
-- ----------------------------
CREATE INDEX "idx_cep_query" ON "tb_ueba_window_event" USING btree (
  "rule_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "end_time" "pg_catalog"."int8_ops" ASC NULLS LAST
);
COMMENT ON INDEX "idx_cep_query" IS '复杂序列查询索引';

-- ----------------------------
-- Triggers structure for table tb_user_entity
-- ----------------------------
CREATE TRIGGER "tb_user_entity_update_trigger" BEFORE UPDATE ON "tb_user_entity"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_user_entity
-- ----------------------------
ALTER TABLE "tb_user_entity" ADD CONSTRAINT "tb_user_entity_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_user_group
-- ----------------------------
CREATE TRIGGER "tb_user_group_update_trigger" BEFORE UPDATE ON "tb_user_group"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_user_group
-- ----------------------------
ALTER TABLE "tb_user_group" ADD CONSTRAINT "unique_user_group_corp_parent_group_id_name" UNIQUE ("corp_id", "parent_group_id", "name");

-- ----------------------------
-- Primary Key structure for table tb_user_group
-- ----------------------------
ALTER TABLE "tb_user_group" ADD CONSTRAINT "tb_user_group_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_user_group_sync
-- ----------------------------
CREATE TRIGGER "tb_user_group_sync_update_trigger" BEFORE UPDATE ON "tb_user_group_sync"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Primary Key structure for table tb_user_group_sync
-- ----------------------------
ALTER TABLE "tb_user_group_sync" ADD CONSTRAINT "tb_user_group_sync_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_user_group_sync_config
-- ----------------------------
CREATE TRIGGER "tb_user_group_sync_config_update_trigger" BEFORE UPDATE ON "tb_user_group_sync_config"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Indexes structure for table tb_user_login_log
-- ----------------------------
CREATE INDEX "idx_user_event_time" ON "tb_user_login_log" USING btree (
  "corp_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "event_time" "pg_catalog"."int8_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table tb_user_login_log
-- ----------------------------
ALTER TABLE "tb_user_login_log" ADD CONSTRAINT "tb_user_login_log_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_user_role
-- ----------------------------
CREATE TRIGGER "tb_user_role_update_trigger" BEFORE UPDATE ON "tb_user_role"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_user_role
-- ----------------------------
ALTER TABLE "tb_user_role" ADD CONSTRAINT "unique_user_role_user_id_role_id" UNIQUE ("user_id", "role_id");

-- ----------------------------
-- Triggers structure for table tb_user_source
-- ----------------------------
CREATE TRIGGER "tb_user_source_update_trigger" BEFORE UPDATE ON "tb_user_source"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_user_source
-- ----------------------------
ALTER TABLE "tb_user_source" ADD CONSTRAINT "unique_user_source_corp_source" UNIQUE ("corp_id", "source_type");
ALTER TABLE "tb_user_source" ADD CONSTRAINT "unique_user_source_corp_name" UNIQUE ("corp_id", "name");

-- ----------------------------
-- Primary Key structure for table tb_user_source
-- ----------------------------
ALTER TABLE "tb_user_source" ADD CONSTRAINT "tb_user_source_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_user_tag
-- ----------------------------
ALTER TABLE "tb_user_tag" ADD CONSTRAINT "tb_user_tag_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table tb_user_tag_config
-- ----------------------------
ALTER TABLE "tb_user_tag_config" ADD CONSTRAINT "tb_user_tag_config_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Triggers structure for table tb_wx_department
-- ----------------------------
CREATE TRIGGER "tb_wx_department_update_trigger" BEFORE UPDATE ON "tb_wx_department"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Uniques structure for table tb_wx_department
-- ----------------------------
ALTER TABLE "tb_wx_department" ADD CONSTRAINT "unique_wx_department_corp_id" UNIQUE ("local_group_id", "id");

-- ----------------------------
-- Triggers structure for table tb_wx_user
-- ----------------------------
CREATE TRIGGER "tb_wx_user_trigger" BEFORE UPDATE ON "tb_wx_user"
FOR EACH ROW
EXECUTE PROCEDURE "public"."upd_timestamp"();

-- ----------------------------
-- Foreign Keys structure for table tb_auth_policy
-- ----------------------------
ALTER TABLE "tb_auth_policy" ADD CONSTRAINT "tb_auth_policy_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_auth_policy_idp_mapper
-- ----------------------------
ALTER TABLE "tb_auth_policy_idp_mapper" ADD CONSTRAINT "tb_auth_policy_idp_mapper_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "tb_auth_policy_idp_mapper" ADD CONSTRAINT "tb_auth_policy_idp_mapper_idp_id_fkey" FOREIGN KEY ("idp_id") REFERENCES "tb_identity_provider" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_component
-- ----------------------------
ALTER TABLE "tb_component" ADD CONSTRAINT "tb_component_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_component_config
-- ----------------------------
ALTER TABLE "tb_component_config" ADD CONSTRAINT "tb_component_config_component_id_fkey" FOREIGN KEY ("component_id") REFERENCES "tb_component" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_credential
-- ----------------------------
ALTER TABLE "tb_credential" ADD CONSTRAINT "tb_credential_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_identity_provider
-- ----------------------------
ALTER TABLE "tb_identity_provider" ADD CONSTRAINT "tb_identity_provider_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_identity_provider_attribute
-- ----------------------------
ALTER TABLE "tb_identity_provider_attribute" ADD CONSTRAINT "tb_identity_provider_attribute_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "tb_identity_provider" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_idp_group_mapper
-- ----------------------------
ALTER TABLE "tb_idp_group_mapper" ADD CONSTRAINT "tb_idp_group_mapper_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_role
-- ----------------------------
ALTER TABLE "tb_role" ADD CONSTRAINT "tb_role_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_entity
-- ----------------------------
ALTER TABLE "tb_user_entity" ADD CONSTRAINT "tb_user_entity_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "tb_user_entity" ADD CONSTRAINT "tb_user_entity_source_id_fkey" FOREIGN KEY ("source_id") REFERENCES "tb_user_source" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_group
-- ----------------------------
ALTER TABLE "tb_user_group" ADD CONSTRAINT "tb_user_group_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "tb_user_group" ADD CONSTRAINT "tb_user_group_source_id_fkey" FOREIGN KEY ("source_id") REFERENCES "tb_user_source" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_group_sync_config
-- ----------------------------
ALTER TABLE "tb_user_group_sync_config" ADD CONSTRAINT "tb_user_group_sync_config_sync_id_fkey" FOREIGN KEY ("sync_id") REFERENCES "tb_user_group_sync" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_group_sync_log
-- ----------------------------
ALTER TABLE "tb_user_group_sync_log" ADD CONSTRAINT "tb_user_group_sync_log_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_role
-- ----------------------------
ALTER TABLE "tb_user_role" ADD CONSTRAINT "tb_user_role_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table tb_user_source
-- ----------------------------
ALTER TABLE "tb_user_source" ADD CONSTRAINT "tb_user_source_corp_id_fkey" FOREIGN KEY ("corp_id") REFERENCES "tb_corp" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
